/* wm-boot.js (loader leve) */
/* Executa cedo no <head> para corrigir URLs de imagens antes do bundle do tema rodar. */
(function () {
  "use strict";

  function rewriteBadUrl(u) {
    try {
      if (!u) return u;
      if (typeof u !== "string") u = String(u);
      if (u.indexOf("data:") === 0 || u.indexOf("blob:") === 0) return u;

      var urlObj = null;
      try {
        urlObj = new URL(u, String(location.href || ""));
      } catch (_e) {
        urlObj = null;
      }

      var href = urlObj ? urlObj.toString() : u;
      var host = urlObj ? String(urlObj.hostname || "").toLowerCase() : "";
      var path = urlObj ? String(urlObj.pathname || "") : "";
      var search = urlObj ? String(urlObj.search || "") : "";

      // ImageKit path on ANY host that isn't ImageKit itself -> redirect
      if (host !== "ik.imagekit.io" && /^\/?zg5zlyoyg\//i.test(path)) {
        return "https://ik.imagekit.io" + (path.charAt(0) === "/" ? "" : "/") + path + search;
      }
      // iGameWin path on any non-igamewin host
      if (host !== "igamewin.com" && /^\/storage\/igamewin\//i.test(path)) {
        return "https://igamewin.com" + (path.charAt(0) === "/" ? "" : "/") + path + search;
      }
      // Google image thumbnails proxied through current host
      if (/^\/images$/i.test(path) && /[?&]q=tbn:/i.test(search)) {
        return "https://encrypted-tbn0.gstatic.com" + path + search;
      }

      // raw relative forms
      if (/^\/images\?q=tbn:/i.test(u)) return "https://encrypted-tbn0.gstatic.com" + u;
      if (/^\/storage\/igamewin\//i.test(u)) return "https://igamewin.com" + u;

      return href;
    } catch (_e2) {
      return u;
    }
  }

  // Patch Image.src
  try {
    var imgProto = (window.Image && window.Image.prototype) ? window.Image.prototype : null;
    if (imgProto && !imgProto.__wmBootSrcPatched) {
      var desc = Object.getOwnPropertyDescriptor(imgProto, "src");
      if (desc && desc.set) {
        Object.defineProperty(imgProto, "src", {
          configurable: true,
          enumerable: desc.enumerable,
          get: desc.get,
          set: function (v) {
            try { return desc.set.call(this, rewriteBadUrl(v)); } catch (_e3) { return desc.set.call(this, v); }
          },
        });
        imgProto.__wmBootSrcPatched = true;
      }
    }
  } catch (_e4) {}

  // Patch fetch
  try {
    if (typeof window.fetch === "function" && !window.__wmBootFetchPatched) {
      var origFetch = window.fetch;
      window.fetch = function (input, init) {
        try {
          if (typeof input === "string") {
            input = rewriteBadUrl(input);
          } else if (input && typeof input.url === "string") {
            var newUrl = rewriteBadUrl(input.url);
            if (newUrl !== input.url && typeof Request === "function") input = new Request(newUrl, input);
          }
        } catch (_e5) {}
        return origFetch.call(this, input, init);
      };
      window.__wmBootFetchPatched = true;
    }
  } catch (_e6) {}

  // Patch XHR.open
  try {
    var xhrProto = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
    if (xhrProto && !xhrProto.__wmBootOpenPatched) {
      var origOpen = xhrProto.open;
      xhrProto.open = function (method, url, async, user, password) {
        try { url = rewriteBadUrl(url); } catch (_e7) {}
        return origOpen.call(this, method, url, async, user, password);
      };
      xhrProto.__wmBootOpenPatched = true;
    }
  } catch (_e8) {}

  // Patch CSSStyleDeclaration.setProperty (best-effort) to normalize background-image URLs.
  try {
    var styleProto = window.CSSStyleDeclaration && window.CSSStyleDeclaration.prototype;
    if (styleProto && !styleProto.__wmBootSetPropPatched && typeof styleProto.setProperty === "function") {
      var origSetProperty = styleProto.setProperty;
      styleProto.setProperty = function (prop, value, priority) {
        try {
          if (prop === "background-image" || prop === "backgroundImage") {
            var v = String(value || "");
            if (v && v.indexOf("url(") !== -1) {
              var m = v.match(/url\((['"]?)(.*?)\1\)/i);
              var u2 = m && m[2] ? rewriteBadUrl(m[2]) : "";
              if (u2) {
                // Replace only inside url(...)
                value = v.replace(/url\((['"]?)(.*?)\1\)/i, 'url("' + String(u2).replace(/"/g, "%22") + '")');
              }
            }
          }
        } catch (_e9) {}
        return origSetProperty.call(this, prop, value, priority);
      };
      styleProto.__wmBootSetPropPatched = true;
    }
  } catch (_e10) {}

  // Also patch direct assignment: el.style.backgroundImage = 'url(...)'
  try {
    var styleProto2 = window.CSSStyleDeclaration && window.CSSStyleDeclaration.prototype;
    if (styleProto2 && !styleProto2.__wmBootBgImgPatched) {
      var bgDesc = Object.getOwnPropertyDescriptor(styleProto2, "backgroundImage");
      if (bgDesc && bgDesc.set) {
        Object.defineProperty(styleProto2, "backgroundImage", {
          configurable: true,
          enumerable: bgDesc.enumerable,
          get: bgDesc.get,
          set: function (v) {
            try {
              var s = String(v || "");
              var m = s.match(/url\((['"]?)(.*?)\1\)/i);
              var u3 = m && m[2] ? rewriteBadUrl(m[2]) : "";
              if (u3) {
                v = s.replace(/url\((['"]?)(.*?)\1\)/i, 'url("' + String(u3).replace(/"/g, "%22") + '")');
              }
            } catch (_e11) {}
            return bgDesc.set.call(this, v);
          },
        });
      }
      styleProto2.__wmBootBgImgPatched = true;
    }
  } catch (_e12) {}
})();
