/* wm-all.js (arquivo unico de customizacoes WM) */
/* Organizado por secoes para facilitar manutencao. */
(function(){
  "use strict";
  window.__WM_ALL = window.__WM_ALL || {};
  var FLAGS = window.__WM_ALL.flags || {};
  var DATA  = window.__WM_ALL.data  || {};

  // DEV marker (localhost): ajuda a confirmar se este arquivo carregou mesmo.
  try {
    var __wmHost = (location && location.hostname) ? String(location.hostname) : "";
    if (__wmHost === "localhost" || __wmHost === "127.0.0.1" || __wmHost === "::1") {
      window.__wm_all_loaded = window.__wm_all_loaded || {};
      window.__wm_all_loaded.at = Date.now ? Date.now() : +new Date();
      window.__wm_all_loaded.href = String(location.href || "");
      console.warn("[wm-all] loaded", window.__wm_all_loaded);
    }
  } catch (_e0) {}

  /* ========================================================== */
  /* SESSION / REGISTER hooks */
  /* ========================================================== */
  (function () {
    // Se o backend determinou que nao ha sessao valida, mas o frontend ainda tem
    // residuos de token no storage, limpa e recarrega.
    try {
      if (DATA && DATA.hasTokenUser === false) {
        var keysToCheck = ["token_user", "web__lobby__persisted__token", "web__lobby__persisted__user"];
        var hasResidue = false;
        for (var i = 0; i < keysToCheck.length; i++) {
          if (localStorage.getItem(keysToCheck[i])) {
            localStorage.removeItem(keysToCheck[i]);
            hasResidue = true;
          }
        }
        if (hasResidue) {
          // Evita loop infinito: faz a limpeza apenas uma vez por aba e NAO força reload.
          // Limpa apenas chaves relacionadas a sessão/persistência, sem apagar cookies gerais.
          var CLEAN_KEY = "wm__session_cleaned";
          try {
            if (sessionStorage.getItem(CLEAN_KEY) === "1") return;
            sessionStorage.setItem(CLEAN_KEY, "1");
          } catch (_e0) {}

          try {
            // Remove quaisquer stores persistidos do lobby
            for (var k = localStorage.length - 1; k >= 0; k--) {
              var key = localStorage.key(k);
              if (!key) continue;
              if (key.indexOf("web__lobby__persisted__") === 0) localStorage.removeItem(key);
            }
          } catch (_e1) {}
          return;
        }
      }
    } catch (_e) {}

    // Compat: alguns fluxos leem window.WITHDRAW_GATE_CONFIG (vem do PHP via DATA.withdrawGateConfig).
    try {
      if (!window.WITHDRAW_GATE_CONFIG && DATA && DATA.withdrawGateConfig) {
        window.WITHDRAW_GATE_CONFIG = DATA.withdrawGateConfig;
      }
    } catch (_e2) {}

    function isRegisterUrl(u) {
      try {
        var url = typeof u === "string" ? u : (u && u.url) || "";
        // Match both "/api/member/register" and "/hall/api/member/register"
        return /\/(hall\/)?api\/member\/register/.test(url) || /\/member\/register/.test(url);
      } catch (_e3) {
        return false;
      }
    }

    function scheduleWelcomeReload(delayMs) {
      try { document.cookie = "welcome_after_register=1; path=/; max-age=300; samesite=Lax"; } catch(_e4) {}
      try { localStorage.setItem('wm_has_session', '1'); } catch(_e4b) {}
      if (window.__welcomeReloadScheduled) return;
      window.__welcomeReloadScheduled = true;
      setTimeout(function () { location.reload(); }, delayMs || 600);
    }

    (function () {
      var originalOpen = XMLHttpRequest.prototype.open;
      var originalSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function (method, url) {
        this._url = url;
        this._method = method;
        return originalOpen.apply(this, arguments);
      };
      XMLHttpRequest.prototype.send = function () {
        var xhr = this;
        if (xhr._url && isRegisterUrl(xhr._url)) {
          xhr.addEventListener("readystatechange", function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
              try {
                var data = JSON.parse(xhr.responseText);
                if (data && data.code === 1 && data.data && data.data.showWelcomeModal === true) {
                  scheduleWelcomeReload(600);
                }
              } catch (_e5) {}
            }
          });
        }
        return originalSend.apply(this, arguments);
      };
    })();

    (function () {
      if (typeof window.fetch !== "function") return;
      var originalFetch = window.fetch;
      window.fetch = function () {
        var args = arguments;
        var url = typeof args[0] === "string" ? args[0] : (args[0] && args[0].url);
        return originalFetch.apply(this, args).then(function (response) {
          if (url && isRegisterUrl(url)) {
            try {
              var cloned = response.clone();
              cloned.json().then(function (data) {
                if (data && data.code === 1 && data.data && data.data.showWelcomeModal === true) {
                  scheduleWelcomeReload(30);
                }
              }).catch(function () {});
            } catch (_e6) {}
          }
          return response;
        });
      };
    })();
  })();

  /* ========================================================== */
  /* /home/search header (logo + title on the right) */
  /* ========================================================== */
  // Shared navigation+DOM hooks for header injections (avoid stacking multiple history wrappers / observers)
  (function () {
    try {
      if (window.__wmHeaderRouteAppliers && window.__wmInstallHeaderRouteHooks) return;
    } catch (_e0) {}

    try { window.__wmHeaderRouteAppliers = window.__wmHeaderRouteAppliers || []; } catch (_e1) {}

    window.__wmInstallHeaderRouteHooks = function () {
      try { if (window.__wmHeaderRouteHooksInstalled) return; } catch (_e2) {}
      try { window.__wmHeaderRouteHooksInstalled = true; } catch (_e3) {}

      var scheduled = false;
      function runAll() {
        var list = [];
        try { list = window.__wmHeaderRouteAppliers || []; } catch (_e0) {}
        for (var i = 0; i < list.length; i++) {
          try { if (typeof list[i] === "function") list[i](); } catch (_e1) {}
        }
      }
      function schedule() {
        if (scheduled) return;
        scheduled = true;
        try {
          requestAnimationFrame(function () {
            scheduled = false;
            runAll();
          });
        } catch (_e2) {
          setTimeout(function () { scheduled = false; runAll(); }, 16);
        }
      }

      // Hook SPA navigations once (do NOT stack wrappers)
      try {
        if (!history.__wmHeaderRouteWrapped) {
          history.__wmHeaderRouteWrapped = true;
          var push = history.pushState;
          var replace = history.replaceState;
          history.pushState = function () {
            var ret = push.apply(this, arguments);
            setTimeout(schedule, 0);
            return ret;
          };
          history.replaceState = function () {
            var ret = replace.apply(this, arguments);
            setTimeout(schedule, 0);
            return ret;
          };
        }
      } catch (_e4) {}

      try { window.addEventListener("popstate", function () { setTimeout(schedule, 0); }, { passive: true }); } catch (_e5) {}
      try { window.addEventListener("hashchange", function () { setTimeout(schedule, 0); }, { passive: true }); } catch (_e6) {}

      // Light DOM observer once (throttled) to catch header re-renders
      try {
        if (!window.__wmHeaderRouteObserver) {
          window.__wmHeaderRouteObserver = new MutationObserver(function () { schedule(); });
          var root = document.body || document.documentElement;
          if (root) window.__wmHeaderRouteObserver.observe(root, { childList: true, subtree: true });
        }
      } catch (_e7) {}

      // Initial run
      setTimeout(schedule, 0);
    };
  })();

  (function () {
    function isHomeSearchRoute() {
      try {
        var href = String(location.href || "");
        return href.indexOf("/home/search") !== -1;
      } catch (_e0) {
        return false;
      }
    }

    function detectLogoSrc() {
      try {
        if (DATA && typeof DATA.logoSrc === "string" && DATA.logoSrc.trim()) return DATA.logoSrc.trim();
      } catch (_e1) {}

      try {
        var img = document.querySelector('img[src^="/uploads/"], img[src*="/uploads/"]');
        if (img) {
          var src = img.getAttribute("src") || "";
          if (src && src.indexOf("/uploads/") !== -1) return src;
        }
      } catch (_e2) {}

      return "";
    }

    function getHeader() {
      return document.querySelector("header.lobby-base-header");
    }

    function resetHeader(header) {
      if (!header) return;
      if (!header.classList.contains("wm-home-search-header")) return;

      try {
        var injected = header.querySelector(".wm-home-search-logo");
        if (injected) injected.remove();
      } catch (_e0) {}

      try {
        var center = header.querySelector(".lobby-base-header__section--center");
        var right = header.querySelector(".lobby-base-header__section--right");
        if (right) {
          right.classList.remove("wm-home-search-title");
          right.textContent = "";
        }
        if (center) {
          center.style.display = "";
          if (header.dataset.wmHomeSearchOriginalTitle) {
            center.textContent = header.dataset.wmHomeSearchOriginalTitle;
          }
        }
      } catch (_e1) {}

      try {
        header.classList.remove("wm-home-search-header");
        delete header.dataset.wmHomeSearchTitleMoved;
        delete header.dataset.wmHomeSearchOriginalTitle;
      } catch (_e2) {}
    }

    function applyHeader() {
      var header = getHeader();
      if (!header) return;

      if (!isHomeSearchRoute()) {
        resetHeader(header);
        return;
      }

      header.classList.add("wm-home-search-header");

      var left = header.querySelector(".lobby-base-header__section--left");
      var center = header.querySelector(".lobby-base-header__section--center");
      var right = header.querySelector(".lobby-base-header__section--right");

      // Inject logo next to back arrow
      if (left && !left.querySelector(".wm-home-search-logo")) {
        var src = detectLogoSrc();
        if (src) {
          var wrap = document.createElement("div");
          wrap.className = "wm-baseheader-logo wm-home-search-logo";
          wrap.innerHTML = '<img alt="logo" src="' + src + '">';
          var back = left.querySelector(".lobby-base-header__back");
          if (back && back.parentNode) {
            back.insertAdjacentElement("afterend", wrap);
          } else {
            left.appendChild(wrap);
          }
        }
      }

      // Move "Pesquisar" to the right section
      if (center && right && !header.dataset.wmHomeSearchTitleMoved) {
        var title = (center.textContent || "").trim();
        if (title) {
          header.dataset.wmHomeSearchOriginalTitle = title;
          right.textContent = title;
          right.classList.add("wm-home-search-title");
          center.textContent = "";
          center.style.display = "none";
          header.dataset.wmHomeSearchTitleMoved = "1";
        }
      }
    }

    try { (window.__wmHeaderRouteAppliers = window.__wmHeaderRouteAppliers || []).push(applyHeader); } catch (_e0) {}
    try { if (window.__wmInstallHeaderRouteHooks) window.__wmInstallHeaderRouteHooks(); } catch (_e1) {}
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () { try { applyHeader(); } catch (_e2) {} }, { once: true });
    } else {
      try { applyHeader(); } catch (_e3) {}
    }
  })();

  /* ========================================================== */
  /* /home/subgame header (logo + title on the right) */
  /* ========================================================== */
  (function () {
    function isHomeSubgameRoute() {
      try {
        var href = String(location.href || "");
        if (href.indexOf("/home/subgame") === -1) return false;
        // garante que é a página de subgame por categoria
        return href.indexOf("gameCategoryId=") !== -1;
      } catch (_e0) {
        return false;
      }
    }

    function detectLogoSrc() {
      try {
        if (DATA && typeof DATA.logoSrc === "string" && DATA.logoSrc.trim()) return DATA.logoSrc.trim();
      } catch (_e1) {}

      try {
        var img = document.querySelector('img[src^="/uploads/"], img[src*="/uploads/"]');
        if (img) {
          var src = img.getAttribute("src") || "";
          if (src && src.indexOf("/uploads/") !== -1) return src;
        }
      } catch (_e2) {}

      return "";
    }

    function getHeader() {
      return document.querySelector("header.lobby-base-header");
    }

    function getSubgameTitleFallback() {
      try {
        var href = String(location.href || "");
        var u = new URL(href, location.origin);
        var gameCategoryId = u.searchParams.get("gameCategoryId") || "";
        var platformId = u.searchParams.get("platformId") || "";

        // Fixos conforme pedido
        if (gameCategoryId === "101" && platformId === "101999") return "Favoritos";
        if (gameCategoryId === "100" && platformId === "100999") return "Recente";
      } catch (_e0) {}

      return "";
    }

    function resetHeader(header) {
      if (!header) return;
      if (!header.classList.contains("wm-home-subgame-header")) return;

      try {
        var injected = header.querySelector(".wm-home-subgame-logo");
        if (injected) injected.remove();
      } catch (_e0) {}

      try {
        var center = header.querySelector(".lobby-base-header__section--center");
        var right = header.querySelector(".lobby-base-header__section--right");
        if (right) {
          right.classList.remove("wm-home-subgame-title");
          right.textContent = "";
        }
        if (center) {
          center.style.display = "";
          if (header.dataset.wmHomeSubgameOriginalTitle) center.textContent = header.dataset.wmHomeSubgameOriginalTitle;
          else if (header.dataset.wmHomeSubgameLastCenterTitle) center.textContent = header.dataset.wmHomeSubgameLastCenterTitle;
        }
      } catch (_e1) {}

      try {
        header.classList.remove("wm-home-subgame-header");
        delete header.dataset.wmHomeSubgameTitleMoved;
        delete header.dataset.wmHomeSubgameOriginalTitle;
        delete header.dataset.wmHomeSubgameLastCenterTitle;
      } catch (_e2) {}
    }

    function applyHeader() {
      var header = getHeader();
      if (!header) return;

      if (!isHomeSubgameRoute()) {
        resetHeader(header);
        return;
      }

      header.classList.add("wm-home-subgame-header");

      var left = header.querySelector(".lobby-base-header__section--left");
      var center = header.querySelector(".lobby-base-header__section--center");
      var right = header.querySelector(".lobby-base-header__section--right");

      // Inject logo next to back arrow
      if (left && !left.querySelector(".wm-home-subgame-logo")) {
        var src = detectLogoSrc();
        if (src) {
          var wrap = document.createElement("div");
          wrap.className = "wm-baseheader-logo wm-home-subgame-logo";
          wrap.innerHTML = '<img alt="logo" src="' + src + '">';
          var back = left.querySelector(".lobby-base-header__back");
          if (back && back.parentNode) {
            back.insertAdjacentElement("afterend", wrap);
          } else {
            left.appendChild(wrap);
          }
        }
      }

      // Move/update title to the right section (sem "travar" um valor único)
      if (center && right) {
        var originalTitle = (center.textContent || "").trim();
        if (originalTitle) header.dataset.wmHomeSubgameLastCenterTitle = originalTitle;
        if (!header.dataset.wmHomeSubgameOriginalTitle && originalTitle) header.dataset.wmHomeSubgameOriginalTitle = originalTitle;

        var fixedTitle = getSubgameTitleFallback();
        var desiredTitle = fixedTitle || originalTitle || header.dataset.wmHomeSubgameLastCenterTitle || "Slots";

        right.textContent = desiredTitle;
        right.classList.add("wm-home-subgame-title");
        center.textContent = "";
        center.style.display = "none";
        header.dataset.wmHomeSubgameTitleMoved = "1";
      }
    }

    try { (window.__wmHeaderRouteAppliers = window.__wmHeaderRouteAppliers || []).push(applyHeader); } catch (_e0) {}
    try { if (window.__wmInstallHeaderRouteHooks) window.__wmInstallHeaderRouteHooks(); } catch (_e1) {}
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () { try { applyHeader(); } catch (_e2) {} }, { once: true });
    } else {
      try { applyHeader(); } catch (_e3) {}
    }
  })();

  /* ========================================================== */
  /* /home/setting header (logo next to back) */
  /* ========================================================== */
  (function () {
    function isHomeSettingRoute() {
      try {
        var href = String(location.href || "");
        return href.indexOf("/home/setting") !== -1;
      } catch (_e0) {
        return false;
      }
    }

    function detectLogoSrc() {
      try {
        if (DATA && typeof DATA.logoSrc === "string" && DATA.logoSrc.trim()) return DATA.logoSrc.trim();
      } catch (_e1) {}

      try {
        var img = document.querySelector('img[src^="/uploads/"], img[src*="/uploads/"]');
        if (img) {
          var src = img.getAttribute("src") || "";
          if (src && src.indexOf("/uploads/") !== -1) return src;
        }
      } catch (_e2) {}

      return "";
    }

    function getHeader() {
      return document.querySelector("header.lobby-base-header");
    }

    function resetHeader(header) {
      if (!header) return;
      if (!header.classList.contains("wm-home-setting-header")) return;
      try {
        var left = header.querySelector(".lobby-base-header__section--left");
        if (left) {
          var logo = left.querySelector(".wm-home-setting-logo");
          if (logo && logo.parentNode) logo.parentNode.removeChild(logo);
        }
      } catch (_e0) {}

      try {
        var center = header.querySelector(".lobby-base-header__section--center");
        var right = header.querySelector(".lobby-base-header__section--right");
        if (right) {
          var ttl = right.querySelector(".wm-home-setting-title");
          if (ttl && ttl.parentNode) ttl.parentNode.removeChild(ttl);
          if (header.dataset.wmHomeSettingPrevRightPad !== undefined) {
            right.style.paddingRight = header.dataset.wmHomeSettingPrevRightPad || "";
          }
        }
        if (center) {
          center.style.display = "";
          if (header.dataset.wmHomeSettingOriginalTitle) {
            center.textContent = header.dataset.wmHomeSettingOriginalTitle;
          }
        }
      } catch (_e1) {}

      try {
        header.classList.remove("wm-home-setting-header");
        delete header.dataset.wmHomeSettingTitleMoved;
        delete header.dataset.wmHomeSettingOriginalTitle;
        delete header.dataset.wmHomeSettingPrevRightPad;
      } catch (_e1) {}
    }

    function applyHeader() {
      var header = getHeader();
      if (!header) return;

      if (!isHomeSettingRoute()) {
        resetHeader(header);
        return;
      }

      header.classList.add("wm-home-setting-header");

      var left = header.querySelector(".lobby-base-header__section--left");
      var center = header.querySelector(".lobby-base-header__section--center");
      var right = header.querySelector(".lobby-base-header__section--right");
      if (left && !left.querySelector(".wm-home-setting-logo")) {
        var src = detectLogoSrc();
        if (src) {
          var wrap = document.createElement("div");
          wrap.className = "wm-baseheader-logo wm-home-setting-logo";
          wrap.innerHTML = '<img alt="logo" src="' + src + '">';
          var back = left.querySelector(".lobby-base-header__back");
          if (back && back.parentNode) {
            back.insertAdjacentElement("afterend", wrap);
          } else {
            left.appendChild(wrap);
          }
        }
      }

      // Move title ("Dados") to the right section (keep existing right controls, e.g. "Mudar para PC")
      try {
        if (center && right) {
          var title = (center.textContent || "").trim();
          if (title) header.dataset.wmHomeSettingOriginalTitle = title;

          if (!right.querySelector(".wm-home-setting-title")) {
            var titleEl = document.createElement("div");
            titleEl.className = "wm-home-setting-title";
            titleEl.style.cssText = "margin-right:auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600;";
            titleEl.textContent = title || (header.dataset.wmHomeSettingOriginalTitle || "");
            // Ensure right is flex so title can push other items to the end.
            try {
              var rs = window.getComputedStyle ? window.getComputedStyle(right) : null;
              if (!rs || rs.display !== "flex") right.style.display = "flex";
              right.style.alignItems = "center";
              right.style.minWidth = "0";
              right.style.gap = ".12rem";
              if (header.dataset.wmHomeSettingPrevRightPad === undefined) {
                header.dataset.wmHomeSettingPrevRightPad = right.style.paddingRight || "";
              }
              // Dá respiro no canto direito (título não fica "colado" na borda)
              right.style.paddingRight = ".22rem";
            } catch (_e2) {}
            right.insertBefore(titleEl, right.firstChild || null);
          } else {
            var ex = right.querySelector(".wm-home-setting-title");
            if (ex && title && ex.textContent !== title) ex.textContent = title;
          }

          center.textContent = "";
          center.style.display = "none";
          header.dataset.wmHomeSettingTitleMoved = "1";
        }
      } catch (_e3) {}
    }

    try { (window.__wmHeaderRouteAppliers = window.__wmHeaderRouteAppliers || []).push(applyHeader); } catch (_e0) {}
    try { if (window.__wmInstallHeaderRouteHooks) window.__wmInstallHeaderRouteHooks(); } catch (_e1) {}
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () { try { applyHeader(); } catch (_e2) {} }, { once: true });
    } else {
      try { applyHeader(); } catch (_e3) {}
    }
  })();

  /* ========================================================== */
  /* Affiliate (Promoção / Agent) page: W1 broadcast strip + "Taxa de Comissão" entry */
  /* ========================================================== */
  (function () {
    var BG_MAP = '/assets/images/img_gaogong_tgditu.avif';
    var BG_FIRE = '/assets/images/apng_tg_gonggao_alpha.avif';
    var ICON_CONFETTI = '/assets/images/xyzp_icon_gglq.avif';
    var ICON_COMMISSION = '/assets/images/img_tg_flbl.avif';
    var ICON_SUBLEVEL = '/assets/images/img_tg_zsku.avif';

    var LEVEL_IMGS = [
      '/assets/images/img_tpdl2.avif',
      '/assets/images/img_tpdl.avif',
      '/assets/images/img_ypdl.avif',
      '/assets/images/img_jpdl2.avif',
      '/assets/images/img_jpdl.avif'
    ];

    function isPromotePage() {
      try {
        // evita depender do path exato (SPA). Detecta pelo DOM.
        return !!document.querySelector('[class*="_agent-info_"],[class*="_share-module_"],[class*="_prmote-info_"]');
      } catch (_e0) {
        return false;
      }
    }

    function isPromoteRouteOnly() {
      try {
        var p = (location && typeof location.pathname === 'string') ? String(location.pathname) : '';
        if (/^\/home\/promote\/?$/.test(p)) return true;
        // compat: hash router (#/home/promote)
        var h = (location && typeof location.hash === 'string') ? String(location.hash) : '';
        if (/\/home\/promote\/?/.test(h)) return true;
        return false;
      } catch (_e0) {
        return false;
      }
    }

    function isVisibleEl(el) {
      try {
        if (!el || !el.getClientRects || !el.isConnected) return false;
        var rects = el.getClientRects();
        if (!rects || !rects.length) return false;
        var st = null;
        try { st = window.getComputedStyle ? window.getComputedStyle(el) : null; } catch (_e0) { st = null; }
        if (st && (st.display === 'none' || st.visibility === 'hidden')) return false;
        return true;
      } catch (_e1) {
        return false;
      }
    }

    function findPromoteRoot() {
      try {
        var candidates = document.querySelectorAll('[class*="_prmote-base-layout_"],[class*="_promot-index_"],[class*="promot-index"]');
        for (var i = 0; i < candidates.length; i++) {
          if (isVisibleEl(candidates[i])) return candidates[i];
        }
      } catch (_e0) {}
      return document;
    }

    function findAnchorAfterAgentInfo() {
      try {
        var root = findPromoteRoot();
        var list = root.querySelectorAll('[class*="_agent-info_"],[class*="agent-info"]');
        for (var i = 0; i < list.length; i++) {
          if (isVisibleEl(list[i])) return list[i];
        }
        // fallback (evita null em builds diferentes)
        list = root.querySelectorAll('[class*="_prmote-info_"],[class*="_promote-info_"]');
        for (var j = 0; j < list.length; j++) {
          if (isVisibleEl(list[j])) return list[j];
        }
        return null;
      } catch (_e0) {
        return null;
      }
    }

    function findShareModule() {
      try {
        var root = findPromoteRoot();
        var list = root.querySelectorAll('[class*="_share-module_"],[class*="share-module"]');
        for (var i = 0; i < list.length; i++) {
          if (isVisibleEl(list[i])) return list[i];
        }
        return null;
      } catch (_e0) {
        return null;
      }
    }

    function escapeHtml(s) {
      return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\"/g, "&quot;")
        .replace(/'/g, "&#39;");
    }

    function formatMoney(n) {
      try {
        var v = Number(n);
        if (isFinite(v)) return v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      } catch (_e0) {}
      return String(n || "");
    }

    function buildBroadcastHtml(items) {
      function normalizeItems(list) {
        try {
          var src = Array.isArray(list) ? list.filter(Boolean) : [];
          if (!src.length) return [];
          // Se vier pouco item (ex.: só 1), replica para ficar com cara de "carrossel"
          var out = src.slice();
          while (out.length < 10) out = out.concat(src);
          return out.slice(0, 20);
        } catch (_e0) {
          return Array.isArray(items) ? items : [];
        }
      }

      items = normalizeItems(items);

      var durationSec = 60;
      try {
        // Velocidade mais perceptível no mobile (~6s por item), com limites.
        durationSec = Math.round(items.length * 6);
        if (durationSec < 30) durationSec = 30;
        if (durationSec > 120) durationSec = 120;
      } catch (_e0) {}

      function buildSeq() {
        var html = '';
        for (var i = 0; i < items.length; i++) {
          var it = items[i] || {};
          var levelImg = it.levelImg || LEVEL_IMGS[i % LEVEL_IMGS.length];
          html += ''
            + '<div class="wm-aff-item">'
            +   '<span class="wm-aff-agent-level"><img class="lobby-image lobby-image" src="' + escapeHtml(levelImg) + '" alt="."></span>'
            +   '<div class="wm-aff-text">'
            +     '<p class="wm-aff-account">ID do agente: ' + escapeHtml(it.account || '-') + '</p>'
            +     '<p class="wm-aff-commission">Comissão ganha hoje:<span class="wm-aff-amount">' + escapeHtml(formatMoney(it.commission || 0)) + '</span></p>'
            +   '</div>'
            + '</div>';
        }
        return html;
      }

      var seq = buildSeq();
      return ''
        + '<div id="wm-aff-broadcast" class="wm-aff-broadcast wm-aff-force-anim">'
        +   '<div class="wm-aff-bg-wrap" style="background-image:url(\'' + BG_MAP + '\')">'
        +     '<div class="wm-aff-fire" style="background-image:url(\'' + BG_FIRE + '\')"></div>'
        +   '</div>'
        +   '<img class="wm-aff-confetti lobby-image" src="' + ICON_CONFETTI + '" alt=".">'
        +   '<div class="wm-aff-marquee">'
        +     '<div class="wm-aff-track" style="--wm-aff-duration: ' + durationSec + 's;">'
        +       '<div class="wm-aff-seq">' + seq + '</div>'
        +       '<div class="wm-aff-seq" aria-hidden="true">' + seq + '</div>'
        +     '</div>'
        +   '</div>'
        + '</div>';
    }

    function isLoggedInQuick() {
      try {
        // Cookie padrão do projeto (PHP) + compat com storage do lobby.
        if (typeof document !== 'undefined' && /(?:^|;\\s*)token_user=/.test(String(document.cookie || ''))) return true;
      } catch (_e0) {}
      try {
        var keys = ['token_user', 'web__lobby__persisted__token', 'wm_has_session'];
        for (var i = 0; i < keys.length; i++) {
          var v = null;
          try { v = localStorage.getItem(keys[i]); } catch (_e1) { v = null; }
          if (v && String(v).trim()) return true;
        }
      } catch (_e2) {}
      return false;
    }

    function buildChevronSvg() {
      return ''
        + '<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">'
        +   '<path d="M9 6l6 6-6 6"></path>'
        + '</svg>';
    }

    function buildEnterListHtml(loggedIn) {
      var arrow = buildChevronSvg();
      return ''
        + '<div id="wm-aff-enter-list" class="wm-aff-enter-list' + (loggedIn ? ' wm-aff-enter-list--grid' : '') + '" data-wm-aff-enter-logged="' + (loggedIn ? '1' : '0') + '">'
        +   (loggedIn ? (
              ''
              + '<div class="wm-aff-enter-item wm-aff-enter-item--primary" role="button" tabindex="0" data-wm-aff-action="create-sublevel">'
              +   '<div class="wm-aff-enter-text">'
              +     '<img class="wm-aff-enter-icon lobby-image" src="' + ICON_SUBLEVEL + '" alt=".">'
              +     '<p class="wm-aff-enter-title">Criar subnível</p>'
              +   '</div>'
              +   '<i class="ui-arrow ui-arrow--right wm-aff-enter-arrow" aria-hidden="true">' + arrow + '</i>'
              + '</div>'
            ) : ''
          )
        +   '<div class="wm-aff-enter-item wm-aff-enter-item--accent" role="button" tabindex="0" data-wm-aff-action="commission-rate">'
        +     '<div class="wm-aff-enter-text">'
        +       '<img class="wm-aff-enter-icon lobby-image" src="' + ICON_COMMISSION + '" alt=".">'
        +       '<p class="wm-aff-enter-title">Taxa de Comissão</p>'
        +     '</div>'
        +     '<i class="ui-arrow ui-arrow--right wm-aff-enter-arrow" aria-hidden="true">' + arrow + '</i>'
        +   '</div>'
        + '</div>';
    }

    function defaultItems() {
      // Fallback "W1-like": lista maior para dar cara de carrossel mesmo sem API.
      return [
        { account: '14****638', commission: 154.00 },
        { account: '10****909', commission: 49.94 },
        { account: '37****880', commission: 49.33 },
        { account: '78****384', commission: 47.66 },
        { account: '21****835', commission: 47.46 },
        { account: '46****143', commission: 34.36 },
        { account: '23****285', commission: 31.85 },
        { account: '29****143', commission: 31.81 },
        { account: '69****917', commission: 30.79 },
        { account: '47****966', commission: 29.59 },
        { account: '30****653', commission: 28.36 },
        { account: '60****037', commission: 25.69 },
        { account: '44****176', commission: 25.19 },
        { account: '99****801', commission: 23.64 },
        { account: '39****108', commission: 23.29 }
      ];
    }

    function mergeUniqueByAccount(primary, fallback, max) {
      var seen = Object.create(null);
      var out = [];
      function pushAll(list) {
        for (var i = 0; i < list.length; i++) {
          var it = list[i];
          if (!it) continue;
          var key = String(it.account || '').trim();
          if (!key) continue;
          if (seen[key]) continue;
          seen[key] = 1;
          out.push(it);
          if (max && out.length >= max) return;
        }
      }
      try { pushAll(Array.isArray(primary) ? primary : []); } catch (_e0) {}
      try { pushAll(Array.isArray(fallback) ? fallback : []); } catch (_e1) {}
      return out;
    }

    function tryFetchPublicity(cb) {
      // Se a API existir no seu backend, usa; senão cai no fallback
      try {
        fetch('/api/agent/promote/getPublicityV2', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: '{}'
        }).then(function (r) {
          if (!r || !r.ok) throw new Error('bad');
          return r.json();
        }).then(function (json) {
          // Tentativas de normalização (formato pode variar)
          var data = (json && (json.data || json)) || {};
          var list = data.list || data.items || data.records || data.publicityList || null;
          if (!Array.isArray(list) || !list.length) throw new Error('no-list');

          var out = [];
          for (var i = 0; i < list.length; i++) {
            var it = list[i] || {};
            out.push({
              levelImg: it.levelImg || it.level_icon || it.levelIcon,
              account: it.account || it.agentId || it.platformId || it.id || it.userId,
              commission: it.commission || it.amount || it.todayCommission || it.todayAmount || 0
            });
          }
          cb(out.filter(function (x) { return x && x.account; }).slice(0, 12));
        }).catch(function () {
          cb(null);
        });
      } catch (_e0) {
        cb(null);
      }
    }

    function ensureInjected() {
      try {
        // Em SPA, ao sair/voltar, nodes injetados podem ficar "soltos".
        // Mantemos tudo restrito a /home/promote e reancoramos sempre que necessário.
        if (!isPromoteRouteOnly()) {
          try {
            var b0 = document.getElementById('wm-aff-broadcast');
            if (b0 && b0.parentNode) b0.parentNode.removeChild(b0);
          } catch (_e00) {}
          try {
            var e0 = document.getElementById('wm-aff-enter-list');
            if (e0 && e0.parentNode) e0.parentNode.removeChild(e0);
          } catch (_e01) {}
          return;
        }

        if (!isPromotePage()) return;

        // 1) Broadcast strip
        (function () {
          var anchor = findAnchorAfterAgentInfo();
          var cur = document.getElementById('wm-aff-broadcast');

          // Se o SPA ainda não renderizou o card do agente, não deixa a faixa "flutuando" no topo.
          if (!anchor) {
            try { if (cur && cur.parentNode) cur.parentNode.removeChild(cur); } catch (_e0) {}
            return;
          }

          // Reancora caso tenha sobrado em posição errada (ex.: ao voltar sem F5)
          if (cur && cur.parentNode && anchor.nextElementSibling !== cur) {
            try { anchor.insertAdjacentElement('afterend', cur); } catch (_e1) {}
            return;
          }

          if (!cur && anchor.insertAdjacentHTML) {
            // tenta carregar dados reais, mas injeta já com fallback para não ficar vazio
            anchor.insertAdjacentHTML('afterend', buildBroadcastHtml(defaultItems()));
            tryFetchPublicity(function (items) {
              try {
                if (!items || !items.length) return;
                var cur2 = document.getElementById('wm-aff-broadcast');
                if (!cur2) return;
                // Se a API vier com poucos itens, completa com fallback para ficar "cheio" como a W1.
                var merged = (items.length < 10) ? mergeUniqueByAccount(items, defaultItems(), 20) : items;
                cur2.outerHTML = buildBroadcastHtml(merged);
              } catch (_e2) {}
            });
          }
        })();

        // 2) Enter item (Taxa de Comissão) abaixo do share module
        (function () {
          if (!isPromoteRouteOnly()) {
            try {
              var existing0 = document.getElementById('wm-aff-enter-list');
              if (existing0 && existing0.parentNode) existing0.parentNode.removeChild(existing0);
            } catch (_e0) {}
            return;
          }

          var loggedIn = isLoggedInQuick();
          var existing = document.getElementById('wm-aff-enter-list');
          if (existing) {
            // Se veio de versão antiga (sem marker), recria.
            if (!existing.getAttribute('data-wm-aff-enter-logged')) {
              existing.outerHTML = buildEnterListHtml(loggedIn);
              return;
            }

            var prev = existing.getAttribute('data-wm-aff-enter-logged') || '0';
            var next = loggedIn ? '1' : '0';
            if (prev !== next) {
              existing.outerHTML = buildEnterListHtml(loggedIn);
            }
            return;
          }

          var share = findShareModule();
          var card = null;
          try { card = share && share.closest && share.closest('[class*="_base-card_"]'); } catch (_e2) { card = null; }
          var anchor = card || share;

          // Se a área de share ainda não montou, remove botões soltos e espera o observer chamar de novo.
          if (!anchor) {
            try {
              var existingX = document.getElementById('wm-aff-enter-list');
              if (existingX && existingX.parentNode) existingX.parentNode.removeChild(existingX);
            } catch (_e3) {}
            return;
          }

          // Reancora caso tenha sobrado em posição errada.
          try {
            var existingY = document.getElementById('wm-aff-enter-list');
            if (existingY && existingY.parentNode && anchor.nextElementSibling !== existingY) {
              anchor.insertAdjacentElement('afterend', existingY);
              return;
            }
          } catch (_e4) {}

          if (anchor && anchor.insertAdjacentHTML) {
            anchor.insertAdjacentHTML('afterend', buildEnterListHtml(loggedIn));
          }
        })();
      } catch (_e0) {}
    }

    // Clique: best-effort abrir a seção/tela existente, se houver.
    function onClick(e) {
      try {
        var el = e && (e.target || e.srcElement);
        if (!el) return;
        var btn = el.closest ? el.closest('[data-wm-aff-action]') : null;
        if (!btn) return;
        var action = null;
        try { action = btn.getAttribute('data-wm-aff-action'); } catch (_e0) { action = null; }
        if (!action) return;

        if (action === 'create-sublevel') {
          try { if (e && e.preventDefault) e.preventDefault(); } catch (_e1) {}
          try { if (e && e.stopPropagation) e.stopPropagation(); } catch (_e2) {}
          try { if (e && e.stopImmediatePropagation) e.stopImmediatePropagation(); } catch (_e3) {}
          try { location.href = '/home/promote?active=createAccount'; } catch (_e4) {}
          return;
        }
        // tenta achar qualquer item existente na tela com o mesmo texto e clicar
        try {
          var candidates = document.querySelectorAll('button, a, div, span');
          for (var i = 0; i < candidates.length; i++) {
            var t = (candidates[i].textContent || '').trim();
            if (action === 'commission-rate' && t === 'Taxa de Comissão') {
              candidates[i].click();
              return;
            }
          }
        } catch (_e1) {}
      } catch (_e0) {}
    }

    try { document.addEventListener('click', onClick, true); } catch (_e2) {}

    // Re-aplica em mudanças de rota e quando o DOM montar
    try { (window.__wmHeaderRouteAppliers = window.__wmHeaderRouteAppliers || []).push(ensureInjected); } catch (_e3) {}
    try { if (window.__wmInstallHeaderRouteHooks) window.__wmInstallHeaderRouteHooks(); } catch (_e4) {}

    // Burst extra quando o SPA navega "pra trás/volta" sem mutações visíveis (keep-alive)
    function scheduleBurst() {
      try {
        if (!isPromoteRouteOnly()) return;
        setTimeout(function () { try { ensureInjected(); } catch (_e0) {} }, 60);
        setTimeout(function () { try { ensureInjected(); } catch (_e1) {} }, 320);
        setTimeout(function () { try { ensureInjected(); } catch (_e2) {} }, 900);
        setTimeout(function () { try { ensureInjected(); } catch (_e3) {} }, 1600);
      } catch (_e4) {}
    }
    try { window.addEventListener('popstate', scheduleBurst); } catch (_e5) {}
    try { window.addEventListener('hashchange', scheduleBurst); } catch (_e6) {}

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () { try { ensureInjected(); } catch (_e5) {} }, { once: true });
    } else {
      try { ensureInjected(); } catch (_e6) {}
    }

    // Observa mutações para pegar quando o SPA renderizar os cards
    try {
      if (!window.__wmAffBroadcastObserver) {
        var scheduled = false;
        var obs = new MutationObserver(function () {
          if (scheduled) return;
          scheduled = true;
          setTimeout(function () {
            scheduled = false;
            ensureInjected();
          }, 250);
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
        window.__wmAffBroadcastObserver = obs;
      }
    } catch (_e7) {}
  })();

  /* ========================================================== */
  /* Invite / QR: botão "Clique para Salvar" -> "Salvar código de convite" (W1-like) */
  /* ========================================================== */
  (function () {
    var OLD_TEXT = 'Clique para Salvar';
    // Exibir como na W1 (2 linhas com reticências)
    var NEW_TEXT = 'Salvar\ncódigo de...';

    function norm(s) {
      return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
    }

    function apply(root) {
      try {
        var scope = root && root.querySelectorAll ? root : document;
        var list = scope.querySelectorAll('.ui-button__text');
        for (var i = 0; i < list.length; i++) {
          var el = list[i];
          if (!el) continue;
          var cur = norm(el.textContent);
          if (cur !== norm(OLD_TEXT) && cur.indexOf(norm(OLD_TEXT)) !== 0) continue;

          el.textContent = NEW_TEXT;

          var host = null;
          try { host = el.closest && el.closest('button,[role="button"],.ui-button'); } catch (_e0) { host = null; }
          if (!host) {
            try { host = el.parentElement && el.parentElement.closest && el.parentElement.closest('button,[role="button"],.ui-button'); } catch (_e1) { host = null; }
          }
          if (!host) host = el.parentElement || null;
          try { if (host && host.classList) host.classList.add('wm-invite-save-code'); } catch (_e2) {}
        }
      } catch (_e1) {}
    }

    function install() {
      try { apply(document); } catch (_e0) {}

      try {
        if (window.__wmInviteSaveObserver) return;
        var scheduled = false;
        var obs = new MutationObserver(function (mutList) {
          if (scheduled) return;
          scheduled = true;
          setTimeout(function () {
            scheduled = false;
            try { apply(document); } catch (_e0) {}
            try {
              for (var i = 0; i < mutList.length; i++) {
                var t = mutList[i] && mutList[i].target;
                if (t && t.nodeType === 1) apply(t);
              }
            } catch (_e1) {}
          }, 120);
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
        window.__wmInviteSaveObserver = obs;
      } catch (_e2) {}

      // Re-aplica em mudanças de rota (SPA)
      try { (window.__wmHeaderRouteAppliers = window.__wmHeaderRouteAppliers || []).push(function(){ apply(document); }); } catch (_e3) {}
      try { if (window.__wmInstallHeaderRouteHooks) window.__wmInstallHeaderRouteHooks(); } catch (_e4) {}
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once: true });
    else install();
  })();

  /* ========================================================== */
  /* /home/search page (W1 behavior: start empty + filter dropdown) */
  /* ========================================================== */
  (function () {
    var wmSearchObserverStarted = false;
    var wmSearchApplyScheduled = false;
    var WM_SEARCH_EMPTY_TEXT = 'Sem dados dispon\u00edveis';
    var WM_SEARCH_PLACEHOLDER = 'Insira o conte\u00fado da pesquisa';

    function wmMatches(el, selector) {
      try {
        return !!(el && el.matches && el.matches(selector));
      } catch (_e) {
        return false;
      }
    }

    function wmClosest(el, selector) {
      try {
        var cur = el;
        while (cur) {
          if (cur.nodeType === 1 && wmMatches(cur, selector)) return cur;
          cur = cur.parentElement || cur.parentNode;
          if (cur === document || cur === window) break;
        }
      } catch (_e) {}
      return null;
    }

    var WM_CLOCK_ICON =
      '<svg width="1em" height="1em" viewBox="0 0 36 36" fill="currentColor" aria-hidden="true">' +
        '<path d="M18 1.4A16.6 16.6 0 1 0 34.6 18 16.62 16.62 0 0 0 18 1.4Zm0 30.4A13.8 13.8 0 1 1 31.8 18 13.82 13.82 0 0 1 18 31.8Z"/>' +
        '<path d="M28.1 19.3H18a1.35 1.35 0 0 1-1.35-1.35V6.3A1.35 1.35 0 1 1 19.35 6.3v10.3H28.1a1.35 1.35 0 1 1 0 2.7Z"/>' +
      '</svg>';

    var WM_EMPTY_ICON_URL = '/assets/images/img_none_sj.avif';

    // W1 delete icon: /siteadmin/skin/lobby_asset/common/web/common/comm_icon_del.svg
    var WM_TRASH_ICON =
      '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 21.351 24" aria-hidden="true">' +
        '<g transform="translate(-1946.084 -41.758)">' +
          '<path d="M1966.49,59.525c.1-.085.12-.114.141-.116,1.694-.211,1.694-.21,1.694,1.456q0,5.73,0,11.46c0,2.576-1.283,3.844-3.877,3.844-3.343,0-6.685.007-10.028,0a3.29,3.29,0,0,1-3.528-3.463c-.025-4.3-.007-8.6-.006-12.893,0-.1.019-.207.035-.376h1.8v.85q0,6.049,0,12.1c0,1.486.47,1.954,1.952,1.955q5.014,0,10.027,0c1.277,0,1.787-.492,1.789-1.77q.011-6.128,0-12.256Z" transform="translate(-2.844 -10.413)"></path>' +
          '<path d="M1962.479,44.734h3.736c.623,0,1.234.078,1.22.89-.012.767-.567.919-1.217.918q-9.5-.005-19,0c-.632,0-1.139-.163-1.137-.9s.5-.917,1.135-.914c1.24,0,2.479,0,3.791,0,.019-.313.033-.567.05-.821a2.086,2.086,0,0,1,2.251-2.146c2.279-.016,4.558-.007,6.837,0a2.084,2.084,0,0,1,2.331,2.291C1962.484,44.236,1962.479,44.419,1962.479,44.734Zm-9.559-.065h7.689c.149-1.093.123-1.127-.851-1.128q-2.979,0-5.959,0C1952.811,43.541,1952.811,43.543,1952.92,44.669Z"></path>' +
          '<path d="M1964.983,67.255c0-1.485,0-2.97,0-4.456,0-.552.143-1.01.74-1.162.641-.164,1.084.264,1.092,1.088.015,1.644.005,3.289.005,4.933,0,1.379.009,2.758,0,4.138-.007.786-.369,1.225-.969,1.185-.743-.05-.86-.587-.861-1.19Q1964.982,69.523,1964.983,67.255Z" transform="translate(-11.21 -11.772)"></path>' +
          '<path d="M1977.18,67.343c0,1.484,0,2.968,0,4.453,0,.8-.333,1.236-.932,1.2-.745-.039-.857-.56-.856-1.176.007-3,0-5.99,0-8.985,0-.81.325-1.232.929-1.2.746.038.864.553.859,1.172C1977.173,64.321,1977.18,65.832,1977.18,67.343Z" transform="translate(-17.385 -11.792)"></path>' +
        '</g>' +
      '</svg>';

    function isHomeSearchRoute() {
      try {
        var href = String(location.href || "");
        return href.indexOf("/home/search") !== -1;
      } catch (_e0) {
        return false;
      }
    }

    function getSearchRoot() {
      return document.querySelector('div[class*="_search-main_"]') || null;
    }

    function scheduleApplySearchPage() {
      if (wmSearchApplyScheduled) return;
      wmSearchApplyScheduled = true;
      setTimeout(function () {
        wmSearchApplyScheduled = false;
        applySearchPage();
      }, 16);
    }

    function renderWmEmptyState(text) {
      var wrap = document.createElement('div');
      wrap.className = 'wm-search-empty-state';
      wrap.innerHTML =
        '<div class="wm-search-empty-state__inner">' +
          '<img class="wm-search-empty-state__img" alt="." />' +
          '<div class="wm-search-empty-state__text"></div>' +
        '</div>';
      try { wrap.querySelector('img').setAttribute('src', WM_EMPTY_ICON_URL); } catch (_e0) {}
      wrap.querySelector('.wm-search-empty-state__text').textContent = (text || WM_SEARCH_EMPTY_TEXT);
      return wrap;
    }

    function getSearchBar(root) {
      if (!root) return null;
      return root.querySelector('div[class*="_searchBar_"], div[class*="_search-bar_"]') || null;
    }

    function getSearchInput(root) {
      if (!root) return null;
      return root.querySelector('input.ui-input__input, input[placeholder]') || null;
    }

    function findSearchTab(root) {
      if (!root) return null;
      var tabs = root.querySelectorAll('.ui-tabs__nav .ui-tab');
      for (var i = 0; i < tabs.length; i++) {
        var t = tabs[i];
        var txt = (t.textContent || '').trim();
        if (txt === 'Pesquisar') return t;
      }
      return null;
    }

    function activateSearchTab(root) {
      try {
        var tab = findSearchTab(root);
        if (tab) tab.click();
      } catch (_e) {}
    }

    function patchEmptyText(root) {
      if (!root) return;
      try {
        var nodes = root.querySelectorAll('.ui-empty__text.ui-empty__text--normal, .ui-empty__text');
        for (var i = 0; i < nodes.length; i++) {
          var el = nodes[i];
          var txt = (el.textContent || '').trim();
          if (!txt) continue;
          // Default in our build sometimes shows "Nenhum jogo disponível"
          if (/Nenhum\s+jogo/i.test(txt)) {
            el.textContent = WM_SEARCH_EMPTY_TEXT;
          }
        }
      } catch (_e0) {}

      // Also standardize the empty-state image icon to W1's asset.
      try {
        var empties = root.querySelectorAll('.ui-empty__content img, .ui-empty__image img, img.ui-empty__image, .ui-empty img');
        for (var j = 0; j < empties.length; j++) {
          var img = empties[j];
          if (!img || img.dataset && img.dataset.wmEmptyPatched === '1') continue;
          try { img.dataset.wmEmptyPatched = '1'; } catch (_eMark) {}
          try { img.setAttribute('src', WM_EMPTY_ICON_URL); } catch (_eSet) {}
        }
      } catch (_e1) {}
    }

    function hideTabsHeader(root) {
      if (!root) return;
      try {
        var wrap = root.querySelector('.ui-tabs__wrap');
        if (wrap && !wrap.dataset.wmHidden) {
          wrap.dataset.wmHidden = "1";
          wrap.dataset.wmOriginalDisplay = wrap.style.display || "";
          wrap.style.display = "none";
        }
      } catch (_e0) {}
      try {
        var line = root.querySelector('.ui-tabs__line');
        if (line) line.style.display = "none";
      } catch (_e1) {}
    }

    function showTabsHeader(root) {
      if (!root) return;
      try {
        var wrap = root.querySelector('.ui-tabs__wrap');
        if (wrap && wrap.dataset.wmHidden === "1") {
          wrap.style.display = wrap.dataset.wmOriginalDisplay || "";
          delete wrap.dataset.wmHidden;
          delete wrap.dataset.wmOriginalDisplay;
        }
      } catch (_e0) {}
      try {
        var line = root.querySelector('.ui-tabs__line');
        if (line) line.style.display = "";
      } catch (_e1) {}
    }

    function ensureFilterDropdown(searchBar) {
      if (!searchBar) return;
      var uiInput = searchBar.querySelector('.ui-input');
      if (!uiInput) return;
      var wrap = uiInput.querySelector('.ui-input__input-wrap');
      if (!wrap) return;

      if (wrap.querySelector('.wm-search-filter')) return;

      // Bind a single global outside-click closer to avoid "open/close loop"
      // caused by duplicate per-render listeners.
      if (!window.__wmSearchFilterCloserBound) {
        try { window.__wmSearchFilterCloserBound = true; } catch (_e0) {}
        try { window.__wmSearchOpenFilter = null; } catch (_e1) {}
        try {
          document.addEventListener('pointerdown', function (ev) {
            try {
              var open = window.__wmSearchOpenFilter;
              if (!open || !open.isConnected) { window.__wmSearchOpenFilter = null; return; }
              var t = ev && ev.target ? ev.target : null;
              if (!t) return;
              if (wmClosest(t, '.wm-search-filter') === open) return;
              var btn0 = open.querySelector('.wm-search-filter__btn');
              var menu0 = open.querySelector('.wm-search-filter__menu');
              if (!btn0 || !menu0) { window.__wmSearchOpenFilter = null; return; }
              menu0.hidden = true;
              open.classList.remove('wm-open');
              btn0.setAttribute('aria-expanded', 'false');
              window.__wmSearchOpenFilter = null;
            } catch (_e2) {}
          }, true);
        } catch (_e3) {}
      }

      var filter = document.createElement('div');
      filter.className = 'wm-search-filter';
      try { filter.dataset.value = 'games'; } catch (_e0) {}
      filter.innerHTML =
        '<button type="button" class="wm-search-filter__btn" aria-label="filter" aria-expanded="false">' +
          '<span class="wm-search-filter__label">Jogos</span>' +
          '<i class="ui-select__icon ui-select__icon--arrowBottom ui-select__icon-arrow wm-search-filter__arrow" style="display:inline-flex;justify-content:center;align-items:center">' +
            '<svg width="1em" height="1em" fill="currentColor" class="">' +
              '<use xlink:href="#ui-arrow-418a3a"></use>' +
            '</svg>' +
          '</i>' +
        '</button>' +
        '<div class="wm-search-filter__menu" hidden role="menu">' +
          '<div class="wm-search-filter__item is-active" role="menuitem" aria-selected="true" data-value="games">Jogos</div>' +
          '<div class="wm-search-filter__item" role="menuitem" aria-selected="false" data-value="events">Eventos</div>' +
        '</div>';

      wrap.insertBefore(filter, wrap.firstChild);

      var btn = filter.querySelector('.wm-search-filter__btn');
      var menu = filter.querySelector('.wm-search-filter__menu');
      var label = filter.querySelector('.wm-search-filter__label');

      function closeMenu() {
        try { menu.hidden = true; } catch (_e0) {}
        try { filter.classList.remove('wm-open'); } catch (_e1) {}
        try { btn.setAttribute('aria-expanded', 'false'); } catch (_e2) {}
        try { if (window.__wmSearchOpenFilter === filter) window.__wmSearchOpenFilter = null; } catch (_e3) {}
      }

      function openMenu() {
        try { menu.hidden = false; } catch (_e0) {}
        try { filter.classList.add('wm-open'); } catch (_e1) {}
        try { btn.setAttribute('aria-expanded', 'true'); } catch (_e2) {}
        try { window.__wmSearchOpenFilter = filter; } catch (_e3) {}
      }

      btn.addEventListener('click', function (e) {
        try { e.preventDefault(); } catch (_e0) {}
        try { e.stopImmediatePropagation(); } catch (_e1) {}
        try { e.stopPropagation(); } catch (_e2) {}

        // Close any other open dropdown first.
        try {
          var other = window.__wmSearchOpenFilter;
          if (other && other !== filter && other.isConnected) {
            var btnO = other.querySelector('.wm-search-filter__btn');
            var menuO = other.querySelector('.wm-search-filter__menu');
            if (btnO && menuO) {
              menuO.hidden = true;
              other.classList.remove('wm-open');
              btnO.setAttribute('aria-expanded', 'false');
            }
          }
        } catch (_e3) {}

        if (menu.hidden) openMenu(); else closeMenu();
      });
      btn.addEventListener('pointerdown', function (e) {
        try { e.stopImmediatePropagation(); } catch (_e0) {}
        try { e.stopPropagation(); } catch (_e1) {}
      }, true);
      btn.addEventListener('touchstart', function (e) {
        try { e.stopPropagation(); } catch (_e0) {}
      }, { passive: true });

      menu.addEventListener('pointerdown', function (e) {
        try { e.stopPropagation(); } catch (_e0) {}
      }, true);

      menu.addEventListener('click', function (e) {
        var item = e.target && e.target.closest ? e.target.closest('.wm-search-filter__item') : null;
        if (!item) return;
        try { e.stopPropagation(); } catch (_eStop) {}
        var text = (item.textContent || '').trim();
        label.textContent = text || 'Jogos';
        var v = 'games';
        try { v = item.getAttribute('data-value') || 'games'; } catch (_e0) {}
        try { filter.dataset.value = v; } catch (_e1) {}

        try {
          var items = menu.querySelectorAll('.wm-search-filter__item');
          for (var i = 0; i < items.length; i++) {
            items[i].classList.toggle('is-active', items[i] === item);
            items[i].setAttribute('aria-selected', items[i] === item ? 'true' : 'false');
          }
        } catch (_e2) {}
        closeMenu();
        try {
          setTimeout(function () {
            // Immediately switch proxy behavior to avoid "buggy typing" when toggling.
            var r = getSearchRoot();
            if (r) setGamesProxyEnabled(r, v !== 'events');
            applySearchPage();
          }, 0);
        } catch (_e3) {}
      });
    }

    function ensureResultsContainer(root) {
      if (!root) return null;
      var existing = root.querySelector('.wm-search-results');
      if (existing) return existing;
      var searchBar = getSearchBar(root);
      if (!searchBar) return null;
      var container = document.createElement('div');
      container.className = 'wm-search-results';
      container.style.cssText = 'padding:.18rem .22rem 0;box-sizing:border-box';
      searchBar.insertAdjacentElement('afterend', container);
      return container;
    }

    function clearResults(root) {
      try {
        var c = root && root.querySelector('.wm-search-results');
        if (c) c.innerHTML = '';
      } catch (_e) {}
    }

    function setBuiltInResultsHidden(root, hidden) {
      if (!root) return;
      try {
        var content = root.querySelector('.ui-tabs__content');
        if (!content) return;
        if (hidden) {
          if (content.dataset.wmHidden !== "1") {
            content.dataset.wmHidden = "1";
            content.dataset.wmOriginalDisplay = content.style.display || "";
            content.style.display = "none";
          }
        } else if (content.dataset.wmHidden === "1") {
          content.style.display = content.dataset.wmOriginalDisplay || "";
          delete content.dataset.wmHidden;
          delete content.dataset.wmOriginalDisplay;
        }
      } catch (_e0) {}
    }

    function getFilterType(root) {
      try {
        var filter = root && root.querySelector('.wm-search-filter');
        var type = (filter && filter.dataset && filter.dataset.value) ? String(filter.dataset.value) : 'games';
        return type === 'events' ? 'events' : 'games';
      } catch (_e) {
        return 'games';
      }
    }

    function getEffectiveQuery(root, type) {
      try {
        var proxy = getProxyInput(root);
        var real = null;
        try { real = root && root.querySelector('input.ui-input__input'); } catch (_e0) { real = null; }
        if (type === 'games') {
          // In "Jogos", the proxy input is the source of truth. If it exists,
          // do NOT fall back to the hidden real input value (prevents stale results showing).
          if (proxy) return String(proxy.value || '').trim();
          return String((real && real.value) ? real.value : '').trim();
        }
        // events: prefer the visible input if proxy is still around for some reason
        if (real && real.value && String(real.value).trim()) return String(real.value).trim();
        if (proxy && proxy.value && String(proxy.value).trim()) return String(proxy.value).trim();
        var any = getSearchInput(root);
        return (any && any.value ? String(any.value) : '').trim();
      } catch (_e) {
        return '';
      }
    }

    var wmPromosCache = null;
    var wmPromosPromise = null;
    var wmPromosFetchedAt = 0;

    function normalizeText(v) {
      try {
        var s = String(v || '');
        // Fix common UTF-8 mojibake (e.g. "IndicaÃ§Ã£o" -> "Indicação")
        try { s = decodeURIComponent(escape(s)); } catch (_eFix) {}
        return s
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .toLowerCase()
          .trim();
      } catch (_e) {
        return String(v || '').toLowerCase().trim();
      }
    }

    function fetchPromos() {
      var now = Date.now();
      if (wmPromosCache && (now - wmPromosFetchedAt) < 60000) return Promise.resolve(wmPromosCache);
      if (wmPromosPromise) return wmPromosPromise;
      wmPromosPromise = fetch('/hall/api/active/promocoes', { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (json) {
          if (!(json && json.ok && Array.isArray(json.items))) throw new Error('bad_promos_response');
          wmPromosCache = json.items;
          wmPromosFetchedAt = Date.now();
          return wmPromosCache;
        })
        .catch(function () {
          // Don't cache failures/empty unexpected payloads; allow retry on next search.
          return [];
        })
        .finally(function () {
          wmPromosPromise = null;
        });
      return wmPromosPromise;
    }

    var wmActiveCache = null;
    var wmActivePromise = null;
    var wmActiveFetchedAt = 0;

    function parseActiveListPayload(json) {
      try {
        if (!json) return [];
        if (Array.isArray(json.data)) {
          for (var i = 0; i < json.data.length; i++) {
            if (json.data[i] && Array.isArray(json.data[i].activeList)) return json.data[i].activeList;
          }
        }
        if (json.data && Array.isArray(json.data.activeList)) return json.data.activeList;
      } catch (_e0) {}
      return [];
    }

    function extractPromotionalPicture(imgId) {
      try {
        if (!imgId) return '';
        var obj = JSON.parse(String(imgId));
        return obj && obj.promotional_picture ? String(obj.promotional_picture) : '';
      } catch (_e0) {
        return '';
      }
    }

    function normalizeImgUrl(url) {
      try {
        var u = String(url || '').trim();
        if (!u) return '';
        if (u.indexOf('http://') === 0 || u.indexOf('https://') === 0) return u;
        if (u[0] === '/') return u;
        return '/uploads/' + u;
      } catch (_e0) {
        return '';
      }
    }

    function canonicalImgKey(url) {
      try {
        var u = normalizeImgUrl(url);
        if (!u) return '';
        // Strip query/hash for de-dupe.
        u = u.split('#')[0].split('?')[0];
        // If absolute URL, keep only the path for matching.
        try {
          if (u.indexOf('http://') === 0 || u.indexOf('https://') === 0) {
            var parsed = new URL(u, location.origin);
            u = parsed.pathname || u;
          }
        } catch (_e0) {}
        return String(u).toLowerCase();
      } catch (_e1) {
        return '';
      }
    }

    function fetchActiveCategoryList() {
      var now = Date.now();
      if (wmActiveCache && (now - wmActiveFetchedAt) < 60000) return Promise.resolve(wmActiveCache);
      if (wmActivePromise) return wmActivePromise;
      // Prefer `.json` path so Apache rewrites it consistently (XAMPP setups often only rewrite `.json`).
      // This returns the same payload as POST `/hall/api/active/category` (activeList).
      wmActivePromise = fetch('/hall/api/active/category/active-list.json', { credentials: 'same-origin' })
        .then(function (r) {
          if (!r || !r.ok) throw new Error('active_category_json_not_ok');
          return r.json();
        })
        .then(function (json) {
          var list = parseActiveListPayload(json);
          wmActiveCache = Array.isArray(list) ? list : [];
          wmActiveFetchedAt = Date.now();
          return wmActiveCache;
        })
        .catch(function () {
          // Fallback: try POST route if available.
          return fetch('/hall/api/active/category', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: '{}',
            credentials: 'same-origin'
          })
            .then(function (r) {
              if (!r || !r.ok) throw new Error('active_category_post_not_ok');
              return r.json();
            })
            .then(function (json) {
              var list = parseActiveListPayload(json);
              wmActiveCache = Array.isArray(list) ? list : [];
              wmActiveFetchedAt = Date.now();
              return wmActiveCache;
            })
            .catch(function () { return []; });
        })
        .finally(function () {
          wmActivePromise = null;
        });
      return wmActivePromise;
    }

    function fetchEventsIndex() {
      return Promise.all([fetchPromos(), fetchActiveCategoryList()]).then(function (res) {
        var promos = (res && res[0]) ? res[0] : [];
        var actives = (res && res[1]) ? res[1] : [];

        // Merge items by banner image to allow searching by either name.
        // Example: searching "Baú" (from active/category) should match the
        // corresponding promo (e.g. "Indicação") even if titles differ.
        var groups = Object.create(null);

        function ensureGroup(key) {
          if (!key) return null;
          if (!groups[key]) groups[key] = { key: key };
          return groups[key];
        }

        for (var i = 0; i < promos.length; i++) {
          var p = promos[i] || {};
          if (p.status != null && Number(p.status) === 0) continue;
          var pTitle = String(p.title || p.titulo || '').trim();
          var pImg = normalizeImgUrl(p.imgUrl || p.img_url || '');
          var pKey = canonicalImgKey(pImg) || ('promos:' + String(p.id != null ? p.id : i));
          var gp = ensureGroup(pKey);
          if (!gp) continue;
          gp.promoId = (p.id != null ? p.id : gp.promoId);
          gp.promoTitle = gp.promoTitle || pTitle;
          gp.promoImgUrl = gp.promoImgUrl || pImg;
        }

        for (var j = 0; j < actives.length; j++) {
          var a = actives[j] || {};
          if (a.status != null && Number(a.status) === 0) continue;
          var aTitle = String(a.activeName || a.name || '').trim();
          var aPic = normalizeImgUrl(extractPromotionalPicture(a.imgId));
          var aKey = canonicalImgKey(aPic) || ('active:' + String(a.activeId != null ? a.activeId : j));
          var ga = ensureGroup(aKey);
          if (!ga) continue;
          ga.activeId = (a.activeId != null ? a.activeId : ga.activeId);
          ga.activeName = ga.activeName || aTitle;
          ga.activeImgUrl = ga.activeImgUrl || aPic;
        }

        var out = [];
        var seen = Object.create(null);
        var keys = Object.keys(groups);
        for (var k = 0; k < keys.length; k++) {
          var g = groups[keys[k]];
          var displayTitle = String(g.activeName || g.promoTitle || '').trim();
          if (!displayTitle) continue;
          // Prefer promo image (usually local `/uploads/...`) to avoid external/cert issues.
          var displayImg = String(g.promoImgUrl || g.activeImgUrl || '').trim();
          var id = (g.promoId != null ? g.promoId : (g.activeId != null ? g.activeId : ''));
          var searchText = String([g.activeName || '', g.promoTitle || ''].join(' ')).trim();

          var dedupeKey = normalizeText(displayTitle) + '|' + canonicalImgKey(displayImg) + '|' + String(id);
          if (seen[dedupeKey]) continue;
          seen[dedupeKey] = 1;

          out.push({
            id: id,
            promoId: g.promoId != null ? g.promoId : '',
            activeId: g.activeId != null ? g.activeId : '',
            title: displayTitle,
            imgUrl: displayImg,
            searchText: searchText,
            source: (g.activeName ? 'active' : 'promos')
          });
        }

        return out;
      });
    }

    function hideNonInjectedAfterSearchBar(root, hidden) {
      if (!root) return;
      var bar = getSearchBar(root);
      if (!bar) return;
      try {
        var el = bar.nextElementSibling;
        while (el) {
          var next = el.nextElementSibling;
          var isInjected = el.classList && el.classList.contains('wm-search-results');
          if (!isInjected) {
            if (hidden) {
              if (el.dataset && el.dataset.wmHidden !== "1") {
                el.dataset.wmHidden = "1";
                el.dataset.wmOriginalDisplay = el.style.display || "";
                el.style.display = "none";
              }
            } else if (el.dataset && el.dataset.wmHidden === "1") {
              el.style.display = el.dataset.wmOriginalDisplay || "";
              delete el.dataset.wmHidden;
              delete el.dataset.wmOriginalDisplay;
            }
          }
          el = next;
        }
      } catch (_e0) {}
    }

    // In "Jogos", hide the native history/extra blocks that appear between the search bar and the tabs,
    // but keep the tabs (where results render).
    function hideBetweenSearchBarAndTabs(root, hidden) {
      if (!root) return;
      var bar = getSearchBar(root);
      if (!bar) return;
      try {
        var el = bar.nextElementSibling;
        while (el) {
          if (el.classList && el.classList.contains('ui-tabs')) break;
          if (String(el.className || '').indexOf('ui-tabs') !== -1) break;

          // Never hide our injected blocks.
          if (
            el.classList &&
            (
              el.classList.contains('wm-search-results') ||
              el.classList.contains('wm-search-games-heading') ||
              el.classList.contains('wm-search-games-history') ||
              el.classList.contains('wm-search-games-empty')
            )
          ) {
            el = el.nextElementSibling;
            continue;
          }

          if (hidden) {
            if (el.dataset && el.dataset.wmHidden !== "1") {
              el.dataset.wmHidden = "1";
              el.dataset.wmOriginalDisplay = el.style.display || "";
              el.style.display = "none";
            }
          } else if (el.dataset && el.dataset.wmHidden === "1") {
            el.style.display = el.dataset.wmOriginalDisplay || "";
            delete el.dataset.wmHidden;
            delete el.dataset.wmOriginalDisplay;
          }

          el = el.nextElementSibling;
        }
      } catch (_e0) {}
    }

    function ensureGamesHeading(root, visible) {
      if (!root) return;
      try {
        var existing = root.querySelector('.wm-search-games-heading');
        if (!visible) {
          if (existing) existing.style.display = 'none';
          return;
        }
        if (existing) {
          try {
            var img0 = existing.querySelector('img');
            if (img0) img0.setAttribute('src', '/assets/images/img_ss_yx.avif');
          } catch (_e0) {}
          existing.style.display = '';
          return;
        }

        var content = root.querySelector('.ui-tabs__content');
        if (!content) return;
        var h = document.createElement('section');
        h.className = 'wm-search-games-heading';
        h.style.cssText = 'padding:.18rem .22rem 0;box-sizing:border-box';
        h.innerHTML =
          '<div class="wm-search-heading-row">' +
            '<img class="wm-search-heading-icon" src="/assets/images/img_ss_yx.avif" alt=".">' +
            '<div class="wm-search-heading-text">Jogos</div>' +
          '</div>';
        content.insertAdjacentElement('beforebegin', h);
      } catch (_e) {}
    }

    function removeGamesHeading(root) {
      try {
        var h = root && root.querySelector('.wm-search-games-heading');
        if (h) h.remove();
      } catch (_e) {}
    }

    function loadGamesHistory() {
      try {
        var raw = localStorage.getItem('wm_search_games_history');
        var arr = raw ? JSON.parse(raw) : [];
        if (!Array.isArray(arr)) return [];
        return arr.filter(function (x) { return typeof x === 'string' && x.trim(); }).slice(0, 10);
      } catch (_e) {
        return [];
      }
    }

    function saveGamesHistory(arr) {
      try { localStorage.setItem('wm_search_games_history', JSON.stringify(arr || [])); } catch (_e) {}
    }

    function addGamesHistory(q) {
      var s = (q || '').trim();
      if (!s) return loadGamesHistory();
      var arr = loadGamesHistory();
      arr = arr.filter(function (x) { return normalizeText(x) !== normalizeText(s); });
      arr.unshift(s);
      arr = arr.slice(0, 10);
      saveGamesHistory(arr);
      return arr;
    }

    function removeGamesHistory(q) {
      var arr = loadGamesHistory();
      arr = arr.filter(function (x) { return normalizeText(x) !== normalizeText(q); });
      saveGamesHistory(arr);
      return arr;
    }

    function clearGamesHistory() {
      saveGamesHistory([]);
      return [];
    }

    function ensureGamesHistoryContainer(root) {
      if (!root) return null;
      try {
        var existing = root.querySelector('.wm-search-games-history');
        if (existing) return existing;
        var ref = root.querySelector('.wm-search-games-heading') || root.querySelector('.ui-tabs__content') || null;
        if (!ref) return null;
        var box = document.createElement('div');
        box.className = 'wm-search-games-history';
        box.style.cssText = 'padding:.12rem .22rem 0;box-sizing:border-box';
        ref.insertAdjacentElement('beforebegin', box);
        return box;
      } catch (_e) {
        return null;
      }
    }

    function renderGamesHistory(root) {
      var box = ensureGamesHistoryContainer(root);
      if (!box) return;
      var arr = loadGamesHistory();
      if (!arr.length) {
        box.innerHTML = '';
        box.style.display = 'none';
        return;
      }
      box.style.display = '';
      box.innerHTML =
        '<div class="wm-search-history__row">' +
          '<div class="wm-search-history__title">' +
            '<span class="wm-search-history__icon" aria-hidden="true">' + WM_CLOCK_ICON + '</span>' +
            '<span>Hist\u00f3rico</span>' +
          '</div>' +
          '<button type="button" class="wm-search-history__clear">' +
            '<span class="wm-search-history__trash" aria-hidden="true">' +
              WM_TRASH_ICON +
            '</span>' +
            '<span>Deletar tudo</span>' +
          '</button>' +
        '</div>' +
        '<div class="wm-search-history__chips"></div>';

      var chips = box.querySelector('.wm-search-history__chips');
      arr.forEach(function (txt) {
        var chip = document.createElement('div');
        chip.className = 'wm-search-chip';
        chip.innerHTML =
          '<button type="button" class="wm-search-chip__btn">' +
            '<span class="wm-search-chip__txt"></span>' +
          '</button>' +
          '<button type="button" class="wm-search-chip__x" aria-label="remove">\u00D7</button>';
        chip.querySelector('.wm-search-chip__txt').textContent = txt;
        chip.querySelector('.wm-search-chip__btn').addEventListener('click', function () {
          var px = getProxyInput(root);
          var real = getSearchInput(root);
          if (px) px.value = txt;
          if (real) {
            try { real.value = txt; real.dispatchEvent(new Event('input', { bubbles: true })); } catch (_e0) {}
          }
          try { root.dataset.wmGamesSearched = "1"; } catch (_e1) {}
          ensureGamesHeading(root, true);
          setBuiltInResultsHidden(root, false);
          hideTabsHeader(root);
          setTimeout(function () { triggerBuiltInSearch(root); }, 0);
        });
        chip.querySelector('.wm-search-chip__x').addEventListener('click', function (e) {
          try { e.stopPropagation(); } catch (_e0) {}
          removeGamesHistory(txt);
          renderGamesHistory(root);
        });
        chips.appendChild(chip);
      });

      box.querySelector('.wm-search-history__clear').addEventListener('click', function () {
        clearGamesHistory();
        renderGamesHistory(root);
      });
    }

    function ensureHistoryDelegation(root) {
      if (!root || (root.dataset && root.dataset.wmHistoryDelegation === "1")) return;
      try { root.dataset.wmHistoryDelegation = "1"; } catch (_e0) {}

      function handleHistoryAction(e) {
        var r = getSearchRoot();
        if (!r) return;

        var clearBtn = wmClosest(e.target, '.wm-search-history__clear');
        var removeBtn = wmClosest(e.target, '.wm-search-chip__x');
        if (!clearBtn && !removeBtn) return;

        var inGames = !!wmClosest(e.target, '.wm-search-games-history');
        var inEvents = !!wmClosest(e.target, '.wm-search-results .wm-search-history');
        if (!inGames && !inEvents) return;

        try { e.preventDefault(); } catch (_e0) {}
        try { e.stopImmediatePropagation(); } catch (_e1) {}
        try { e.stopPropagation(); } catch (_e2) {}

        if (inGames) {
          if (clearBtn) {
            clearGamesHistory();
            renderGamesHistory(r);
            return;
          }
          if (removeBtn) {
            var chip = wmClosest(removeBtn, '.wm-search-chip');
            var txt0 = '';
            try {
              var tEl = chip ? chip.querySelector('.wm-search-chip__txt') : null;
              txt0 = (tEl && tEl.textContent) ? String(tEl.textContent).trim() : '';
            } catch (_e3) {}
            if (txt0) removeGamesHistory(txt0);
            renderGamesHistory(r);
            return;
          }
        }

        if (inEvents) {
          var last = (r.dataset && r.dataset.wmEventsLastQuery != null) ? String(r.dataset.wmEventsLastQuery) : '';
          if (clearBtn) {
            clearEventsHistory();
            renderEventsBlock(r, last);
            return;
          }
          if (removeBtn) {
            var chip2 = wmClosest(removeBtn, '.wm-search-chip');
            var txt1 = '';
            try {
              var tEl2 = chip2 ? chip2.querySelector('.wm-search-chip__txt') : null;
              txt1 = (tEl2 && tEl2.textContent) ? String(tEl2.textContent).trim() : '';
            } catch (_e4) {}
            if (txt1) removeEventsHistory(txt1);
            renderEventsBlock(r, last);
            return;
          }
        }
      }

      // Capture early in case something overlays these controls.
      root.addEventListener('pointerdown', handleHistoryAction, true);
      root.addEventListener('click', handleHistoryAction, true);
    }

    function getProxyInput(root) {
      try {
        return root && root.querySelector('input.wm-search-proxy-input');
      } catch (_e) {
        return null;
      }
    }

    function setGamesProxyEnabled(root, enabled) {
      if (!root) return;
      try {
        var real = getSearchInput(root);
        if (!real) return;
        var container = real.parentElement;
        if (!container) return;

        var proxy = getProxyInput(root);

        if (!enabled) {
          if (proxy) proxy.remove();
          if (real.dataset.wmRealHidden === "1") {
            real.style.cssText = real.dataset.wmRealCssText || "";
            delete real.dataset.wmRealHidden;
            delete real.dataset.wmRealCssText;
          }
          return;
        }

        if (proxy) return;

        proxy = document.createElement('input');
        proxy.type = 'text';
        proxy.autocomplete = 'off';
        proxy.spellcheck = false;
        proxy.className = 'wm-search-proxy-input';
        proxy.value = (real.value || '');
        try { proxy.setAttribute('placeholder', real.getAttribute('placeholder') || ''); } catch (_e0) {}

        // Hide real input but keep it in DOM for native search to read on Enter/click.
        if (real.dataset.wmRealHidden !== "1") {
          real.dataset.wmRealHidden = "1";
          real.dataset.wmRealCssText = real.style.cssText || "";
          real.style.cssText = (real.style.cssText || '') + ';position:absolute;opacity:0;pointer-events:none;left:-9999px;';
        }

        container.insertBefore(proxy, real);

      proxy.addEventListener('input', function () {
        // typing should NOT trigger native search; keep heading hidden until Enter/search
        var q = (proxy.value || '').trim();
        if (!q) {
          // Clear the hidden real input too to avoid stale results when switching categories.
          try {
            if (real) {
              real.value = '';
              real.dispatchEvent(new Event('input', { bubbles: true }));
            }
          } catch (_e0) {}
          try { delete root.dataset.wmGamesSearched; } catch (_e1) {}
          ensureGamesHeading(root, false);
          // Hide any previously rendered native results when query is cleared.
          setBuiltInResultsHidden(root, true);
          activateSearchTab(root);
          try {
            var gh = root.querySelector('.wm-search-games-history');
            if (gh) gh.style.display = '';
          } catch (_e2) {}
          ensureGamesEmptyState(root, true);
        }
      }, { passive: true });

        proxy.addEventListener('keydown', function (e) {
          if (!(e && (e.key === 'Enter' || e.keyCode === 13))) return;
          try { e.preventDefault(); } catch (_e00) {}
          try { e.stopPropagation(); } catch (_e01) {}

          var q = (proxy.value || '').trim();
          if (!q) {
            try { delete root.dataset.wmGamesSearched; } catch (_e02) {}
            ensureGamesHeading(root, false);
            try { renderGamesHistory(root); } catch (_eH0) {}
            ensureGamesEmptyState(root, true);
            return;
          }

          // Sync into real input just-in-time and run native search.
          try { real.value = q; } catch (_e03) {}
          try { real.dispatchEvent(new Event('input', { bubbles: true })); } catch (_e04) {}
          try { root.dataset.wmGamesSearched = "1"; } catch (_e05) {}
          ensureGamesHeading(root, true);
          try { addGamesHistory(q); renderGamesHistory(root); } catch (_eH1) {}
          ensureGamesEmptyState(root, false);
          setBuiltInResultsHidden(root, false);
          hideTabsHeader(root);
          // Do NOT force click on "Pesquisar" tab; let native search render where it wants.
          setTimeout(function () { triggerBuiltInSearch(root); }, 0);
        }, true);
      } catch (_e) {}
    }

    function loadEventsHistory() {
      try {
        var raw = localStorage.getItem('wm_search_events_history');
        var arr = raw ? JSON.parse(raw) : [];
        if (!Array.isArray(arr)) return [];
        return arr.filter(function (x) { return typeof x === 'string' && x.trim(); }).slice(0, 10);
      } catch (_e) {
        return [];
      }
    }

    function saveEventsHistory(arr) {
      try { localStorage.setItem('wm_search_events_history', JSON.stringify(arr || [])); } catch (_e) {}
    }

    function addEventsHistory(q) {
      var s = (q || '').trim();
      if (!s) return loadEventsHistory();
      var arr = loadEventsHistory();
      arr = arr.filter(function (x) { return normalizeText(x) !== normalizeText(s); });
      arr.unshift(s);
      arr = arr.slice(0, 10);
      saveEventsHistory(arr);
      return arr;
    }

    function removeEventsHistory(q) {
      var arr = loadEventsHistory();
      arr = arr.filter(function (x) { return normalizeText(x) !== normalizeText(q); });
      saveEventsHistory(arr);
      return arr;
    }

    function clearEventsHistory() {
      saveEventsHistory([]);
      return [];
    }
    function renderEventsBlock(root, query) {
      var c = ensureResultsContainer(root);
      if (!c) return;
      try { root.dataset.wmEventsLastQuery = String(query || '').trim(); } catch (_e0) {}
      c.innerHTML = '';

      var q = (query || '').trim();
      var history = loadEventsHistory();

      // Historico
      if (history.length) {
        var hist = document.createElement('div');
        hist.className = 'wm-search-history';
        hist.innerHTML =
          '<div class="wm-search-history__row">' +
            '<div class="wm-search-history__title">' +
              '<span class="wm-search-history__icon" aria-hidden="true">' + WM_CLOCK_ICON + '</span>' +
              '<span>Hist\u00f3rico</span>' +
            '</div>' +
            '<button type="button" class="wm-search-history__clear">' +
              '<span class="wm-search-history__trash" aria-hidden="true">' +
                WM_TRASH_ICON +
              '</span>' +
              '<span>Deletar tudo</span>' +
            '</button>' +
          '</div>' +
          '<div class="wm-search-history__chips"></div>';

        var chips = hist.querySelector('.wm-search-history__chips');
        history.forEach(function (txt) {
          var chip = document.createElement('div');
          chip.className = 'wm-search-chip';
          chip.innerHTML =
            '<button type="button" class="wm-search-chip__btn">' +
              '<span class="wm-search-chip__txt"></span>' +
            '</button>' +
            '<button type="button" class="wm-search-chip__x" aria-label="remove">\u00D7</button>';
          chip.querySelector('.wm-search-chip__txt').textContent = txt;
          chip.querySelector('.wm-search-chip__btn').addEventListener('click', function () {
            var input = getSearchInput(root);
            if (input) input.value = txt;
            setTimeout(function () { renderEventsBlock(root, txt); }, 0);
          });
          chips.appendChild(chip);
        });
        c.appendChild(hist);
      }

      // Se nao tem query, nao lista eventos ainda (W1 fica vazio)
      if (!q) {
        c.appendChild(renderWmEmptyState(WM_SEARCH_EMPTY_TEXT));
        return;
      }

      // Secao Eventos + cards
      var section = document.createElement('div');
      section.className = 'wm-search-section';
      section.innerHTML = '<div class="wm-search-section__title"><span class="wm-search-section__emoji">\uD83C\uDF81</span> Eventos</div><div class="wm-search-events"></div>';
      var list = section.querySelector('.wm-search-events');
      c.appendChild(section);

      var nq = normalizeText(q);
      fetchEventsIndex().then(function (items) {
        if (!root.isConnected) return;
        list.innerHTML = '';

        var matched = (items || []).filter(function (it) {
          var t = normalizeText(it && (it.searchText || it.title || it.titulo));
          return t && t.indexOf(nq) !== -1;
        });

        if (!matched.length) {
          list.appendChild(renderWmEmptyState(WM_SEARCH_EMPTY_TEXT));
          return;
        }

        matched.forEach(function (it) {
          var imgUrl = (it && (it.imgUrl || it.img_url)) || '';
          var title = (it && (it.title || it.titulo)) || '';
          var id = it && (it.id != null ? it.id : '');
          var promoId = it && (it.promoId != null ? it.promoId : '');

          var card = document.createElement('div');
          card.className = 'wm-event-card';
          card.innerHTML =
            '<div class="wm-event-card__banner"></div>' +
            '<div class="wm-event-card__caption"></div>';
          var banner = card.querySelector('.wm-event-card__banner');
          var cap = card.querySelector('.wm-event-card__caption');

          if (imgUrl) banner.style.backgroundImage = 'url("' + String(imgUrl).replace(/"/g, '%22') + '")';
          cap.textContent = title;

          card.addEventListener('click', function () {
            var url = '/home/event?eventCurrent=1';
            if (promoId !== '') url += '&promoId=' + encodeURIComponent(String(promoId));
            else if (id !== '') url += '&promoId=' + encodeURIComponent(String(id));
            location.href = url;
          });

          list.appendChild(card);
        });
      });
    }

    function ensureGamesEmptyState(root, visible) {
      if (!root) return;
      try {
        var existing = root.querySelector('.wm-search-games-empty');
        if (!visible) {
          if (existing) existing.remove();
          return;
        }

        if (existing) {
          // ensure it has the right content
          var txt = existing.querySelector('.wm-search-empty-state__text');
          if (txt) txt.textContent = 'Sem dados disponíveis';
          return;
        }

        var box = document.createElement('div');
        box.className = 'wm-search-games-empty';
        box.appendChild(renderWmEmptyState('Sem dados disponíveis'));
        root.appendChild(box);
      } catch (_e) {}
    }

    function triggerBuiltInSearch(root) {
      if (!root) return;
      try {
        var icon = root.querySelector('.ui-input__suffix-icon, .ui-input__suffix, [class*="_searchIcon_"]');
        if (icon) {
          icon.click();
          return;
        }
      } catch (_e0) {}
    }

    function applySearchPage() {
      var onRoute = isHomeSearchRoute();
      var root = getSearchRoot();

      try {
        if (onRoute) document.documentElement.classList.add('wm-home-search-route');
        else document.documentElement.classList.remove('wm-home-search-route');
      } catch (_e0) {}
      try {
        if (!onRoute) {
          document.documentElement.classList.remove('wm-home-search-ready');
          document.documentElement.classList.remove('wm-search-mode-events');
          document.documentElement.classList.remove('wm-search-mode-games');
        }
      } catch (_e00) {}

      if (!root) return;

      if (root && root.dataset && root.dataset.wmSearchApplying === "1") return;
      try { root.dataset.wmSearchApplying = "1"; } catch (_eGuard0) {}

      ensureHistoryDelegation(root);

      function cleanupInjected() {
        try {
          var allResults = document.querySelectorAll('.wm-search-results');
          for (var i = 0; i < allResults.length; i++) {
            if (!root.contains(allResults[i])) allResults[i].remove();
          }
        } catch (_eC0) {}
        try {
          var allHead = document.querySelectorAll('.wm-search-games-heading');
          for (var j = 0; j < allHead.length; j++) {
            if (!root.contains(allHead[j])) allHead[j].remove();
          }
        } catch (_eC1) {}
        try {
          var allHist = document.querySelectorAll('.wm-search-games-history');
          for (var h = 0; h < allHist.length; h++) {
            if (!root.contains(allHist[h])) allHist[h].remove();
          }
        } catch (_eC1b) {}
        try {
          var inner = root.querySelectorAll('.wm-search-results');
          for (var k = 1; k < inner.length; k++) inner[k].remove();
        } catch (_eC2) {}
      }

      cleanupInjected();

      if (!onRoute) {
        showTabsHeader(root);
        setBuiltInResultsHidden(root, false);
        hideNonInjectedAfterSearchBar(root, false);
        hideBetweenSearchBarAndTabs(root, false);
        removeGamesHeading(root);
        try {
          var gh0 = root.querySelector('.wm-search-games-history');
          if (gh0) gh0.remove();
        } catch (_eH0) {}
        try { delete root.dataset.wmGamesSearched; } catch (_e0) {}
        try {
          var injected = root.querySelector('.wm-search-filter');
          if (injected) injected.remove();
        } catch (_e1) {}
          try {
          var injectedResults = root.querySelector('.wm-search-results');
          if (injectedResults) injectedResults.remove();
        } catch (_e1b) {}
        try {
          var input0 = getSearchInput(root);
          if (input0 && input0.dataset.wmSearchPlaceholder != null) {
            input0.setAttribute('placeholder', input0.dataset.wmSearchPlaceholder);
            delete input0.dataset.wmSearchPlaceholder;
          }
        } catch (_e2) {}
        try { delete root.dataset.wmSearchApplying; } catch (_eGuard1) {}
        return;
      }

      var searchBar = getSearchBar(root);
      ensureFilterDropdown(searchBar);

      var input = getSearchInput(root);
      if (input) {
        if (!input.dataset.wmSearchPlaceholder) {
          input.dataset.wmSearchPlaceholder = input.getAttribute('placeholder') || '';
          input.setAttribute('placeholder', WM_SEARCH_PLACEHOLDER);
        }
        if (!input.dataset.wmSearchHooked) {
          input.dataset.wmSearchHooked = '1';
          input.addEventListener('input', function (e) {
            var r = getSearchRoot();
            if (!r) return;
            if (getFilterType(r) !== 'events') return;
            try { e.preventDefault(); } catch (_e0) {}
            try { e.stopImmediatePropagation(); } catch (_e1) {}
            try { e.stopPropagation(); } catch (_e2) {}
            setBuiltInResultsHidden(r, true);
          }, true);
          input.addEventListener('input', function () {
            var r = getSearchRoot();
            if (!r) return;
            if (getFilterType(r) !== 'games') return;
            var q0 = (input.value || '').trim();
            if (!q0) {
              try { delete r.dataset.wmGamesSearched; } catch (_e0) {}
              ensureGamesHeading(r, false);
            }
          }, { passive: true });
          input.addEventListener('keydown', function (e) {
            if (e && (e.key === 'Enter' || e.keyCode === 13)) {
              var r = getSearchRoot();
              if (!r) return;
              var type = getFilterType(r);
              var q = getEffectiveQuery(r, type);

              if (type === 'events') {
                try { e.preventDefault(); } catch (_e00) {}
                try { e.stopImmediatePropagation(); } catch (_e01) {}
                try { e.stopPropagation(); } catch (_e02) {}
                setBuiltInResultsHidden(r, true);
                try { r.dataset.wmEventsMode = "1"; } catch (_eSet0) {}
                if (!q) {
                  clearResults(r);
                  hideTabsHeader(r);
                  activateSearchTab(r);
                  renderEventsBlock(r, '');
                  return;
                }
                hideTabsHeader(r);
                activateSearchTab(r);
                addEventsHistory(q);
                renderEventsBlock(r, q);
                return;
              }

              // default: games
              setBuiltInResultsHidden(r, false);
              clearResults(r);
              hideTabsHeader(r);
              if (!q) {
                try { delete r.dataset.wmGamesSearched; } catch (_e0) {}
                ensureGamesHeading(r, false);
                try { renderGamesHistory(r); } catch (_eH0) {}
                return;
              }
              try { r.dataset.wmGamesSearched = "1"; } catch (_e1) {}
              ensureGamesHeading(r, true);
              try { addGamesHistory(q); renderGamesHistory(r); } catch (_eH1) {}
              setTimeout(function () { triggerBuiltInSearch(r); }, 0);
            }
          });
        }
      }

      if (!root.dataset.wmSearchIconHooked) {
        root.dataset.wmSearchIconHooked = '1';
        root.addEventListener('click', function (e) {
          var r = getSearchRoot();
          if (!r) return;
          var icon = null;
          try {
            icon = wmClosest(e.target, '.ui-input__suffix-icon, .ui-input__suffix, [class*="_searchIcon_"]');
          } catch (_e0) { icon = null; }
          if (!icon) return;
          var t = getFilterType(r);
        if (t === 'games') {
            var px = getProxyInput(r);
            var inp0 = getSearchInput(r);
            var q0 = (px && px.value ? String(px.value) : (inp0 && inp0.value ? String(inp0.value) : '')).trim();
            if (!q0) {
              try { delete r.dataset.wmGamesSearched; } catch (_e00) {}
              ensureGamesHeading(r, false);
              try { renderGamesHistory(r); } catch (_eH0) {}
              setBuiltInResultsHidden(r, true);
              activateSearchTab(r);
              ensureGamesEmptyState(r, true);
              return;
            }
            try { if (inp0) { inp0.value = q0; inp0.dispatchEvent(new Event('input', { bubbles: true })); } } catch (_eSync) {}
            try { r.dataset.wmGamesSearched = "1"; } catch (_e01) {}
            ensureGamesHeading(r, true);
            try { addGamesHistory(q0); renderGamesHistory(r); } catch (_eH1) {}
            ensureGamesEmptyState(r, false);
            scheduleApplySearchPage();
            return; // let the native click handler run the search
          }
          if (t !== 'events') return;
          try { e.preventDefault(); } catch (_e1) {}
          try { e.stopImmediatePropagation(); } catch (_e2) {}
          try { e.stopPropagation(); } catch (_e3) {}

          setBuiltInResultsHidden(r, true);
          hideTabsHeader(r);
          activateSearchTab(r);
          try { r.dataset.wmEventsMode = "1"; } catch (_eSet0) {}

          var q = getEffectiveQuery(r, 'events');
          if (q) addEventsHistory(q);
          renderEventsBlock(r, q);
        }, true);
      }

      // Hide the "Popular/Recentes/Favoritos" tabs header and default to the empty "Pesquisar" panel.
      hideTabsHeader(root);
      var tNow = getFilterType(root);
      try {
        document.documentElement.classList.toggle('wm-search-mode-events', tNow === 'events');
        document.documentElement.classList.toggle('wm-search-mode-games', tNow !== 'events');
      } catch (_eMode) {}
      setBuiltInResultsHidden(root, tNow === 'events');
      patchEmptyText(root);
      if (tNow === 'events') {
        removeGamesHeading(root);
        try {
          var ge0 = root.querySelector('.wm-search-games-empty');
          if (ge0) ge0.remove();
        } catch (_eGE0) {}
        try { delete root.dataset.wmGamesSearched; } catch (_e00) {}
        try {
          var gh1 = root.querySelector('.wm-search-games-history');
          if (gh1) gh1.remove();
        } catch (_eH1) {}
        setGamesProxyEnabled(root, false);
        // Keep search tab active to stay on the empty panel.
        activateSearchTab(root);
        hideNonInjectedAfterSearchBar(root, true);
        hideBetweenSearchBarAndTabs(root, true);
        try {
          // Avoid re-render loops: only render the initial block once per route entry/filter switch.
          if (root.dataset.wmEventsMode !== "1") {
            root.dataset.wmEventsMode = "1";
            root.dataset.wmEventsLastQuery = "";
            renderEventsBlock(root, '');
          } else {
            // Keep the last rendered query; don't rebuild on every DOM mutation.
            var last = (root.dataset.wmEventsLastQuery != null) ? String(root.dataset.wmEventsLastQuery) : "";
            var hasContainer = !!root.querySelector('.wm-search-results');
            if (!hasContainer) renderEventsBlock(root, last);
          }
        } catch (_e0) {}
      } else {
        hideNonInjectedAfterSearchBar(root, false);
        hideBetweenSearchBarAndTabs(root, true);
        setGamesProxyEnabled(root, true);
        // If query is empty, always treat as "not searched" (even if some native clear button didn't touch our dataset).
        try {
          var qNow = getEffectiveQuery(root, 'games');
          if (!qNow) delete root.dataset.wmGamesSearched;
        } catch (_eQNow) {}
        // Only force the empty panel when no search was executed yet.
        if (root.dataset.wmGamesSearched !== "1") {
          // W1 behavior: start empty (no native game cards visible until user searches).
          setBuiltInResultsHidden(root, true);
          activateSearchTab(root);
          ensureGamesEmptyState(root, true);
        } else {
          setBuiltInResultsHidden(root, false);
          ensureGamesEmptyState(root, false);
        }
        ensureGamesHeading(root, root.dataset.wmGamesSearched === "1");
        try { renderGamesHistory(root); } catch (_eH2) {}
        try {
          var injectedResults0 = root.querySelector('.wm-search-results');
          if (injectedResults0) injectedResults0.remove();
        } catch (_e1) {}
        try { delete root.dataset.wmEventsMode; } catch (_e2) {}
      }

      try { document.documentElement.classList.add('wm-home-search-ready'); } catch (_eReady) {}
      try { delete root.dataset.wmSearchApplying; } catch (_eGuard2) {}
    }

    function hookHistory() {
      try {
        var push = history.pushState;
        var replace = history.replaceState;
        history.pushState = function () {
          var ret = push.apply(this, arguments);
          scheduleApplySearchPage();
          return ret;
        };
        history.replaceState = function () {
          var ret = replace.apply(this, arguments);
          scheduleApplySearchPage();
          return ret;
        };
        window.addEventListener('popstate', function () { scheduleApplySearchPage(); }, { passive: true });
        window.addEventListener('hashchange', function () { scheduleApplySearchPage(); }, { passive: true });
      } catch (_e) {}
    }

    function observeDom() {
      if (wmSearchObserverStarted) return;
      wmSearchObserverStarted = true;
      try {
        var mo = new MutationObserver(function () {
          scheduleApplySearchPage();
        });
        mo.observe(document.documentElement, { childList: true, subtree: true });
      } catch (_e) {}
    }

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () {
        hookHistory();
        observeDom();
        applySearchPage();
      }, { once: true });
    } else {
      hookHistory();
      observeDom();
      applySearchPage();
    }
  })();

  /* ========================================================== */
  /* MENU NAVBAR / marketing box */
  /* ========================================================== */
  try{
    document.documentElement.style.setProperty('--marketing-box-display', FLAGS.menuNavbar ? 'block' : 'none');
  }catch(_e0){}
  if (FLAGS.menuNavbar) {
           const MARKETING_BOX_CONFIG = {
               enabled: true,
               items: [
                  {
                      id: 'promocao',
                      title: 'Promoção',
                      icon: '/assets/images/icon_tgzq1.avif',
                      route: '/home/event?eventCurrent=1'
                  },
                  {
                      id: 'recompensas',
                      title: 'Recompensas',
                      icon: '/assets/images/icon_dlq1.avif',
                      route: '/home/canReceive'
                  },
                  {
                      id: 'juros',
                      title: 'Juros',
                      icon: '/assets/images/icon_lxb1.avif',
                      route: '/home/yuebao'
                  },
                  {
                      id: 'rebate',
                      title: 'Rebate',
                      icon: '/assets/images/icon_ssfs1.avif',
                      route: '/home/cashback'
                  },
                  {
                      id: 'vip',
                      title: 'VIP',
                      icon: '/assets/images/icon_vip1.avif',
                      route: '/home/vip'
                  }
              ]
          };
      
          function createMarketingBox() {
              if (!MARKETING_BOX_CONFIG.enabled) return null;
      
              const marketingBox = document.createElement('div');
              marketingBox.className = '_marketing-box_10kxy_33';
              marketingBox.id = 'marketing-box';
      
              const mainContainer = document.createElement('div');
              mainContainer.className = '_main_1sqbq_44';
              mainContainer.setAttribute('data-length', String(MARKETING_BOX_CONFIG.items.length));
      
              MARKETING_BOX_CONFIG.items.forEach(item => {
                  const itemElement = document.createElement('div');
                  itemElement.className = '_marketing-item_tnolq_68';
                  itemElement.setAttribute('data-marketing', item.id);
                  itemElement.style.cursor = 'pointer';
      
                  const iconElement = document.createElement('img');
                  iconElement.className = '_marketing-bg_tnolq_77';
                  iconElement.src = item.icon;
                  iconElement.alt = item.title;
                  iconElement.loading = 'lazy';
      
                  const titleElement = document.createElement('div');
                  titleElement.className = '_marketing-title_tnolq_118';
                  const titleText = document.createElement('p');
                  titleText.textContent = item.title;
                  titleElement.appendChild(titleText);
      
                  itemElement.appendChild(iconElement);
                  itemElement.appendChild(titleElement);
      
                  itemElement.addEventListener('click', () => {
                      handleMarketingClick(item);
                  });
      
                  mainContainer.appendChild(itemElement);
              });
      
              marketingBox.appendChild(mainContainer);
              return marketingBox;
          }
      
          function handleMarketingClick(item) {
              sessionStorage.setItem('activeMarketingItem', item.id);
              
              if (item.route) {
                  window.location.href = item.route;
              }
          }
      
          function injectMarketingBox() {
              if (!MARKETING_BOX_CONFIG.enabled) return;
      
              const targetSelector = '._banner-container_1xtky_30';
              const target = document.querySelector(targetSelector);
              
              if (target && !document.getElementById('marketing-box')) {
                  const marketingBox = createMarketingBox();
                  if (marketingBox) {
                      target.parentNode.insertBefore(marketingBox, target);
                  }
              }
          }
      
          function toggleMarketingBox(enabled) {
              MARKETING_BOX_CONFIG.enabled = enabled;
              const existingBox = document.getElementById('marketing-box');
              
              if (enabled && !existingBox) {
                  injectMarketingBox();
              } else if (!enabled && existingBox) {
                  existingBox.remove();
              }
              
              document.documentElement.style.setProperty('--marketing-box-enabled', enabled ? '1' : '0');
          }
      
          function isMarketingBoxEnabled() {
              return MARKETING_BOX_CONFIG.enabled;
          }
      
          function attemptInjection() {
              let attempts = 0;
              const maxAttempts = 50;
              
              const tryInject = () => {
                  attempts++;
                  if (attempts > maxAttempts) {
                      return;
                  }
                  
                  const target = document.querySelector('._banner-container_1xtky_30');
                  if (target) {
                      injectMarketingBox();
                  } else {
                      setTimeout(tryInject, 100);
                  }
              };
              
              tryInject();
          }
      
          if (document.readyState === 'loading') {
              document.addEventListener('DOMContentLoaded', attemptInjection);
          } else {
              attemptInjection();
          }
      
          const observer = new MutationObserver((mutations) => {
              mutations.forEach((mutation) => {
                  if (mutation.type === 'childList') {
                      const target = document.querySelector('._banner-container_1xtky_30');
                      if (target && !document.getElementById('marketing-box')) {
                          injectMarketingBox();
                      }
                  }
              });
          });
      
          observer.observe(document.body, {
              childList: true,
              subtree: true
          });
  }

  /* ========================================================== */
  /* EVENT page tweaks */
  /* ========================================================== */
      (function() {
          'use strict';
  
          function isEventCurrentPage() {
              try {
                  var url = new URL(window.location.href);
                  return url.pathname === '/home/event' && url.searchParams.get('eventCurrent') === '1';
              } catch (_) {
                  return false;
              }
          }
  
          function hasRenderableEventImage(card) {
              if (!card) return false;
  
              var candidates = card.querySelectorAll(
                  '.onePic, .item-backgroud-img, [class*="_background_"], [class*="_icon_"], img, [style*="background-image"]'
              );
  
              for (var i = 0; i < candidates.length; i++) {
                  var node = candidates[i];
                  if (!node) continue;
  
                  if (node.tagName === 'IMG') {
                      var src = (node.getAttribute('src') || '').trim();
                      if (src && !/^(data:|about:blank)$/i.test(src)) return true;
                  }
  
                  var bg = '';
                  try {
                      bg = window.getComputedStyle(node).backgroundImage || '';
                  } catch (_) {}
                  if (bg && bg !== 'none') return true;
              }
  
              return false;
          }
  
          function cleanupInvalidEventCards() {
              if (!isEventCurrentPage()) return;
  
              var cards = document.querySelectorAll('[class*="_event-list-item_"], .eventListItem');
              cards.forEach(function(card) {
                  if (hasRenderableEventImage(card)) {
                      card.style.display = '';
                      return;
                  }
  
                  card.style.display = 'none';
              });
          }
  
          cleanupInvalidEventCards();
  
          new MutationObserver(function() {
              cleanupInvalidEventCards();
          }).observe(document.documentElement, {
              childList: true,
              subtree: true,
              attributes: true,
              attributeFilter: ['class', 'style', 'src']
          });
  
          window.addEventListener('popstate', function() {
              setTimeout(cleanupInvalidEventCards, 80);
          });
      })();

  /* ========================================================== */
  /* EFEITO NATALINO */
  /* ========================================================== */
  if (FLAGS.efeitoNatal) {
      document.addEventListener('DOMContentLoaded', function() {
          function injectChristmasEffect() {
  
              const path = window.location.pathname;
              const normalizedPath = path.endsWith('/') && path.length > 1 ? path.slice(0, -1) : path;
              
              const homePaths = ['', '/', '/index.php', '/home'];
              const tabAllowedPaths = [
                  '/home/event', 
                  '/home/mine', 
                  '/home/canReceive', 
                  '/home/yuebao', 
                  '/home/cashback', 
                  '/home/vip',
                  '/home/records',
                  '/home/task'
              ];
              
              const isHome = homePaths.includes(normalizedPath);
              const isTabAllowed = isHome || tabAllowedPaths.includes(normalizedPath);
  
              if (!isTabAllowed) {
                  document.querySelectorAll('.gameHotHoliday, .christmas-header-effect, .tabbar-festival-box').forEach(el => el.remove());
                  return;
              }
  
              if (!isHome) {
                   document.querySelectorAll('.gameHotHoliday, .christmas-header-effect').forEach(el => el.remove());
              }
  
              if (isHome && !document.querySelector('.gameHotHoliday')) {
                  let titleContainer = document.querySelector('div[class*="_title_"]');
                  
                  if (!titleContainer) {
                       const titles = document.querySelectorAll('div');
                       for (let t of titles) {
                           if (t.textContent.trim() === 'Popular' && t.className.includes('_title_')) {
                               titleContainer = t;
                               break;
                           }
                       }
                  }
                  
                   if (!titleContainer) {
                       const elements = document.querySelectorAll('*');
                       for (let el of elements) {
                           if (el.textContent.trim() === 'Popular' && el.className.includes('title')) {
                               titleContainer = el.closest('[class*="title"]') || el;
                               break;
                           }
                       }
                  }
  
                  if (titleContainer && titleContainer.parentNode) {
                      const parentStyle = window.getComputedStyle(titleContainer.parentNode);
                      if (parentStyle.position === 'static') {
                          titleContainer.parentNode.style.position = 'relative';
                      }
  
                      const natalDiv = document.createElement('div');
                      natalDiv.className = '_holiday_tumws_45 gameHotHoliday holidayMobile';
                      
                      natalDiv.style.position = 'absolute';
                      natalDiv.style.left = '50%';
                      natalDiv.style.top = '50%';
                      natalDiv.style.transform = 'translate(-50%, -50%)';
                      natalDiv.style.zIndex = '10';
                      
                      natalDiv.style.display = 'flex';
                      natalDiv.style.alignItems = 'center';
                      natalDiv.innerHTML = '<img class="lobby-image lobby-image" data-load-strategy="loading-set@1:lazy@1" data-status="success" data-thumb="0" data-id="807d23be-393e-4ba9-af30-e9bc81c4533c" src="/assets/images/apng_top_jr.avif" alt="." style="width: 2.13rem; height: 0.84rem; display: block;">';
                      
                      titleContainer.parentNode.appendChild(natalDiv);
                  }
              }
  
              const header = document.querySelector('.lobby-home-header-container') || document.querySelector('[class*="header-container"]');
              if (isHome && header) {
                  const hStyle = window.getComputedStyle(header);
                  if (hStyle.position === 'static') {
                      header.style.position = 'relative';
                  }
                  
                  if (!header.querySelector('.christmas-header-effect')) {
                      const effectDiv = document.createElement('div');
                      effectDiv.className = 'christmas-header-effect';
                      effectDiv.style.position = 'absolute';
                      effectDiv.style.top = '0';
                      effectDiv.style.left = '0';
                      effectDiv.style.width = '100%';
                      effectDiv.style.height = '100%';
                      effectDiv.style.zIndex = '0';
                      effectDiv.style.pointerEvents = 'none';
  
                      effectDiv.innerHTML = `
                          <!-- Background Pattern -->
                          <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: url('/assets/images/bg_pattern_tile2.png'); background-size: 1.8rem 1.8rem; background-repeat: repeat-x;"></div>
                          
                          <!-- Decorações Penduradas (Esquerda, Centro, Direita) -->
                          <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; justify-content: space-between; align-items: flex-start;">
                              <img src="/assets/images/h5_zs_jr.avif" style="height: 100%; object-fit: contain;">
                              <img src="/assets/images/h5_zs_jr3.avif" style="height: 100%; flex-grow: 1; object-fit: fill;">
                              <img src="/assets/images/h5_zs_jr2.avif" style="height: 100%; object-fit: contain;">
                          </div>
                      `;
                      
                       header.insertBefore(effectDiv, header.firstChild);
                   }
               }
  
               let tabContainer = document.querySelector('._tabbar_gtdvm_34') || 
                                  document.querySelector('div[class*="ui-tabs"][class*="_tabbar_"]') ||
                                  document.querySelector('div[class*="ui-tabs__wrap"]');
               
               if (!tabContainer) {
                    tabContainer = document.querySelector('.ui-tabbar') || document.querySelector('[role="tablist"]') || document.querySelector('.ui-tabs__nav');
               }
               
               if (tabContainer) {
                   const tStyle = window.getComputedStyle(tabContainer);
                   if (tStyle.position === 'static') {
                       tabContainer.style.position = 'relative';
                   }
                   
                   if (!tabContainer.querySelector('.tabbar-festival-box')) {
                       const festivalBox = document.createElement('div');
                       festivalBox.className = '_normalBg_1kn67_131 _nationalBg_1kn67_46 tabbar-festival-box';
                       festivalBox.style.position = 'absolute';
                       festivalBox.style.top = '0';
                       festivalBox.style.left = '0';
                       festivalBox.style.width = '100%';
                       festivalBox.style.height = '100%';
                       festivalBox.style.pointerEvents = 'none';
                       festivalBox.style.zIndex = '0';
                       festivalBox.style.display = 'flex';
                       festivalBox.style.justifyContent = 'space-between';
                       festivalBox.style.alignItems = 'stretch';
                       festivalBox.style.overflow = 'hidden';
                       
                       festivalBox.innerHTML = `
                          <img class="lobby-image lobby-image _normalBgLeft_1kn67_131 _nationalLeft_1kn67_55" data-load-strategy="loading-set@1:lazy@1" data-status="success" data-thumb="0" data-id="a205197b-7743-4a60-a5b6-ce078e97ab9f" src="/assets/images/icon_btm_jr.avif" alt="." style="height: 100%; display: block; object-fit: contain;">
                          <img class="lobby-image lobby-image _longScreenBg_1kn67_142" data-load-strategy="loading-set@1:lazy@1" data-status="success" data-thumb="0" data-id="98a96ddf-4994-4507-a3a4-54307e7f7faf" src="/assets/images/icon_btm_jr3.avif" alt="." style="height: 100%; flex-grow: 1; object-fit: fill; display: block;">
                          <img class="lobby-image lobby-image _normalBgRight_1kn67_136 _nationalRight_1kn67_60" data-load-strategy="loading-set@1:lazy@1" data-status="success" data-thumb="0" data-id="7355bec6-5a0c-4357-babd-6a1603e43413" src="/assets/images/icon_btm_jr2.avif" alt="." style="height: 100%; display: block; object-fit: contain;">
                       `;
      
                       tabContainer.insertBefore(festivalBox, tabContainer.firstChild);
                   }
               }
  
               const sidebarItems = document.querySelectorAll('div[class*="_sidebar-common-tab-item_"]');
               const cashbackItems = document.querySelectorAll('div[class*="_cashback-tab-item_"]');
               
               const allNavItems = [...sidebarItems, ...cashbackItems];
               
               allNavItems.forEach(item => {
                   if (item.querySelector('.normal-holiday-wrap')) return;
                   
                   const iStyle = window.getComputedStyle(item);
                   if (iStyle.position === 'static') {
                       item.style.position = 'relative';
                   }
                   
                   const wrap = document.createElement('div');
                   wrap.className = '_holiday-wrap_13eho_45 normal-holiday-wrap';
                   wrap.style.position = 'absolute';
                   wrap.style.top = '0';
                   wrap.style.left = '0';
                   wrap.style.width = '100%';
                   wrap.style.height = '100%';
                   wrap.style.pointerEvents = 'none';
                   wrap.style.zIndex = '5';
                   
                   wrap.innerHTML = `
                      <img class="lobby-image lobby-image _rightBottom_13eho_74" src="/assets/images/btn_zc1_jr2.avif" alt="." style="width: 0.5rem; height: 0.5rem; position: absolute; bottom: 0; right: 0; display: block;">
                      <img class="lobby-image lobby-image _topLeft_13eho_56" src="/assets/images/btn_zc1_jr.avif" alt="." style="width: 0.5rem; height: 0.5rem; position: absolute; top: 0; left: 0; display: block;">
                   `;
                   
                   item.appendChild(wrap);
               });
          }
  
          setTimeout(injectChristmasEffect, 1000);
          injectChristmasEffect();
  
          const observer = new MutationObserver((mutations) => {
              injectChristmasEffect();
          });
  
          observer.observe(document.body, {
              childList: true,
              subtree: true
          });
      });
  }

  /* ========================================================== */
  /* RECORDE DE GANHOS */
  /* ========================================================== */
  if (FLAGS.recordeGanhos) {
      function genRecords(count){
          const banners = [
              '/uploads/tema1.png',
              '/uploads/tema2.png',
              '/uploads/tema3.png',
              '/uploads/tema4.png',
              '/uploads/tema5.png',
              '/uploads/tema6.png',
              '/uploads/tema7.png'
          ];
          const items = [];
          for(let i=0;i<count;i++){
              const mobile = String(Math.floor(1000 + Math.random()*9000));
              const banner = banners[i % banners.length];
              const wins = Math.floor(16 + Math.random()*24);
              items.push({mobile, banner, wins});
          }
          return items;
      }
      const RECORD_WINS_DATA = genRecords(12);
      function maskMobile(m){
          if(!m) return '';
          const d = (String(m)).replace(/\D/g,'');
          if(d.length < 4) return d;
          const s = d.slice(0,1);
          const e = d.slice(-2);
          return s + '***' + e;
      }
      function buildCards(items){
          return items.map(function(it){
              const mask = maskMobile(it.mobile);
              const banner = it.banner || '';
              const wins = it.wins || 0;
              return '<div class="_card-right-box_1506k_33">'
                  + '<div class="_poster-image_18m7l_37" style="background-image:url(' + banner + ');"></div>'
                  + '<div class="_game-name-normal_xt81s_33">'
                  + '<div class="_user-name-box_xt81s_39"><span class="_words_xt81s_47">Parabéns! </span>' + mask + '</div>'
                  + '<div class="_win-box_xt81s_50"><span class="_words_xt81s_478">win </span>' + wins + 'Vezes</div>'
                  + '</div></div>';
          }).join('');
      }
      function buildRecordHtml(items){
          const title = '<div class="winner-title"><p style="zoom:0.98;"><img src="https://cdn-icons-png.flaticon.com/128/15893/15893294.png" style="height:14px;margin-bottom:-1px;filter:hue-rotate(190deg) brightness(0.5);position:relative;left:8px;">'
              + '<img src="https://cdn-icons-png.flaticon.com/128/15893/15893294.png" style="height:21px;margin-bottom:-4px;filter:hue-rotate(190deg) brightness(0.5);"> Recorde do Grande Prêmio '
              + '<img src="https://cdn-icons-png.flaticon.com/128/15893/15893294.png" style="height:21px;margin-bottom:-4px;filter:hue-rotate(190deg) brightness(0.5);">'
              + '<img src="https://cdn-icons-png.flaticon.com/128/15893/15893294.png" style="height:14px;margin-bottom:-1px;filter:hue-rotate(190deg) brightness(0.5);position:relative;right:1px;"></p></div>';
          
          const cardsHtml = buildCards(items);
          
          const left = '<div class="_list-slide-box_igxdt_33 _winner-card_18vum_56"><div class="_scroll-wrapper" style="animation:25s linear 0s infinite normal none running scrollX;">'
              + cardsHtml + '</div></div>';
          const right = '<div class="_list-slide-box_igxdt_33 _winner-card_18vum_56"><div class="_scroll-wrapper" style="animation:25s linear 0s infinite reverse none running scrollX;">'
              + buildCards(items.slice().reverse()) + '</div></div>';
          return '<div id="record_big_win" class="_winner_18vum_33">' + title + left + right + '</div>';
      }
      function tryInjectRecords(){
          let attempts=0;const max=60;
          const tick=function(){
              attempts++;
              const target = document.querySelector('._marquee_xxjsk_34.global-marquee') || document.querySelector('.global-marquee');
              if(target){
                  if(!document.getElementById('record_big_win')){
                      const html = buildRecordHtml(RECORD_WINS_DATA);
                      target.insertAdjacentHTML('afterend', html);
                  }
              } else if(attempts<max){
                  setTimeout(tick,200);
              }
          };
          tick();
      }
      if(document.readyState==='loading'){
          document.addEventListener('DOMContentLoaded', tryInjectRecords);
      } else {
          tryInjectRecords();
      }
  }

  /* ========================================================== */
  /* JOGOS ESPECIAIS */
  /* ========================================================== */
  if (FLAGS.jogoEspeciais) {
      var ESPECIAIS_GAMES = (DATA && DATA.especiaisGames) ? DATA.especiaisGames : [];
  
      // SVG decorativo igual ao W1 (referencia o símbolo já existente na página)
      var ESP_SVG_L = '<i style="display:inline-flex;justify-content:center;align-items:center;color:var(--skin__border,#b0935a);">'
          + '<svg width="1.49rem" height="0.35rem" fill="currentColor"><use xlink:href="#img_tsyx_ys2_h5"></use></svg></i>';
      var ESP_SVG_R = '<i style="display:inline-flex;justify-content:center;align-items:center;color:var(--skin__border,#b0935a);transform:scaleX(-1);">'
          + '<svg width="1.49rem" height="0.35rem" fill="currentColor"><use xlink:href="#img_tsyx_ys2_h5"></use></svg></i>';
  
      function buildEspeciaisHtml(games){
          var cardHtml = games.map(function(g){
              var isPlatform = g && g.type === 'platform' && g.platformId;
              var attrs = isPlatform
                ? (' data-platform-id="' + String(g.platformId) + '" data-category-id="' + String(g.gameCategoryId || 3) + '"')
                : (' data-especial-id="' + String(g.id) + '"');
              return '<div class="esp-card' + (isPlatform ? ' esp-platform' : '') + '"' + attrs
                  + ' style="background-image:url(\'' + String(g.banner || '').replace(/'/g,"\\'") + '\');">'
                  + '<div class="esp-card-name">' + String(g.name || '') + '</div>'
                  + '</div>';
          }).join('');
  
          return '<div id="jogo_especiais_section">'
              + '<style>'
              + '#jogo_especiais_section{width:100%;margin:.12rem 0;}'
              + '#jogo_especiais_section .esp-header{'
              + 'display:flex;justify-content:center;align-items:center;margin-bottom:.12rem;}'
              + '#jogo_especiais_section .esp-title{'
              + 'font-size:.24rem;margin:0 .14rem;color:var(--skin__lead,#e8c97a);white-space:nowrap;flex-shrink:0;}'
              /* outer: W1-like box (clippa horizontal, deixa vertical crescer) */
              + '#jogo_especiais_section .esp-outer{'
              + 'width:100%;overflow:visible;padding:0;box-sizing:border-box;display:flex;justify-content:center;}'
              /* viewport: exatamente 7.1rem e clippa as laterais (como W1) */
              + '#jogo_especiais_section .esp-viewport{'
              + 'width:7.1rem;height:2.24rem;overflow:hidden;}'
              /* track: flex com gap 0.2rem; largura é pelo conteúdo */
              + '#jogo_especiais_section .esp-track{'
              + 'display:flex;align-items:flex-end;gap:.2rem;will-change:transform;'
              + 'height:2.24rem;box-sizing:border-box;}'
              /* card base: 1rem x 1.33rem, scale muda o visual sem bagunçar o grid */
              + '#jogo_especiais_section .esp-card{'
              + '--card-benchmark:1rem;'
              + 'position:relative;flex-shrink:0;width:var(--card-benchmark);height:calc(var(--card-benchmark) * 1.33);z-index:1;'
              + 'border-radius:calc(var(--card-benchmark) * 0.125);overflow:hidden;background-size:cover;background-position:center;'
              + 'cursor:pointer;transition:transform .3s ease,z-index 0s;margin:0;transform-origin:center bottom;transform:scale(1.26);}'
              /* near: 1.44 */
              + '#jogo_especiais_section .esp-card.esp-near{transform:scale(1.44);z-index:5;}'
              /* active: 1.68 */
              + '#jogo_especiais_section .esp-card.esp-active{transform:scale(1.68);z-index:20;}'
              + '#jogo_especiais_section .esp-card-name{'
              + 'position:absolute;bottom:0;left:0;right:0;padding:.04rem .06rem;'
              + 'font-size:.12rem;color:#fff;text-align:center;word-break:break-word;'
              + 'background:linear-gradient(transparent,rgba(0,0,0,.82));line-height:1.3;}'
              + '</style>'
              + '<div class="esp-header">'
              + ESP_SVG_L + '<span class="esp-title">Jogo especiais</span>' + ESP_SVG_R
              + '</div>'
              + '<div class="esp-outer"><div class="esp-viewport"><div class="esp-track">' + cardHtml + '</div></div></div>'
              + '</div>';
      }
  
          function setupEspeciais(){
          var section = document.getElementById('jogo_especiais_section');
          if(!section) return;
          var outer = section.querySelector('.esp-outer');
          var viewport = section.querySelector('.esp-viewport');
          var track = section.querySelector('.esp-track');
          var cards = track.querySelectorAll('.esp-card');
          var total = cards.length;
          // Começar sempre no bloco inicial (PG): centraliza no card do provedor PG (platformId=200),
          // para a primeira tela ficar: Tiger, Ox, PG, Rabbit, Snake.
          var cur = 0;
          try{
              var preferIdx = -1;
              for(var k=0;k<total;k++){
                  if(String(cards[k].getAttribute('data-platform-id')||'') === '200'){ preferIdx = k; break; }
              }
              if(preferIdx >= 0) cur = preferIdx;
              else cur = Math.min(2, Math.max(0, total - 1));
          }catch(_e0){
              cur = Math.min(2, Math.max(0, total - 1));
          }
  
          function applyClasses(){
              // W1 usa espaçamentos extras via margins no próprio card.
              var rem  = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
              // Ajuste fino: sobe um pouco os cards menores para reduzir o "vazio" no topo (fica mais parecido com a W1)
              var yNear = (0.06 * rem); // px
              var yFar  = (0.12 * rem); // px
              cards.forEach(function(c, i){
                  c.classList.remove('esp-active','esp-near');
                  c.style.marginLeft = '0';
                  c.style.marginRight = '0';
                  if(i === cur){
                      c.classList.add('esp-active');
                      c.style.transform = 'scale(1.68)';
                  } else if(i === cur - 1){
                      c.classList.add('esp-near');
                      c.style.transform = 'scale(1.44) translateY(-' + yNear + 'px)';
                      c.style.marginRight = '.6rem';
                  } else if(i === cur + 1){
                      c.classList.add('esp-near');
                      c.style.transform = 'scale(1.44) translateY(-' + yNear + 'px)';
                      c.style.marginLeft = '.6rem';
                  } else if(i === cur - 2){
                      c.style.transform = 'scale(1.26) translateY(-' + yFar + 'px)';
                      c.style.marginRight = '.48rem';
                  } else if(i === cur + 2){
                      c.style.transform = 'scale(1.26) translateY(-' + yFar + 'px)';
                      c.style.marginLeft = '.48rem';
                  } else if(i < cur){
                      c.style.transform = 'scale(1.26) translateY(-' + yFar + 'px)';
                  } else {
                      c.style.transform = 'scale(1.26) translateY(-' + yFar + 'px)';
                  }
              });
          }
  
          function goTo(idx, animate){
              cur = Math.max(0, Math.min(total - 1, idx));
              applyClasses();
              // Slot = largura do card + gap (não muda com o scale — scale é visual)
              var gap    = parseFloat(getComputedStyle(track).gap) || 0;
              function m(el){
                  var cs = getComputedStyle(el);
                  return {
                      w: el.offsetWidth,
                      ml: parseFloat(cs.marginLeft) || 0,
                      mr: parseFloat(cs.marginRight) || 0
                  };
              }
              // Soma o "layout width" (width + margins) como no W1.
              var before = 0;
              var totalW = 0;
              for(var i=0;i<total;i++){
                  var mi = m(cards[i]);
                  var li = mi.w + mi.ml + mi.mr;
                  totalW += li;
                  if(i < total - 1) totalW += gap;
                  if(i < cur) before += li + gap;
              }
              var mc = m(cards[cur]);
              var center = before + mc.ml + (mc.w / 2);
              var viewW  = (viewport && viewport.offsetWidth) ? viewport.offsetWidth : outer.offsetWidth;
              var offset = center - (viewW / 2);
              var maxOffset = Math.max(0, totalW - viewW);
              offset = Math.min(maxOffset, Math.max(0, offset));
              track.style.transition = animate ? 'transform .3s ease' : 'none';
              track.style.transform  = 'translateX(-' + offset + 'px)';
          }
  
          setTimeout(function(){ goTo(cur, false); }, 60);
  
          // Touch / drag
          var startX = 0, dragging = false, moved = 0;
          outer.addEventListener('touchstart', function(e){ startX=e.touches[0].clientX; dragging=true; moved=0; }, {passive:true});
          outer.addEventListener('touchmove',  function(e){ if(dragging) moved=e.touches[0].clientX-startX; }, {passive:true});
          outer.addEventListener('touchend',   function(){
              if(!dragging) return; dragging=false;
              if(moved < -30) goTo(cur+1, true);
              else if(moved > 30) goTo(cur-1, true);
          });
          outer.addEventListener('mousedown', function(e){ startX=e.clientX; dragging=true; moved=0; e.preventDefault(); });
          window.addEventListener('mousemove', function(e){ if(dragging) moved=e.clientX-startX; });
          window.addEventListener('mouseup', function(){
              if(!dragging) return; dragging=false;
              if(moved < -30) goTo(cur+1, true);
              else if(moved > 30) goTo(cur-1, true);
          });
  
          // Abre o jogo via Vue router + Pinia (igual ao platform nativo)
          function findPinia(app){
              // 1) Tenta pelo Symbol canônico do Pinia
              var p = app._context.provides[Symbol.for('pinia')];
              if(p && p._s) return p;
              // 2) Varre todos os Symbols do provides
              var syms = Object.getOwnPropertySymbols(app._context.provides);
              for(var i=0;i<syms.length;i++){
                  var v = app._context.provides[syms[i]];
                  if(v && v._s instanceof Map) return v;
              }
              // 3) Varre keys string
              var keys = Object.keys(app._context.provides);
              for(var j=0;j<keys.length;j++){
                  var vv = app._context.provides[keys[j]];
                  if(vv && vv._s instanceof Map) return vv;
              }
              return null;
          }
  
          function openGameEmbedded(gameUrl, gameName){
              var opened = false;
              try {
                  var appEl = document.querySelector('#app');
                  if(appEl && appEl.__vue_app__){
                      var app = appEl.__vue_app__;
                      var pinia = findPinia(app);
                      // console.log('[esp] pinia encontrado:', !!pinia);
                      if(pinia){
                          var gameStore = null;
                          pinia._s.forEach(function(store, key){
                              // console.log('[esp] store key:', key, 'tem setGameParameters:', !!store.setGameParameters);
                              if(store.setGameParameters && !gameStore) gameStore = store;
                          });
                          // console.log('[esp] gameStore encontrado:', !!gameStore);
                          if(gameStore){  
                              var router = app.config.globalProperties.$router;
                              // console.log('[esp] router encontrado:', !!router);
                              if(router){
                                  // setPreGameEmbeddedParams é obrigatório — o embedded fecha se name estiver vazio
                                  var curRoute = router.currentRoute && router.currentRoute.value;
                                  if(gameStore.setPreGameEmbeddedParams){
                                      gameStore.setPreGameEmbeddedParams({
                                          name: (curRoute && curRoute.name) || 'root',
                                          query: (curRoute && curRoute.query) || {}
                                      });
                                  }
                                  gameStore.setGameParameters({
                                      url: gameUrl,
                                      name: gameName || '',
                                      platformId: null,
                                      gameInfo: null,
                                      screenDirection: 2
                                  });
                                  if(gameStore.setGamePlaying) gameStore.setGamePlaying(true);
                                  router.push({ name: 'gameEmbedded' });
                                  opened = true;
                              }
                          }
                      }
                  }
              } catch(err){ /* console.warn('[esp] openGame err', err); */ }
              if(!opened){
                  // console.warn('[esp] fallback window.open');
                  window.open(gameUrl, '_blank');
              }
          }
  
          function espGetGameGold(){
              try{
                  var appEl = document.querySelector('#app');
                  if(!appEl || !appEl.__vue_app__) return null;
                  var pinia = findPinia(appEl.__vue_app__);
                  if(!pinia) return null;
                  var gold = null;
                  pinia._s.forEach(function(store){
                      if(gold !== null) return;
                      var ui = store.userInfos;
                      if(ui && typeof ui.game_gold !== 'undefined') gold = parseFloat(ui.game_gold);
                      else if(typeof store.game_gold !== 'undefined') gold = parseFloat(store.game_gold);
                  });
                  return gold;
              }catch(_){ return null; }
          }
  
          function espShowToast(msg){
              var overlay = document.createElement('div');
              overlay.setAttribute('data-v-app', '');
              overlay.innerHTML = '<div class="ui-overlay wg-fixed-no-desktop" data-hidden="1" style="z-index:5000;">'
                  + '<div class="ui-popup ui-popup--center safe-area-top safe-area-bottom ui-toast__toast ui-toast__toast--container ui-toast__toast--warn" tabindex="0" closeonclick="false" style="z-index:5000;">'
                  + '<div class="ui-toast__toast--instance" style="transform:translateY(0px);">'
                  + '<div class="ui-toast__toast--icon ui-toast__toast--warn">'
                  + '<i style="display:inline-flex;justify-content:center;align-items:center;">'
                  + '<svg width="1em" height="1em" fill="currentColor"><use xlink:href="#ui-exclamation-circle-a39166"></use></svg>'
                  + '</i></div>'
                  + '<div class="ui-toast__toast-message"></div>'
                  + '</div></div></div>';
              overlay.querySelector('.ui-toast__toast-message').textContent = msg;
              document.body.appendChild(overlay);
              setTimeout(function(){ overlay.remove(); }, 3000);
          }
  
          function espTriggerDeposit(){
              var btn = document.getElementById('depositClick')
                     || document.querySelector('._reCharge_1wuau_54')
                     || document.querySelector('[class*="_reCharge_"]')
                     || document.querySelector('#gn-deposit-btn');
              if(!btn){
                  var all = document.querySelectorAll('button,a,div[role="button"]');
                  for(var i=0;i<all.length;i++){
                      if(/dep[oó]sit/i.test(all[i].textContent||'')){btn=all[i];break;}
                  }
              }
              if(!btn) btn = document.querySelector('[class*="deposit"],[class*="recharge"]');
              if(btn) try{ btn.click(); }catch(_){}
          }
  
          track.addEventListener('click', function(e){
              var card = e.target.closest('[data-especial-id],[data-platform-id]');
              // console.log('[esp] click card:', card);
              if(!card) return;

              // Card de categoria/provedor (PG/WG) -> abre /home/subgame
              var platformId = card.getAttribute('data-platform-id');
              if(platformId){
                  var categoryId = card.getAttribute('data-category-id') || '3';
                  var url = '/home/subgame?gameCategoryId=' + encodeURIComponent(categoryId) + '&platformId=' + encodeURIComponent(platformId);
                  try{
                      var appEl0 = document.querySelector('#app');
                      if(appEl0 && appEl0.__vue_app__){
                          var router0 = appEl0.__vue_app__.config.globalProperties.$router;
                          if(router0){
                              try{ router0.push(url); return; }catch(_e0){}
                          }
                      }
                  }catch(_e1){}
                  try{
                      history.pushState({},'',url);
                      window.dispatchEvent(new PopStateEvent('popstate'));
                  }catch(_e2){
                      location.href = url;
                  }
                  return;
              }

              // Verificar se está logado — cookie é a fonte definitiva
              var loggedIn = document.cookie.indexOf('token_user=') > -1;
              if(!loggedIn) {
                  try {
                      var _p2 = findPinia(document.querySelector('#app').__vue_app__);
                      if(_p2) {
                          _p2._s.forEach(function(s){
                              if(loggedIn) return;
                              if(s && (s.hasLogined || s.isLogined || s.isLogin)) loggedIn = true;
                          });
                      }
                  } catch(_) {}
              }
              if(!loggedIn) {
                  try {
                      var _p3 = findPinia(document.querySelector('#app').__vue_app__);
                      if(_p3) {
                          var _loginStore = _p3._s.get('loginRegister');
                          if(_loginStore && typeof _loginStore.openLoginRegister === 'function') {
                              _loginStore.openLoginRegister({});
                              return;
                          }
                      }
                  } catch(_) {}
                  var loginBtn = document.querySelector('[class*="loginBtn"],[class*="login-btn"],#loginClick,[data-action="login"]');
                  if(loginBtn) loginBtn.click();
                  return;
              }
  
              // Verificação de saldo (igual ao fluxo W1 nativo)
              var gold = espGetGameGold();
              var minEntry = 1; // minimumEntryBalance configurado em t7
              if(gold !== null && gold < minEntry){
                  var goldLabel = 'R$' + minEntry.toFixed(2);
                  var toastMsg = 'Seu saldo é menor que ' + goldLabel + ', Por favor, faça um depósito para jogar';
                  try{
                      var _app = document.querySelector('#app').__vue_app__;
                      var _t = _app.config.globalProperties.$t;
                      if(_t) toastMsg = _t('lobby.game.goldInadequate', {gold: goldLabel});
                  }catch(_){}
                  espShowToast(toastMsg);
                  return;
              }
  
              var id = card.getAttribute('data-especial-id');
              // console.log('[esp] fetching gameid:', id);
              fetch('/hall/api/gameCenter/gameApi/login', {
                  method: 'POST',
                  headers: {'Content-Type': 'application/json'},
                  body: JSON.stringify({gameid: parseInt(id, 10)})
              })
                  .then(function(r){ return r.json(); })
                  .then(function(d){
                      // console.log('[esp] resposta API:', JSON.stringify(d));
                      if(d && d.code === 1 && d.data && d.data.game_url)
                          openGameEmbedded(d.data.game_url, d.data.gameName || '');
                      else {} // resposta inesperada
                  })
                  .catch(function(err){ /* console.error('[esp] fetch erro:', err); */ });
          });
      }
  
      function tryInjectEspeciais(){
          var attempts=0, max=80;
          var tick=function(){
              attempts++;
              if(document.getElementById('jogo_especiais_section')){
                  return; // já injetado
              }
              var anchor = document.getElementById('record_big_win')
                        || document.querySelector('._marquee_xxjsk_34.global-marquee')
                        || document.querySelector('.global-marquee');
              if(anchor){
                  if(!document.getElementById('jogo_especiais_section')){
                      anchor.insertAdjacentHTML('afterend', buildEspeciaisHtml(ESPECIAIS_GAMES));
                      setupEspeciais();
                  }
              } else if(attempts < max){
                  setTimeout(tick, 250);
              }
          };
          tick();
      }
  
      if(document.readyState==='loading'){
          document.addEventListener('DOMContentLoaded', tryInjectEspeciais);
      } else {
          tryInjectEspeciais();
      }
  }

  /* ========================================================== */
  /* WIDGET LIVE STREAM */
  /* ========================================================== */
      (function(){
          var IMG_BTN    = '/assets/images/2041641878285254657.avif';
          var IMG_POSTER = '/assets/images/2041641897938309121.avif';
  
          var css = ''
              /* botão colapsado — fixo no canto esquerdo do #app */
              + '#ls-btn{position:absolute;bottom:4.1rem;left:0;z-index:99999;width:.5rem;height:1.62rem;cursor:pointer;}'
              + '#ls-btn-bg{position:absolute;inset:0;background:url("'+IMG_BTN+'") center/contain no-repeat;}'
              /* overlay escuro ao abrir o player */
              + '#ls-overlay{display:none;position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.72);align-items:center;justify-content:center;}'
              + '#ls-overlay.ls-open{display:flex;}'
              /* player — igual _live-stream-drag_iayek_45 */
              + '#ls-player{position:relative;width:88%;max-width:var(--lobby__max-width,6rem);height:3.93rem;overflow:hidden;border-radius:.16rem;}'
              /* desktop: mais afastado nas laterais (mobile fica como está) */
              + '@media (min-width: 1024px){#ls-player{width:86%;max-width:6.6rem;}}'
              + '#ls-poster{position:absolute;inset:0;background:url("'+IMG_POSTER+'") center/cover no-repeat;}'
              /* badge LIVE top-center */
              + '#ls-live-badge{position:absolute;top:.2rem;left:50%;transform:translateX(-50%);'
              +   'background:#e62929;border-radius:.08rem;padding:.04rem .16rem;'
              +   'font-size:.22rem;font-weight:700;color:#fff;display:flex;align-items:center;gap:.06rem;}'
              + '#ls-live-badge .ls-dot{width:.12rem;height:.12rem;border-radius:50%;background:#fff;animation:ls-blink 1.2s infinite;}'
              /* controles */
              + '#ls-menu-btn{position:absolute;top:.2rem;left:.2rem;font-size:.28rem;color:#fff;padding:.1rem;cursor:pointer;opacity:.85;}'
              + '#ls-close-btn{position:absolute;top:.2rem;right:.2rem;font-size:.28rem;color:#fff;padding:.1rem;cursor:pointer;}'
              + '#ls-screen-btn{position:absolute;top:.2rem;right:.8rem;font-size:.28rem;color:#fff;padding:.1rem;cursor:pointer;opacity:.85;}'
              + '#ls-bottom-bar{position:absolute;bottom:0;left:0;right:0;display:flex;align-items:center;justify-content:space-between;padding:.1rem .1rem;}'
              + '#ls-bottom-right{display:flex;align-items:center;gap:.04rem;}'
              + '#ls-play-btn{font-size:.29rem;color:#fff;padding:.1rem;cursor:pointer;opacity:.85;}'
              + '#ls-vol-btn{font-size:.32rem;color:#fff;padding:.1rem;cursor:pointer;opacity:.85;}'
              + '#ls-lang-btn{cursor:pointer;'
              +   'background:rgba(0,0,0,.2);border:.01rem solid rgba(255,255,255,.4);border-radius:.25rem;'
              +   'padding:.06rem .18rem;font-size:.18rem;color:#fff;display:flex;align-items:center;gap:.06rem;}'
              /* sem live */
              + '#ls-no-live{position:absolute;top:50%;left:0;width:100%;transform:translateY(-50%);'
              +   'display:flex;align-items:center;justify-content:center;'
              +   'font-size:.22rem;color:rgba(255,255,255,.7);pointer-events:none;}'
              + '@keyframes ls-blink{0%,100%{opacity:1}50%{opacity:.3}}';
  
          var se = document.createElement('style');
          se.textContent = css;
          document.head.appendChild(se);
  
          // SVGs inline dos controles (simplificados)
          var SVG_CLOSE    = '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 28 28"><path d="M24.29 2.24a1.48 1.48 0 0 1 0 2.51L16.08 14l8.21 9.25a1.48 1.48 0 0 1-2.22 1.97L14 16.08l-8.07 9.14a1.48 1.48 0 0 1-2.22-1.97L11.92 14 3.71 4.75a1.48 1.48 0 1 1 2.22-1.97L14 11.92 22.07 2.78a1.48 1.48 0 0 1 2.22-.54z"/></svg>';
          var SVG_PLAY     = '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 28 28"><path d="M22.9 13.94L8.86 5.26A1.49 1.49 0 0 0 6.64 6.6v17.8a1.49 1.49 0 0 0 2.22 1.34L22.9 17.06a1.5 1.5 0 0 0 0-2.12z"/></svg>';
          var SVG_SCREEN   = '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 28 28"><path d="M18.62 27.5h7.49a1.38 1.38 0 0 0 1.39-1.39v-7.49a1.38 1.38 0 0 0-2.76 0v5.1l-5.35-5.35a1.38 1.38 0 0 0-1.95 1.95l5.35 5.35h-5.1a1.38 1.38 0 0 0 0 2.76V27.5zM1.89 27.5h7.49a1.38 1.38 0 0 0 0-2.76H4.28l5.35-5.35a1.38 1.38 0 0 0-1.95-1.95L2.33 22.8v-5.1A1.38 1.38 0 0 0 .5 19.11v7.49A1.38 1.38 0 0 0 1.89 27.5zM26.11.5h-7.49a1.38 1.38 0 1 0 0 2.76h5.1L18.37 8.61a1.38 1.38 0 1 0 1.95 1.95l5.35-5.35v5.1a1.38 1.38 0 1 0 2.76 0V1.89A1.38 1.38 0 0 0 26.11.5zM9.38.5H1.89A1.38 1.38 0 0 0 .5 1.89v7.42a1.38 1.38 0 1 0 2.76 0v-5.1l5.35 5.35a1.38 1.38 0 0 0 1.95-1.95L5.21 3.26h5.1a1.38 1.38 0 0 0 0-2.76z"/></svg>';
          var SVG_MENU     = '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 28 28"><path d="M2 6h24v2.5H2zm0 6.75h24v2.5H2zM2 19.5h24V22H2z"/></svg>';
          var SVG_VOL_OFF  = '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 28 28"><path d="M25.49 25.75L1.64 4.51a.78.78 0 0 1 1.04-1.17l23.85 21.24a.78.78 0 0 1-1.04 1.17zM14.25 2.36L8.58 7.21 16 13.75V3.22a.78.78 0 0 0-1.25-.63L14.25 2.36zM8.29 20.45H2.19A.78.78 0 0 1 1.5 19.7V8.3a.78.78 0 0 1 .69-.75h1.55l8 7.14v5.2a.78.78 0 0 1-.69.75l-.76.81z"/></svg>';
          var ARROW_DOWN   = '<svg width=".18rem" height=".18rem" fill="currentColor" viewBox="0 0 18 18"><path d="M7.5 12.56C8.25 13.69 9.53 13.79 10.13 12.94L16.13 6.94C17.5 5.5 17 4 14.93 4.31L9 8 3 4.31C1 4 1 6 1.88 6.94L7.5 12.56z"/></svg>';
  
          var html = ''
              + '<div id="ls-overlay">'
              +   '<div id="ls-player">'
              +     '<div id="ls-poster"></div>'
              +     '<span id="ls-menu-btn">'+SVG_MENU+'</span>'
              +     '<span id="ls-screen-btn">'+SVG_SCREEN+'</span>'
              +     '<span id="ls-close-btn">'+SVG_CLOSE+'</span>'
              +     '<div id="ls-bottom-bar">'
              +       '<span id="ls-play-btn">'+SVG_PLAY+'</span>'
              +       '<div id="ls-bottom-right">'
              +         '<div id="ls-lang-btn">Inglês&nbsp;'+ARROW_DOWN+'</div>'
              +         '<span id="ls-vol-btn">'+SVG_VOL_OFF+'</span>'
              +       '</div>'
              +     '</div>'
              +   '</div>'
              + '</div>';
  
          function injectBtn(appEl){
              if(document.getElementById('ls-btn')) return;
              // Garante contexto de posicionamento no #app
              var cs = window.getComputedStyle(appEl);
              if(cs.position === 'static') appEl.style.position = 'relative';
  
              // Botão dentro do #app (posição absoluta, lado esquerdo)
              var btnWrap = document.createElement('div');
              btnWrap.innerHTML = '<div id="ls-btn"><div id="ls-btn-bg"></div></div>';
              appEl.appendChild(btnWrap.firstChild);
  
              // Overlay no body (position:fixed cobre tela inteira)
              var overlayWrap = document.createElement('div');
              overlayWrap.innerHTML = html;
              document.body.appendChild(overlayWrap.firstChild);
  
              var btn     = document.getElementById('ls-btn');
              var overlay = document.getElementById('ls-overlay');
              var closeBtn= document.getElementById('ls-close-btn');
  
              /* ── Vertical drag ── */
              btn.style.cursor = 'grab';
              (function(){
                  var LS_KEY = 'ls_btn_top';
                  var dragging = false, didDrag = false;
                  var startY = 0, startTop = 0;
  
                  /* restore saved position */
                  var saved = localStorage.getItem(LS_KEY);
                  if (saved !== null) {
                      btn.style.bottom = '';
                      btn.style.top = parseFloat(saved) + 'px';
                  }
  
                  function getTop() {
                      /* usa posição real na tela para evitar erro de conversão rem→px */
                      var parentRect = btn.parentElement ? btn.parentElement.getBoundingClientRect() : {top:0};
                      return btn.getBoundingClientRect().top - parentRect.top;
                  }
  
                  function clampTop(t) {
                      var appH = btn.parentElement ? btn.parentElement.offsetHeight : window.innerHeight;
                      return Math.max(0, Math.min(appH - btn.offsetHeight, t));
                  }
  
                  function onStart(e) {
                      dragging = true; didDrag = false;
                      startY   = e.touches ? e.touches[0].clientY : e.clientY;
                      startTop = getTop();
                      btn.style.cursor = 'grabbing';
                      e.preventDefault();
                  }
  
                  function onMove(e) {
                      if (!dragging) return;
                      var clientY = e.touches ? e.touches[0].clientY : e.clientY;
                      var delta = clientY - startY;
                      if (Math.abs(delta) > 4) {
                          if (!didDrag) {
                              didDrag = true;
                              btn.style.bottom = '';
                              btn.style.top = startTop + 'px';
                          }
                          btn.style.top = clampTop(startTop + delta) + 'px';
                      }
                      e.preventDefault();
                  }
  
                  function onEnd() {
                      if (!dragging) return;
                      dragging = false;
                      btn.style.cursor = 'grab';
                      localStorage.setItem(LS_KEY, parseFloat(btn.style.top));
                  }
  
                  btn.addEventListener('mousedown',  onStart, {passive:false});
                  btn.addEventListener('touchstart', onStart, {passive:false});
                  document.addEventListener('mousemove', onMove, {passive:false});
                  document.addEventListener('touchmove', onMove, {passive:false});
                  document.addEventListener('mouseup',  onEnd);
                  document.addEventListener('touchend', onEnd);
  
                  /* block click if it was a drag */
                  btn.addEventListener('click', function(e){ if (didDrag) { didDrag = false; e.stopImmediatePropagation(); } }, true);
              })();
  
              btn.addEventListener('click', function(){
                  overlay.classList.add('ls-open');
              });
              closeBtn.addEventListener('click', function(e){
                  e.stopPropagation();
                  overlay.classList.remove('ls-open');
              });
              overlay.addEventListener('click', function(e){
                  if(e.target === overlay) overlay.classList.remove('ls-open');
              });
  
              // Oculta o botão na rota /home/embedded e mostra nas demais
              function syncLsBtnVisibility(){
                  var hidden = /\/home\/embedded(\/|$|\?)/.test(window.location.pathname + window.location.search);
                  btn.style.display = hidden ? 'none' : '';
                  if(hidden) overlay.classList.remove('ls-open');
              }
              syncLsBtnVisibility();
              window.addEventListener('popstate', syncLsBtnVisibility);
              // Vue Router usa history.pushState — intercepta para detectar navegação SPA
              (function(){
                  var _origPush = history.pushState.bind(history);
                  var _origReplace = history.replaceState.bind(history);
                  history.pushState = function(){ _origPush.apply(this, arguments); syncLsBtnVisibility(); };
                  history.replaceState = function(){ _origReplace.apply(this, arguments); syncLsBtnVisibility(); };
              })();
          }
  
          function watchLoginModal(){
              // Abre o live stream quando o modal de login/registro aparecer — apenas 1x
              var lsOverlay = document.getElementById('ls-overlay');
              if(!lsOverlay) return;
              var loginObs = new MutationObserver(function(){
                  if(lsOverlay.classList.contains('ls-open')) return;
                  var modal = document.querySelector('[class*="loginRegisterDialog"]');
                  if(modal && modal.offsetParent !== null){
                      loginObs.disconnect(); // para de observar após abrir 1x
                      lsOverlay.classList.add('ls-open');
                  }
              });
              loginObs.observe(document.body, {childList:true, subtree:true, attributes:true, attributeFilter:['style','class']});
          }
  
          function waitAndInject(){
              // Aguarda o Vue terminar de renderizar o #app (detecta um filho com classe Vue)
              var obs = new MutationObserver(function(){
                  var appEl = document.getElementById('app');
                  if(!appEl) return;
                  // Vue renderizou quando há filhos com classes geradas (contêm "_")
                  var vueReady = appEl.querySelector('[class*="_"]');
                  if(vueReady){
                      obs.disconnect();
                      injectBtn(appEl);
                      watchLoginModal();
                  }
              });
              obs.observe(document.documentElement, {childList:true, subtree:true});
              setTimeout(function(){ obs.disconnect(); }, 30000);
          }
  
          if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', waitAndInject);
          else waitAndInject();
      })();

  /* ========================================================== */
  /* GAME NAVIGATOR (GN) */
  /* ========================================================== */
      (function(){
          'use strict';
  
          // GN injeta DOM no <body>; wm-all pode ser carregado no <head>.
          // Defere todo o bloco GN até o DOM estar pronto para evitar document.body null.
          // NOTE: GN must run only when <body> exists. wm-all is normally loaded with `defer`.
          // If this script is loaded early, index.php should load only the lightweight wm-boot.js instead.

          var GN_PER_PAGE = 6; // 3 cols × 2 rows por página — igual W1
          var _gnPage = 0;
          var _cats = null;
          var _activeCat = null;
          var _gamesCache = {};
  
          /* ── CSS ── */
          var gnStyle = document.createElement('style');
          gnStyle.textContent = ''
              /* Barra */
              + '#gn-bar{'
              +   'position:fixed;top:0;left:50%;transform:translateX(-50%);'
              +   'width:min(21.4%,var(--lobby__max-width,6rem));'
              +   'z-index:2001;display:none;align-items:center;'
              +   'height:.9rem;padding-right:.1rem;box-sizing:border-box;overflow:hidden;'
              +   'background-color:var(--skin__bs_topnav_bg,var(--skin__bg_1,#333333));'
              +   'background-image:url("/siteadmin/skin/lobby_asset/2-0-22/common/common/bg_pattern_tile2.png");'
              +   'background-size:1.8rem 1.8rem;background-repeat:repeat-x;'
              +   'border-bottom:.01rem solid var(--skin__border,#444444);}'
              +   '@media(max-width:768px){'
              +   '#gn-bar{width:min(100%,var(--lobby__max-width,6rem));}'
              +   '}'
              + '#gn-bar.gn-visible{display:flex;}'
              + '#gn-left{display:flex;align-items:center;flex:1;min-width:0;height:100%;}'
              + '#gn-back{padding:0 .08rem 0 .1rem;height:100%;display:inline-flex;align-items:center;background:none;border:none;cursor:pointer;flex-shrink:0;font-size:.36rem;color:var(--skin__alt_border,#999999);}'
              + '#gn-back svg{width:1em;height:1em;fill:currentColor;}'
              + '#gn-logo{height:.7rem;max-width:2.63rem;display:flex;align-items:center;}'
              + '#gn-logo img{height:.7rem;width:auto;max-width:2.63rem;object-fit:contain;display:block;}'
              + '#gn-right{display:flex;align-items:center;gap:.04rem;flex-shrink:0;}'
              + '#gn-deposit-btn{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.04rem;min-width:.7rem;background:none;border:none;cursor:pointer;color:var(--skin__lead,#e3e3e3);font-size:.18rem;padding:.04rem .06rem;white-space:nowrap;}'
              + '#gn-deposit-btn svg{width:.38rem;height:.38rem;fill:var(--skin__alt_border,#aaa);flex-shrink:0;}'
              + '.gn-icon-btn{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.04rem;min-width:.7rem;background:none;border:none;cursor:pointer;color:var(--skin__lead,#e3e3e3);font-size:.18rem;padding:.04rem .06rem;white-space:nowrap;}'
              + '.gn-icon-btn svg{width:.38rem;height:.38rem;fill:currentColor;flex-shrink:0;}'
              + '#gn-fs-btn svg{fill:var(--skin__alt_border,#aaa);}'
              + '#gn-sort-btn svg{fill:var(--skin__alt_border,#aaa);}'
              + '#gn-sort-btn.gn-active svg{fill:var(--skin__primary,var(--skin__accent_1,#04BE02));}'
              + '#gn-sort-btn.gn-active{color:var(--skin__primary,var(--skin__accent_1,#04BE02));}'
              /* Painel — igual W1: linha de select + carousel */
              + '#gn-panel{position:fixed;top:.9rem;left:50%;transform:translateX(-50%);width:min(100%,var(--lobby__max-width,6rem));z-index:2000;display:none;flex-direction:column;background:var(--skin__bg_2,#222);}'
              + '#gn-panel.gn-open{display:flex;}'
              /* Linha do selector — igual _game-box_ do W1 */
              + '#gn-cat-row{display:flex;align-items:center;gap:.1rem;padding:.1rem .14rem;flex-shrink:0;background:var(--skin__bg_1,#333);border-bottom:.01rem solid var(--skin__border,#444);position:relative;z-index:5;}'
              + '#gn-kf-icon{width:.52rem;height:.52rem;fill:var(--skin__lead,#e3e3e3);flex-shrink:0;padding:.07rem;background:var(--skin__bg_2,rgba(255,255,255,.08));border-radius:50%;box-sizing:border-box;}'
              + '#gn-select-wrap{position:relative;flex:1;}'
              + '#gn-select-btn{display:flex;align-items:center;gap:.08rem;background:var(--skin__bg_2,rgba(255,255,255,.1));border:.01rem solid var(--skin__border,rgba(255,255,255,.22));border-radius:.6rem;padding:.09rem .16rem .09rem .12rem;cursor:pointer;color:var(--skin__lead,#e3e3e3);font-size:.2rem;}'
              + '#gn-select-btn .gn-sel-ico{width:.3rem;height:.3rem;flex-shrink:0;object-fit:contain;}'
              + '#gn-select-btn .gn-sel-txt{flex:1;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}'
              + '#gn-select-btn .gn-sel-arr{width:.2rem;height:.2rem;fill:rgba(255,255,255,.6);flex-shrink:0;transition:transform .2s;}'
              + '#gn-select-btn.open .gn-sel-arr{transform:rotate(180deg);}'
              /* Dropdown */
              + '#gn-cat-dd{position:absolute;top:calc(100% + .05rem);left:0;min-width:100%;background:var(--skin__bg_1,#333);border:.01rem solid var(--skin__border,#444);border-radius:.08rem;box-shadow:0 .1rem .3rem rgba(0,0,0,.6);z-index:20;display:none;overflow:hidden;}'
              + '#gn-cat-dd.open{display:block;}'
              + '.gn-dd-hdr{padding:.1rem .14rem .04rem;font-size:.13rem;font-weight:700;text-transform:uppercase;letter-spacing:.02rem;color:rgba(255,255,255,.3);}'
              + '.gn-dd-item{display:flex;align-items:center;gap:.1rem;padding:.1rem .14rem;font-size:.2rem;cursor:pointer;color:rgba(255,255,255,.7);white-space:nowrap;}'
              + '.gn-dd-item .gn-dd-icon{width:.3rem;height:.3rem;flex-shrink:0;object-fit:contain;}'
              + '.gn-dd-item:active,.gn-dd-item.active{background:rgba(255,255,255,.08);color:var(--skin__primary,var(--skin__accent_1,#04BE02));}'
              + '#gn-cat-dd{max-height:4rem;overflow-y:auto;}'
              + '#gn-deposit-btn.gn-deposit-active svg{fill:var(--skin__primary,var(--skin__accent_1,#04BE02));}'
              + '#gn-deposit-btn.gn-deposit-active{color:var(--skin__primary,var(--skin__accent_1,#04BE02));}'
              /* Área de jogos */
              + '#gn-game-area{display:flex;flex-direction:column;overflow:hidden;}'
              + '#gn-carousel-outer{overflow:hidden;position:relative;flex-shrink:0;cursor:grab;user-select:none;}'
              + '#gn-carousel-track{display:flex;transition:transform .28s ease;will-change:transform;align-items:flex-start;}'
              + '.gn-page{min-width:100%;flex-shrink:0;display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:auto auto;gap:.1rem;padding:.1rem;box-sizing:border-box;}'
              + '.gn-game-card{border-radius:.14rem;overflow:hidden;cursor:pointer;position:relative;background:#1a1a2e;aspect-ratio:3/4;}'
              + '.gn-game-card img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;}'
              + '.gn-game-card span{position:absolute;bottom:0;left:0;right:0;font-size:.13rem;color:#fff;background:linear-gradient(transparent,rgba(0,0,0,.9));padding:.08rem .07rem .05rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}'
              /* Dots */
              + '#gn-dots{height:.44rem;display:flex;justify-content:center;align-items:center;gap:.1rem;flex-shrink:0;background:var(--skin__bg_2,#222);}'
              + '.gn-dot{width:.12rem;height:.12rem;border-radius:50%;border:none;padding:0;cursor:pointer;background:rgba(255,255,255,.25);transition:.2s;flex-shrink:0;}'
              + '.gn-dot.active{background:var(--skin__primary,var(--skin__accent_1,#04BE02));width:.28rem;border-radius:.06rem;}'
              + '#gn-loading-msg,#gn-empty-msg{color:rgba(255,255,255,.4);font-size:.18rem;padding:.3rem;text-align:center;grid-column:1/-1;display:flex;align-items:center;justify-content:center;height:100%;}';
  
          document.head.appendChild(gnStyle);
  
          /* ── HTML: Barra ── */
          var gnBar = document.createElement('div');
          gnBar.id = 'gn-bar';
          gnBar.innerHTML = ''
              + '<div id="gn-left">'
              +   '<button id="gn-back" aria-label="Voltar">'
              +     '<svg viewBox="0 0 21.999 35.998"><path d="M18.279,32.564l-14.743-13.773a2.024,2.024,0,0,1-.271-.228,2.009,2.009,0,0,1,0-2.83,2.02,2.02,0,0,1,.274-.23L18.279,1.733a1.992,1.992,0,0,0-2.817-2.816L1.52,12.687A5.992,5.992,0,0,0,1.52,22.311l13.942,13.07a1.992,1.992,0,0,0,2.817-2.817Z"/></svg>'
              +   '</button>'
              +   '<div id="gn-logo">'
              +     '<img src="'+(DATA.logoSrc||'')+'" onerror="this.style.display=\'none\'">'
              +   '</div>'
              + '</div>'
              + '<div id="gn-right">'
              +   '<button id="gn-deposit-btn">'
              +     '<svg viewBox="0 0 40 40"><path d="M34.7432 9.07143C36.3999 9.07159 37.7432 10.4147 37.7432 12.0714V18.214H25.8574C23.3328 18.214 21.2863 20.2607 21.2861 22.7853C21.2861 25.31 23.3327 27.3566 25.8574 27.3566H37.7432V33.5001C37.7431 35.1568 36.3998 36.5 34.7432 36.5001H6C4.34319 36.5001 3.00008 35.1569 3 33.5001V12.0714C3 10.4146 4.34315 9.07143 6 9.07143H34.7432Z"/><path d="M28.6 22.7857C28.6 24.0481 27.5767 25.0714 26.3143 25.0714C25.0519 25.0714 24.0286 24.0481 24.0286 22.7857C24.0286 21.5233 25.0519 20.5 26.3143 20.5C27.5767 20.5 28.6 21.5233 28.6 22.7857Z"/></svg>'
              +     'Dep\u00f3sito'
              +   '</button>'
              +   '<button id="gn-fs-btn" class="gn-icon-btn" aria-label="Tela cheia">'
              +     '<svg viewBox="0 0 40 40"><path d="M32 4C34.2091 4 36 5.79086 36 8V32C36 34.2091 34.2091 36 32 36H8C5.79086 36 4 34.2091 4 32V8C4 5.79086 5.79086 4 8 4H32ZM10.6006 27.4707V24.0215L7.60059 24.0205L7.59961 32.5205L16.0996 32.5215L16.1006 29.5215H12.792L18.1924 24.1211L16.0713 22L10.6006 27.4707ZM23.8418 11H27.0713L22 16.0713L24.1211 18.1924L29.3418 12.9717V16.5L32.3418 16.501L32.3428 8.00098L23.8428 8L23.8418 11Z"/></svg>'
              +     'Ecr\u00e3'
              +   '</button>'
              +   '<button id="gn-sort-btn" class="gn-icon-btn" aria-label="Mais jogos">'
              +     '<svg viewBox="0 0 40 40"><path d="M14.1055 22.5188C16.0575 22.5188 17.6396 24.1046 17.6396 26.0608V33.1164C17.6395 35.0725 16.0574 36.6584 14.1055 36.6584H7.03418C5.08236 36.6583 3.50013 35.0724 3.5 33.1164V26.0608C3.5 24.1046 5.08228 22.5189 7.03418 22.5188H14.1055Z"/><path d="M31.8438 22.5188C33.7957 22.5189 35.3779 24.1046 35.3779 26.0608V33.1164C35.3778 35.0725 33.7956 36.6583 31.8438 36.6584H24.7725C22.8205 36.6584 21.2384 35.0725 21.2383 33.1164V26.0608C21.2383 24.1046 22.8205 22.5188 24.7725 22.5188H31.8438Z"/><path d="M26.3594 4.49534C27.6311 3.22385 29.69 3.22165 30.959 4.49045L35.5566 9.08713C36.8255 10.3561 36.8234 12.416 35.5518 13.6877L30.9639 18.2746C29.6921 19.546 27.6332 19.5482 26.3643 18.2795L21.7666 13.6828C20.4977 12.4139 20.4999 10.354 21.7715 9.08225L26.3594 4.49534Z"/><path d="M14.1055 4.84397C15.0428 4.84408 15.9417 5.21705 16.6045 5.88108C17.2674 6.54534 17.6396 7.44656 17.6396 8.38596V15.4416C17.6396 16.381 17.2674 17.2823 16.6045 17.9465C15.9417 18.6105 15.0427 18.9835 14.1055 18.9836H7.03516C6.09763 18.9836 5.1981 18.6107 4.53516 17.9465C3.87222 17.2823 3.5 16.381 3.5 15.4416V8.38596C3.5 7.44656 3.87221 6.54534 4.53516 5.88108C5.1981 5.21682 6.09761 4.84397 7.03516 4.84397H14.1055Z"/></svg>'
              +     'Mais'
              +   '</button>'
              + '</div>';
          document.body.appendChild(gnBar);
  
          /* ── HTML: Painel — igual _game-box_ W1 ── */
          var gnPanel = document.createElement('div');
          gnPanel.id = 'gn-panel';
          gnPanel.innerHTML = ''
              /* Linha: select de categoria (esquerda) + ícone headphone (direita) */
              + '<div id="gn-cat-row">'
              +   '<div id="gn-select-wrap">'
              +     '<button id="gn-select-btn">'
              +       '<img class="gn-sel-ico" src="/siteadmin/skin/lobby_asset/2-0-common/common/_sprite/icon_dtfl_rm_1.avif">'
              +       '<span class="gn-sel-txt">Popular</span>'
              +       '<svg class="gn-sel-arr" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>'
              +     '</button>'
              +     '<div id="gn-cat-dd"></div>'
              +   '</div>'
              +   '<svg id="gn-kf-icon" viewBox="0 0 40 40">'
              +     '<path d="M20 7.97C12.35 7.97 6.13 14.06 6 21.61L6 21.84V27.79C6 28.33 5.55 28.78 5 28.78H3C1.9 28.78 1 27.89 1 26.8V22.83C1 21.74 1.9 20.85 3 20.85H3.03C3.55 12.01 10.95 5 20 5C29.05 5 36.45 12.01 36.97 20.85H37C38.1 20.85 39 21.74 39 22.83V26.8C39 27.89 38.1 28.78 37 28.78H35C34.45 28.78 34 28.33 34 27.79V21.84C34 14.18 27.73 7.97 20 7.97Z"/>'
              +     '<path fill-rule="evenodd" clip-rule="evenodd" d="M20 10.34C26.89 10.34 32.47 15.93 32.47 22.81C32.47 25.16 31.82 27.35 30.69 29.23C30.74 29.27 30.78 29.31 30.81 29.37L32.88 33.31C33.07 33.66 32.75 34.08 32.36 33.99L27.41 32.84C25.34 34.37 22.78 35.28 20 35.28C13.11 35.28 7.53 29.7 7.53 22.81C7.53 15.93 13.11 10.34 20 10.34ZM12.88 20.73C11.89 20.73 11.09 21.53 11.09 22.52C11.09 23.5 11.89 24.3 12.88 24.3C13.86 24.3 14.66 23.5 14.66 22.52C14.66 21.53 13.86 20.73 12.88 20.73ZM20 20.73C19.02 20.73 18.22 21.53 18.22 22.52C18.22 23.5 19.02 24.3 20 24.3C20.98 24.3 21.78 23.5 21.78 22.52C21.78 21.53 20.98 20.73 20 20.73ZM27.13 20.73C26.14 20.73 25.34 21.53 25.34 22.52C25.34 23.5 26.14 24.3 27.13 24.3C28.11 24.3 28.91 23.5 28.91 22.52C28.91 21.53 28.11 20.73 27.13 20.73Z"/>'
              +   '</svg>'
              + '</div>'
              /* Área de jogos: carousel + dots */
              + '<div id="gn-game-area">'
              +   '<div id="gn-carousel-outer"><div id="gn-carousel-track"></div></div>'
              +   '<div id="gn-dots"></div>'
              + '</div>';
          document.body.appendChild(gnPanel);
  
          /* ── Pinia helpers ── */
          function getPinia(){
              var appEl = document.querySelector('#app');
              if(!appEl || !appEl.__vue_app__) return null;
              var provides = appEl.__vue_app__._context.provides;
              var syms = Object.getOwnPropertySymbols(provides);
              for(var i=0;i<syms.length;i++){
                  var sv = provides[syms[i]];
                  if(sv && sv._s instanceof Map) return sv;
              }
              return null;
          }
  
          function isLoggedIn(){
              /* Verifica cookie token_user (fonte definitiva) */
              if(document.cookie.indexOf('token_user=') > -1) return true;
              /* Fallback: Pinia store */
              var pinia = getPinia();
              if(!pinia) return false;
              var found = false;
              pinia._s.forEach(function(s){
                  if(found) return;
                  if(s && (s.hasLogined || s.isLogined || s.isLogin || s.token || s.userId || s.uid)) found = true;
              });
              return found;
          }
  
          function openLogin(){
              var pinia = getPinia(); if(!pinia) return;
              var s = pinia._s.get('loginRegister');
              if(s && s.openLoginRegister) s.openLoginRegister({});
          }
  
          function openRecharge(){
              var pinia = getPinia(); if(!pinia) return;
              var d = pinia._s.get('dialogs');
              if(d && d.open){ try{ d.open('recharge',{openType:'overlay'}); }catch(e){} }
          }
  
          /* Ícones de categoria — usa avif do siteadmin igual ao lobby principal */
          var GN_ICON_BASE = '/siteadmin/skin/lobby_asset/2-0-common/common/_sprite/';
          /* Apenas os códigos com avif disponível em /siteadmin/skin/lobby_asset/2-0-common/common/_sprite/ */
          var GN_ICON_CODES = {
              'popular':'rm',
              'slot':'dz','dz':'dz',
              'block':'qkl','chain':'qkl','crypto':'qkl',
              'recente':'zj','recent':'zj','histor':'zj',
              'favorit':'sc','collect':'sc',
          };
          /* Ícones inexistentes (esporte/ty, pescaria/by, crash/pj etc.) → fallback dz */
          function gnCatIconCode(name){
              var n=(name||'').toLowerCase();
              var ks=Object.keys(GN_ICON_CODES);
              for(var i=0;i<ks.length;i++){ if(n.indexOf(ks[i])>-1) return GN_ICON_CODES[ks[i]]; }
              return 'dz';
          }
          function gnCatIconHtml(code,cls){
              return '<img class="'+(cls||'gn-dd-icon')+'" src="'+GN_ICON_BASE+'icon_dtfl_'+code+'_1.avif" onerror="this.style.opacity=0">';
          }
  
          /* Categorias a ignorar (sem jogos reais) */
          var GN_SKIP_CATS = ['jogar gr','gratis','free','demonstra','demo'];
          function gnSkipCat(name){
              var n = (name||'').toLowerCase();
              return GN_SKIP_CATS.some(function(s){ return n.indexOf(s) !== -1; });
          }
  
          /* ── Categorias ── */
          function loadCats(cb){
              if(_cats){ cb(_cats); return; }
              fetch('/hall/api/game/hall/listPlatformCateLoadV2/currency/BRL/language/pt.json')
              .then(function(r){ return r.json(); })
              .then(function(data){
                  var list = [{type:'item', name:'Popular', key:'popular', icon:'rm', providers:[]}];
                  if(data && data.data){
                      data.data.forEach(function(cat){
                          if(!cat.p1 || cat.p1==='Popular') return;
                          if(gnSkipCat(cat.p1)) return;
                          if(!Array.isArray(cat.l)) return;
                          var providers = [];
                          cat.l.forEach(function(p){ if(p.t6===0 && p.t10) providers.push(p.t10); });
                          if(!providers.length) return;
                          var icode = gnCatIconCode(cat.p1);
                          list.push({type:'item', name:cat.p1, key:cat.p1.toLowerCase().replace(/\s+/g,'_'), icon:icode, providers:providers});
                      });
                  }
                  list.push({type:'item', name:'Recente',  key:'recente',  icon:'zj', providers:[], special:'recent'});
                  list.push({type:'item', name:'Favoritos', key:'favoritos', icon:'sc', providers:[], special:'favorites'});
                  _cats = list;
                  cb(_cats);
              })
              .catch(function(){ _cats=[{type:'item',name:'Popular',key:'popular',icon:'rm',providers:[]}]; cb(_cats); });
          }
  
          function renderCatsDropdown(cats){
              var dd = document.getElementById('gn-cat-dd');
              dd.innerHTML = '';
              cats.forEach(function(cat){
                  if(cat.type !== 'item') return;
                  var el = document.createElement('div');
                  el.className = 'gn-dd-item' + (cat.key===(_activeCat&&_activeCat.key)?' active':'');
                  el.dataset.key = cat.key;
                  el.innerHTML = gnCatIconHtml(cat.icon||'dz') + '<span>' + cat.name + '</span>';
                  el.addEventListener('click', function(){ selectCat(cat); closeDd(); });
                  dd.appendChild(el);
              });
          }
  
          function openDd(){
              document.getElementById('gn-select-btn').classList.add('open');
              document.getElementById('gn-cat-dd').classList.add('open');
          }
          function closeDd(){
              document.getElementById('gn-select-btn').classList.remove('open');
              document.getElementById('gn-cat-dd').classList.remove('open');
          }
  
          /* Lê jogos recentes/favoritos do Pinia store (mesma fonte que o lobby principal) */
          function getGamesFromPinia(type){
              var pinia = getPinia();
              if(!pinia) return null;
              var candidates = [];
              var namePatterns = type==='recent'
                  ? /recent|history|played|record|histori|zj|lately/i
                  : /fav|like|collect|star|bookmark|colect|sc|wish/i;
              pinia._s.forEach(function(store, sid){
                  /* Varre TODAS as propriedades de cada store */
                  try {
                      var props = Object.keys(store);
                      props.forEach(function(prop){
                          try {
                              var arr = store[prop];
                              if(!Array.isArray(arr) || arr.length < 1) return;
                              var g = arr[0];
                              if(!g || typeof g !== 'object') return;
                              var hasId   = !!(g.gameId||g.id||g.g0||g.game_id||g.gameCode);
                              var hasName = !!(g.gameName||g.name||g.g1||g.game_name||g.title);
                              if(!hasId && !hasName) return;
                              var score = 0;
                              if(namePatterns.test(sid))   score += 20;
                              if(namePatterns.test(prop))  score += 10;
                              if(hasId)   score += 2;
                              if(hasName) score += 2;
                              candidates.push({sid:sid, prop:prop, score:score, arr:arr});
                          } catch(e){}
                      });
                  } catch(e){}
              });
              if(!candidates.length) return null;
              /* Debug: mostra todos os candidatos */
              candidates.sort(function(a,b){return b.score-a.score;});
              // console.log('[GN] getGamesFromPinia('+type+') candidates:', candidates.map(function(c){return c.sid+'.'+c.prop+'('+c.arr.length+') score='+c.score;}));
              var best = candidates[0];
              if(best.score < 10) return null; /* nenhum candidato relevante */
              return best.arr.map(function(g){
                  return {
                      id:+(g.gameId||g.id||g.g0||g.game_id)||0,
                      name:g.gameName||g.game_name||g.name||g.g1||g.title||'',
                      img:g.banner||g.imgUrl||g.img||g.iconUrl||g.g2||g.image||''
                  };
              }).filter(function(g){return g.id;});
          }
  
          function loadGames(cat, cb){
              var cacheKey = cat.key;
              /* Recente/Favoritos: nunca cacheia (pode mudar a cada jogada) */
              if(!cat.special && _gamesCache[cacheKey]){ cb(_gamesCache[cacheKey]); return; }
  
              if(cat.special === 'recent' || cat.special === 'favorites'){
                  /* 1ª tentativa: Pinia store (mesma fonte do lobby) */
                  var fromPinia = getGamesFromPinia(cat.special==='recent'?'recent':'favorites');
                  if(fromPinia && fromPinia.length){ cb(fromPinia); return; }
  
                  /* 2ª tentativa: APIs internas (usam cookie token_user automaticamente) */
                  var apiPath = cat.special === 'recent'
                      ? '/hall/api/gameCenter/gameApi/recent-list/v3'
                      : '/hall/api/gameCenter/gameApi/favorite-list-all/v3';
                  fetch(apiPath, {method:'POST', credentials:'include'})
                  .then(function(r){ return r.json(); })
                  .then(function(d){
                      var list=(d&&d.data)?(Array.isArray(d.data)?d.data:(d.data.list||d.data.l||[])):[];
                      var games=list.map(function(g){
                          return {
                              id:+(g.g0||g.gameId||g.id)||0,
                              name:g.g1||g.gameName||g.game_name||'',
                              img:g.g2||g.banner||g.imgUrl||g.img||''
                          };
                      }).filter(function(g){return g.id;});
                      cb(games);
                  })
                  .catch(function(){ cb([]); });
                  return;
              }
  
              var url;
              if(cat.key === 'popular'){
                  url = '/hall/api/games-by-provider?popular=1';
              } else if(cat.providers && cat.providers.length){
                  url = '/hall/api/games-by-provider?provider=' + cat.providers.join(',');
              } else { cb([]); return; }
              fetch(url)
              .then(function(r){ return r.json(); })
              .then(function(d){ _gamesCache[cacheKey]=(d&&d.data)?d.data:[]; cb(_gamesCache[cacheKey]); })
              .catch(function(){ cb([]); });
          }
  
          function selectCat(cat){
              if(!cat || cat.type==='header') return;
              _activeCat = cat;
              _gnPage = 0;
              var selTxt = document.querySelector('#gn-select-btn .gn-sel-txt');
              if(selTxt) selTxt.textContent = cat.name;
              var selIco = document.querySelector('#gn-select-btn .gn-sel-ico');
              if(selIco){
                  var ni = document.createElement('img');
                  ni.className = 'gn-sel-ico';
                  ni.src = GN_ICON_BASE + 'icon_dtfl_' + (cat.icon||'dz') + '_1.avif';
                  selIco.parentNode.replaceChild(ni, selIco);
              }
              document.querySelectorAll('.gn-dd-item').forEach(function(el){
                  el.classList.toggle('active', el.dataset.key === cat.key);
              });
              setCarouselLoading();
              loadGames(cat, renderGames);
          }
  
          function setCarouselLoading(){
              document.getElementById('gn-carousel-track').innerHTML =
                  '<div class="gn-page"><div id="gn-loading-msg">Carregando...</div></div>';
              document.getElementById('gn-dots').innerHTML = '';
          }
  
          function renderGames(games){
              var track = document.getElementById('gn-carousel-track');
              var dotsEl = document.getElementById('gn-dots');
              if(!games||!games.length){
                  var msg = 'Sem jogos';
                  if(_activeCat){
                      if(_activeCat.special==='recent')   msg = isLoggedIn() ? 'Nenhum jogo recente' : 'Faça login para ver recentes';
                      if(_activeCat.special==='favorites') msg = isLoggedIn() ? 'Nenhum favorito ainda' : 'Faça login para ver favoritos';
                  }
                  track.innerHTML='<div class="gn-page"><div id="gn-empty-msg">'+msg+'</div></div>';
                  dotsEl.innerHTML='';
                  return;
              }
              var pages=Math.ceil(games.length/GN_PER_PAGE);
              var pagesHtml='';
              for(var p=0;p<pages;p++){
                  pagesHtml+='<div class="gn-page">';
                  var slice=games.slice(p*GN_PER_PAGE,(p+1)*GN_PER_PAGE);
                  slice.forEach(function(g){
                      var name=(g.name||'').replace(/"/g,'&quot;').replace(/</g,'&lt;');
                      pagesHtml+='<div class="gn-game-card" data-gid="'+g.id+'">'
                          +'<img src="'+(g.img||'')+'" loading="lazy" onerror="this.onerror=null;this.src=\'/uploads/tema1.png\'">'
                          +'<span>'+name+'</span></div>';
                  });
                  pagesHtml+='</div>';
              }
              track.innerHTML = pagesHtml;
              track.querySelectorAll('.gn-game-card').forEach(function(el){
                  el.addEventListener('click',function(){ launchGame(el.dataset.gid); });
              });
              var dHtml='';
              for(var i=0;i<pages;i++) dHtml+='<button class="gn-dot'+(i===_gnPage?' active':'')+'" data-p="'+i+'"></button>';
              dotsEl.innerHTML=dHtml;
              dotsEl.querySelectorAll('.gn-dot').forEach(function(d){
                  d.addEventListener('click',function(){ gnGoToPage(parseInt(d.dataset.p)); });
              });
              gnGoToPage(_gnPage, true);
          }
  
          function gnGoToPage(n, instant){
              var track=document.getElementById('gn-carousel-track');
              if(!track) return;
              var pages=track.querySelectorAll('.gn-page').length;
              _gnPage=Math.max(0,Math.min(n,pages-1));
              track.style.transition=instant?'none':'transform .28s ease';
              track.style.transform='translateX(-'+(_gnPage*100)+'%)';
              document.querySelectorAll('.gn-dot').forEach(function(d,i){
                  d.classList.toggle('active',i===_gnPage);
              });
          }
  
          /* Swipe (touch + mouse drag) — inicializado uma única vez no container externo */
          (function(){
              var outer = document.getElementById('gn-carousel-outer');
              var sx=0,sy=0,swiping=false;
              /* Touch */
              outer.addEventListener('touchstart',function(e){ sx=e.touches[0].clientX; sy=e.touches[0].clientY; swiping=false; },{passive:true});
              outer.addEventListener('touchmove',function(e){ swiping=true; },{passive:true});
              outer.addEventListener('touchend',function(e){
                  if(!swiping) return;
                  var dx=e.changedTouches[0].clientX-sx, dy=e.changedTouches[0].clientY-sy;
                  if(Math.abs(dx)>Math.abs(dy)&&Math.abs(dx)>28){ dx<0?gnGoToPage(_gnPage+1):gnGoToPage(_gnPage-1); }
              },{passive:true});
              /* Mouse drag (desktop) */
              var mx=0, dragging=false;
              outer.addEventListener('mousedown',function(e){ mx=e.clientX; dragging=true; outer.style.cursor='grabbing'; e.preventDefault(); });
              document.addEventListener('mouseup',function(e){
                  if(!dragging) return;
                  dragging=false; outer.style.cursor='';
                  var dx=e.clientX-mx;
                  if(Math.abs(dx)>28){ dx<0?gnGoToPage(_gnPage+1):gnGoToPage(_gnPage-1); }
              });
              document.addEventListener('mouseleave',function(){ dragging=false; outer.style.cursor=''; });
          })();
  
          function launchGame(id){
              closeMorePanel();
              var appEl = document.querySelector('#app');
              if(appEl && appEl.__vue_app__){
                  var router = appEl.__vue_app__.config.globalProperties.$router;
                  if(router){
                      try{ router.push({name:'game-embedded',query:{id:String(id)}}); return; }catch(e){}
                      try{ router.push('/home/embedded?id='+id); return; }catch(e){}
                  }
              }
              history.pushState({},'','/home/embedded?id='+id);
              window.dispatchEvent(new PopStateEvent('popstate'));
          }
  
          function openMorePanel(){
              gnPanel.classList.add('gn-open');
              document.getElementById('gn-sort-btn').classList.add('gn-active');
              loadCats(function(cats){
                  if(!_activeCat){
                      for(var i=0;i<cats.length;i++){ if(cats[i].type==='item'){ _activeCat=cats[i]; break; } }
                  }
                  var selTxt = document.querySelector('#gn-select-btn .gn-sel-txt');
                  if(selTxt) selTxt.textContent = _activeCat.name;
                  renderCatsDropdown(cats);
                  setCarouselLoading();
                  loadGames(_activeCat, renderGames);
              });
          }
  
          function closeMorePanel(){
              gnPanel.classList.remove('gn-open');
              closeDd();
              var sb = document.getElementById('gn-sort-btn');
              if(sb) sb.classList.remove('gn-active');
          }
  
          /* ── Visibilidade ── */
          function syncGameNav(){
              var onGame = /\/home\/embedded(\/|$|\?)/.test(window.location.pathname+window.location.search);
              if(onGame){
                  gnBar.classList.add('gn-visible');
              } else {
                  gnBar.classList.remove('gn-visible');
                  closeMorePanel();
              }
          }
  
          /* ── Eventos ── */
          document.getElementById('gn-back').addEventListener('click', function(){ history.back(); });
  
          document.getElementById('gn-deposit-btn').addEventListener('click', function(){
              if(!isLoggedIn()) openLogin(); else openRecharge();
          });
          /* Deposit active state — detecta quando o modal de depósito abre/fecha */
          (function(){
              var btn = document.getElementById('gn-deposit-btn');
              function checkDeposit(){
                  var open = !!(
                      document.querySelector('[class*="finance__wrap"]') ||
                      document.querySelector('[class*="recharge__"]') ||
                      document.querySelector('[class*="deposit__"]')
                  );
                  btn.classList.toggle('gn-deposit-active', open);
              }
              new MutationObserver(checkDeposit).observe(document.body, {childList:true});
          })();
  
          document.getElementById('gn-fs-btn').addEventListener('click', function(){
              if(!document.fullscreenElement){
                  (document.documentElement.requestFullscreen||document.documentElement.webkitRequestFullscreen||function(){}).call(document.documentElement);
              } else {
                  (document.exitFullscreen||document.webkitExitFullscreen||function(){}).call(document);
              }
          });
  
          document.getElementById('gn-sort-btn').addEventListener('click', function(){
              if(gnPanel.classList.contains('gn-open')) closeMorePanel();
              else openMorePanel();
          });
  
          document.getElementById('gn-select-btn').addEventListener('click', function(e){
              e.stopPropagation();
              loadCats(function(cats){
                  renderCatsDropdown(cats);
                  var dd = document.getElementById('gn-cat-dd');
                  if(dd.classList.contains('open')) closeDd(); else openDd();
              });
          });
  
          document.addEventListener('click', function(e){
              if(!gnPanel.classList.contains('gn-open')) return;
              var dd = document.getElementById('gn-cat-dd');
              var sb = document.getElementById('gn-select-btn');
              if(dd && dd.classList.contains('open') && !dd.contains(e.target) && sb && !sb.contains(e.target)){
                  closeDd();
              }
              if(!gnPanel.contains(e.target) && !gnBar.contains(e.target)){
                  closeMorePanel();
              }
          }, true);
  
          /* ── Route watcher ── */
          syncGameNav();
          window.addEventListener('popstate', syncGameNav);
          (function(){
              var _op = history.pushState.bind(history);
              var _or = history.replaceState.bind(history);
              history.pushState    = function(){ _op.apply(this,arguments); syncGameNav(); };
              history.replaceState = function(){ _or.apply(this,arguments); syncGameNav(); };
          })();
      })();

  /* ========================================================== */
  /* AUTO OPEN LOGIN (quando deslogado) */
  /* ========================================================== */
  if (!DATA.hasTokenUser) {
      // Usuário não logado: abre o modal de login/registro assim que o store Pinia estiver pronto,
      // sem esperar o systemInfos da API (evita o delay de 10-15s)
      (function(){
          var _attempts = 0;
          function findPiniaStore(id){
              var appEl = document.querySelector('#app');
              if(!appEl || !appEl.__vue_app__) return null;
              var provides = appEl.__vue_app__._context.provides;
              var pinia = provides[Symbol.for('pinia')];
              if(!pinia || !pinia._s){
                  var syms = Object.getOwnPropertySymbols(provides);
                  for(var i=0;i<syms.length;i++){
                      var v = provides[syms[i]];
                      if(v && v._s instanceof Map){ pinia = v; break; }
                  }
              }
              if(!pinia || !pinia._s) return null;
              return pinia._s.get(id) || null;
          }
          function tryOpenLogin(){
              _attempts++;
              if(_attempts > 60) return; // desiste após 30s
              var store = findPiniaStore('loginRegister');
              if(!store || !store.openLoginRegister){
                  setTimeout(tryOpenLogin, 500);
                  return;
              }
              store.openLoginRegister({});
          }
          if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(tryOpenLogin, 300); });
          else setTimeout(tryOpenLogin, 300);
      })();
  }

  /* ========================================================== */
  /* PIX / order id helpers */
  /* ========================================================== */
      (function(){
          function findOrderId(){
              try {
                  const list = document.querySelectorAll('._orderInfo_eji8x_30 li');
                  for (const li of list){
                      const labelEl = li.querySelector('span');
                      const labelText = labelEl ? (labelEl.textContent || '').trim() : '';
                      if (!labelText) continue;
                      if (labelText.includes('Número do pedido do comerciante') || labelText.includes('Número do Pedido')){
                          const infoEl = li.querySelector('div');
                          const txt = infoEl ? (infoEl.textContent || '').trim() : (li.textContent || '').replace(labelText,'').trim();
                          if (txt) return txt;
                      }
                  }
              } catch(e){}
              return null;
          }
  
          function showPaidView(){
              try {
                  const mainInfo = document.querySelector('._mainInfo_1e4js_30');
                  const qrContainer = document.querySelector("[id^='recharge-qrcode-']");
                  if (!mainInfo || !qrContainer) return;
  
                  const amountEl = document.querySelector('._money_1e4js_33 span');
                  const amountText = amountEl ? (amountEl.textContent || '').trim() : '';
  
                  const statusLabel = Array.from(document.querySelectorAll('._orderInfo_eji8x_30 li span')).find(el => (el.textContent || '').trim().includes('Status do pedido'));
                  if (statusLabel){
                      const li = statusLabel.closest('li');
                      const info = li ? li.querySelector('div') : null;
                      if (info){
                          info.innerHTML = '<span style="color:#10b981;font-weight:700">Pagamento bem-feito</span>';
                      }
                  }
  
                  if (!document.getElementById('paid-overlay')){
                      const overlay = document.createElement('div');
                      overlay.id = 'paid-overlay';
                      overlay.style.position = 'absolute';
                      overlay.style.inset = '0';
                      overlay.style.backdropFilter = 'blur(3px)';
                      overlay.style.background = 'rgba(0,0,0,0.25)';
                      overlay.style.pointerEvents = 'none';
                      overlay.style.zIndex = '5';
  
                      const checkWrap = document.createElement('div');
                      checkWrap.style.position = 'absolute';
                      checkWrap.style.inset = '0';
                      checkWrap.style.display = 'flex';
                      checkWrap.style.alignItems = 'center';
                      checkWrap.style.justifyContent = 'center';
                      checkWrap.style.zIndex = '6';
  
                      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                      svg.setAttribute('viewBox','0 0 120 120');
                      svg.style.width = '96px';
                      svg.style.height = '96px';
  
                      const circle = document.createElementNS('http://www.w3.org/2000/svg','circle');
                      circle.setAttribute('cx','60');
                      circle.setAttribute('cy','60');
                      circle.setAttribute('r','46');
                      circle.setAttribute('fill','#22c55e');
  
                      const path = document.createElementNS('http://www.w3.org/2000/svg','path');
                      path.setAttribute('d','M44 60l10 10 22-22');
                      path.setAttribute('stroke','#fff');
                      path.setAttribute('stroke-width','10');
                      path.setAttribute('fill','none');
                      path.setAttribute('stroke-linecap','round');
                      path.setAttribute('stroke-linejoin','round');
  
                      svg.appendChild(circle);
                      svg.appendChild(path);
                      checkWrap.appendChild(svg);
  
                      const qrBox = qrContainer;
                      qrBox.style.position = 'relative';
                      qrBox.appendChild(overlay);
                      qrBox.appendChild(checkWrap);
                  }
  
                  if (!document.getElementById('paid-success-block')){
                      const successBlock = document.createElement('div');
                      successBlock.id = 'paid-success-block';
                      successBlock.style.display = 'flex';
                      successBlock.style.flexDirection = 'column';
                      successBlock.style.alignItems = 'center';
                      successBlock.style.gap = '8px';
                      successBlock.style.padding = '.12rem 0';
  
                      const amount = document.createElement('div');
                      amount.style.fontSize = '20px';
                      amount.style.fontWeight = '700';
                      amount.style.color = '#fff';
                      amount.textContent = amountText;
  
                      const success = document.createElement('div');
                      success.style.color = '#22c55e';
                      success.style.fontSize = '18px';
                      success.style.fontWeight = '800';
                      success.textContent = 'Recebido com sucesso';
  
                      const desc = document.createElement('div');
                      desc.style.color = '#8ce99a';
                      desc.style.textAlign = 'center';
                      desc.style.fontSize = '14px';
                      desc.innerHTML = 'O sistema atribuiu automaticamente uma pontuação a você, A página atual será fechada após <span id="paid-countdown">10</span> segundos';
  
                      const actions = document.createElement('div');
                      actions.style.display = 'flex';
                      actions.style.gap = '8px';
                      actions.style.fontSize = '13px';
                      actions.style.color = '#fff';
                      actions.style.alignItems = 'center';
  
                      const closeNow = document.createElement('a');
                      closeNow.href = 'javascript:void(0)';
                      closeNow.style.color = '#fff';
                      closeNow.style.textDecoration = 'underline';
                      closeNow.textContent = 'Fechar agora';
                      closeNow.onclick = function(){ window.location.reload(); };
  
                      const sep = document.createElement('span');
                      sep.style.opacity = '0.7';
                      sep.textContent = 'Ou verificar pedido';
                      sep.onclick = function(){ window.location.reload(); };
  
                      actions.appendChild(closeNow);
                      actions.appendChild(sep);
  
                      successBlock.appendChild(amount);
                      successBlock.appendChild(success);
                      successBlock.appendChild(desc);
                      successBlock.appendChild(actions);
  
                      mainInfo.appendChild(successBlock);
  
                      let t = 10;
                      const el = document.getElementById('paid-countdown');
                      const c = setInterval(function(){
                          t--; if (el) el.textContent = String(t);
                          if (t <= 0){ clearInterval(c); window.location.reload(); }
                      },1000);
                  }
              } catch(e){}
          }
  
          function poll(){
              const orderId = findOrderId();
              if (!orderId) return;
              let done = false;
              const intv = setInterval(function(){
                  if (done){ clearInterval(intv); return; }
                  fetch('/hall/pay/checkstatus?orderId=' + encodeURIComponent(orderId), { credentials: 'include' })
                      .then(function(r){ return r.json(); })
                      .then(function(j){
                          if (j && j.data && j.data.status === 'pago'){
                              done = true;
                              clearInterval(intv);
                              showPaidView();
                          }
                      })
                      .catch(function(){ /* silencioso */ });
              }, 3000);
          }
  
          function initWhenReady(){
              let attempts = 0;
              const max = 60;
              const tryStart = function(){
                  attempts++;
                  const orderSection = document.querySelector('._orderInfo_eji8x_30');
                  const qr = document.querySelector("[id^='recharge-qrcode-']");
                  if (orderSection && qr){
                      poll();
                  } else if (attempts < max){
                      setTimeout(tryStart, 500);
                  }
              };
              tryStart();
          }
  
          if (document.readyState === 'loading'){
              document.addEventListener('DOMContentLoaded', initWhenReady);
          } else {
              initWhenReady();
          }
  
          const mo = new MutationObserver(function(){
              const orderSection = document.querySelector('._orderInfo_eji8x_30');
              const qr = document.querySelector("[id^='recharge-qrcode-']");
              if (orderSection && qr){
                  initWhenReady();
                  mo.disconnect();
              }
          });
      mo.observe(document.body,{childList:true,subtree:true});
      })();

    /* ========================================================== */
    /* WELCOME MODAL */
    /* ========================================================== */
      (function(){
          function ensureWelcomeModal(){
              var existing = document.getElementById('welcome-modal');
              if(existing) return existing;

              try{
                  var confettiSrc = '/assets/images/img_emoji_tada.avif';
                  var modal = document.createElement('div');
                  modal.id = 'welcome-modal';
                  modal.style.cssText = 'position:fixed;inset:0;display:none;z-index:9999;background:rgba(0,0,0,0.65);padding:.38rem .32rem;box-sizing:border-box;align-items:center;justify-content:center;flex-direction:column;gap:.18rem';
                  modal.innerHTML = '' +
                      '<div style="width:min(6rem,92%);border-radius:.2rem;background:var(--skin__bg_2,#0b4a4d);border:1px solid rgba(255,255,255,.14);box-shadow:0 0 0 1px rgba(33,208,122,.22) inset, 0 .28rem .9rem rgba(0,0,0,.45);color:var(--skin__neutral_2,#fff);padding:.28rem .30rem .30rem;text-align:center;backface-visibility:hidden;overflow:auto;min-height:2.7rem;display:flex;flex-direction:column;justify-content:center;position:relative;box-sizing:border-box">' +
                        '<div style="display:flex;justify-content:center;margin-bottom:.18rem">' +
                          '<div style="width:.88rem;height:.88rem;border-radius:50%;background:#21d07a;display:flex;align-items:center;justify-content:center;flex-shrink:0">' +
                            '<svg width=".46rem" height=".46rem" fill="#fff" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>' +
                          '</div>' +
                        '</div>' +
                        '<div style="display:flex;align-items:center;justify-content:center;gap:.14rem;margin-bottom:.14rem">' +
                          '<img src="' + confettiSrc + '" style="width:.44rem;height:.44rem;object-fit:contain" alt="">' +
                          '<span class="wm-title" style="font-weight:800;font-size:.30rem;line-height:1.22;color:var(--skin__neutral_2,#fff)">Parab&eacute;ns Por Se<br>Cadastrar!</span>' +
                          '<img src="' + confettiSrc + '" style="width:.44rem;height:.44rem;object-fit:contain" alt="">' +
                        '</div>' +
                        '<div style="font-size:.21rem;line-height:1.55;color:rgba(255,255,255,.78);margin:.08rem 0 .26rem;padding:0 .06rem">' +
                          '&#127881; Parab&eacute;ns por se cadastrar! &#9989;<br>' +
                          '&#128178; Ganhe at&eacute; 777 de b&ocirc;nus no seu primeiro dep&oacute;sito.<br>' +
                          '&#128165; Jogue agora! &#128165;' +
                        '</div>' +
                        '<div style="display:flex;gap:.2rem;padding-top:.20rem">' +
                          '<div style="position:relative;flex:1;padding-top:.31rem">' +
                            '<div style="position:absolute;top:-.20rem;right:0;background:var(--skin__accent_1,#21d07a);color:#fff;border-radius:999px;padding:.04rem .10rem;font-size:.16rem;font-weight:800;white-space:nowrap;z-index:1;border:1px solid rgba(255,255,255,.10);line-height:1;display:flex;align-items:center;gap:.03rem;box-sizing:border-box;max-width:calc(100% - .06rem)">' +
                              '<img src="/assets/images/img_xzapp_jl.avif" style="width:.30rem;height:.30rem;object-fit:contain;flex-shrink:0;margin-left:-.14rem" alt="">' +
                              '<span style="display:inline-block;overflow:hidden;text-overflow:ellipsis">Ganhe R$777</span>' +
                            '</div>' +
                            '<button class="wm-app" style="width:100%;height:.7rem;padding:0 .1rem;border-radius:.14rem;border:none;background:linear-gradient(90deg,#f495f3 2.08%,#8632ff 98.1%);color:#fff;font-weight:800;font-size:.22rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:.08rem;box-sizing:border-box">' +
                              '<img src="/assets/images/icon_zccgtc_yh.avif" style="width:.35rem;height:.35rem;object-fit:contain;flex-shrink:0" alt="">' +
                              '<span>Baixe o APP</span>' +
                            '</button>' +
                          '</div>' +
                          '<div style="position:relative;flex:1;padding-top:.31rem">' +
                            '<div style="position:absolute;top:-.20rem;right:0;background:var(--skin__accent_1,#21d07a);color:#fff;border-radius:999px;padding:.04rem .10rem;font-size:.16rem;font-weight:800;white-space:nowrap;z-index:1;border:1px solid rgba(255,255,255,.10);line-height:1;display:flex;align-items:center;gap:.03rem;box-sizing:border-box;max-width:calc(100% - .06rem)">' +
                              '<img src="/assets/images/img_xzapp_jl.avif" style="width:.30rem;height:.30rem;object-fit:contain;flex-shrink:0;margin-left:-.14rem" alt="">' +
                              '<span style="display:inline-block;overflow:hidden;text-overflow:ellipsis">B&ocirc;nus de dep&oacute;sito</span>' +
                            '</div>' +
                            '<button class="wm-deposit" style="width:100%;height:.7rem;padding:0 .1rem;border-radius:.14rem;border:none;background:linear-gradient(90deg,#fece01 -13.33%,#ff7200 98.1%);color:#fff;font-weight:800;font-size:.22rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:.08rem;box-sizing:border-box">' +
                              '<img src="/assets/images/icon_zccgtc_cz.avif" style="width:.35rem;height:.35rem;object-fit:contain;flex-shrink:0" alt="">' +
                              '<span>Deposite agora</span>' +
                            '</button>' +
                          '</div>' +
                        '</div>' +
                      '</div>' +
                      '<button class="wm-close" aria-label="close" style="border:none;background:transparent;color:inherit;display:flex;align-items:center;justify-content:center;padding:0;cursor:pointer">' +
                        '<i class="ui-dialog-close-box__icon" style="font-size:.6rem;color:#fff;cursor:pointer;display:inline-flex;justify-content:center;align-items:center">' +
                          '<svg width="1em" height="1em" fill="currentColor" class=""><use xlink:href="#ui-close-059120"></use></svg>' +
                        '</i>' +
                      '</button>';
                  (document.body || document.documentElement).appendChild(modal);
                  return modal;
              }catch(_e){
                  return null;
              }
          }

          var modal = ensureWelcomeModal();
          if(!modal) return;
          var wmWelcomeIsOpen = false;
          var wmWelcomeLastOpenTs = 0;
          try{
              wmWelcomeLastOpenTs = parseInt(sessionStorage.getItem('wm_welcome_last_open') || '0', 10) || 0;
          }catch(_e){}

          function normalizeText(text){
              return (text || '')
                  .toLowerCase()
                  .normalize('NFD')
                  .replace(/[\u0300-\u036f]/g, '');
          }
           
          function openWelcome(){
              if(wmWelcomeIsOpen) return;
              wmWelcomeIsOpen = true;
              try{ sessionStorage.setItem('wm_welcome_last_open', String(Date.now())); }catch(_e){}
              window.__welcomeAfterRegister=true;
              var title=modal.querySelector('.wm-title');
              title.style.color='#21d07a';
              var btnDeposit=modal.querySelector('.wm-deposit');
              var btnApp=modal.querySelector('.wm-app');
              var btnClose=modal.querySelector('.wm-close');
              
              try{
                  var hasSymbol = document.querySelector('#ui-close-059120') != null;
                  btnClose.innerHTML =
                      (hasSymbol
                        ? '<i class="ui-dialog-close-box__icon" style="font-size:.6rem;color:#fff;cursor:pointer;display:inline-flex;justify-content:center;align-items:center"><svg width="1em" height="1em" fill="currentColor" class=""><use xlink:href=\"#ui-close-059120\"></use></svg></i>'
                        : '<i class="ui-dialog-close-box__icon" style="font-size:.6rem;color:#fff;cursor:pointer;display:inline-flex;justify-content:center;align-items:center">×</i>');
              }catch(_e){}
              
              function findDepositTriggerDeep(){
                  try{
                      var byId=document.getElementById('depositClick');
                      if(byId) return byId;
                      
                      var byClass = document.querySelector('._reCharge_1wuau_54');
                      if(byClass) return byClass;
                      
                      var byClassContains = document.querySelector('[class*="_reCharge_"]');
                      if(byClassContains) return byClassContains;
                      
                      var buttons = document.querySelectorAll('button, a, div[role="button"], span[role="button"]');
                      
                      for(var i=0; i<buttons.length; i++){
                          var btn = buttons[i];
                          var txt = normalizeText((btn.textContent || '').trim());
                          var ariaLabel = normalizeText(btn.getAttribute('aria-label') || '');
                          if(txt === 'deposito' || /deposit/i.test(txt) || /deposit/i.test(ariaLabel)) return btn;
                      }
                      
                      var iconButtons = document.querySelectorAll('[class*="deposit"], [class*="recharge"], [class*="Deposit"], [class*="Recharge"]');
                      if(iconButtons.length > 0) return iconButtons[0];
                      
                      return null;
                  }catch(e){ 
                      return null;
                  }
              }
              
              function tryOpenDeposit(){
                  setTimeout(function(){
                      var depositBtn = findDepositTriggerDeep();
                      
                      if(depositBtn){
                          try{ depositBtn.click(); }catch(e){}
                          
                          try{ 
                              depositBtn.dispatchEvent(new MouseEvent('click', {
                                  bubbles:true, 
                                  cancelable:true, 
                                  view:window
                              })); 
                          }catch(e){}
                          
                          try{ 
                              depositBtn.dispatchEvent(new PointerEvent('click', {
                                  bubbles:true, 
                                  cancelable:true
                              })); 
                          }catch(e){}
                          
                          try{ 
                              depositBtn.dispatchEvent(new TouchEvent('touchstart', {
                                  bubbles:true, 
                                  cancelable:true
                              })); 
                          }catch(e){}
                          
                          var checkCount = 0;
                          var checkTimer = setInterval(function(){
                              checkCount++;
                              
                              var depositModalSelectors = [
                                  '.ui-overlay[data-hidden="0"]', 
                                  '.ui-popup:not(#welcome-modal)', 
                                  '._main-recharge_1m3jl_30',
                                  '[class*="recharge"]:not(#welcome-modal)',
                                  '[class*="deposit"]:not(#welcome-modal)',
                                  '.modal:not(#welcome-modal)',
                                  '[role="dialog"]:not(#welcome-modal)'
                              ];
                              
                              var modalOpened = false;
                              for(var i=0; i<depositModalSelectors.length; i++){
                                  var el = document.querySelector(depositModalSelectors[i]);
                                  if(el && el.offsetParent !== null && el.id !== 'welcome-modal'){ 
                                      modalOpened = true;
                                      break; 
                                  }
                              }
                              
                              if(modalOpened || checkCount >= 20){
                                  clearInterval(checkTimer);
                                  if(modalOpened) close();
                              }
                          }, 200);
                      } else {
                          alert('Não foi possível encontrar o botão de depósito. Por favor, clique no botão "Depósito" na barra superior.');
                      }
                  }, 500);
              }
              
              function close(){
                  modal.style.display='none';
                  document.cookie='welcome_after_register=; path=/; max-age=0; samesite=Lax';
                  window.__welcomeAfterRegister=false;
                  wmWelcomeIsOpen = false;
                  try{ localStorage.removeItem('welcome_after_register'); }catch(_e){}
              }
              
              btnClose.addEventListener('click', function(){
                  close();
              });
              
              btnApp.addEventListener('click', function(){ 
                  window.location.href='/uploads/baixar.avif'; 
              });
              
              btnDeposit.addEventListener('click', function(){
                  tryOpenDeposit();
              });
              
              modal.style.display='flex';
          }
          
          function hasFlag(){ 
              return document.cookie.indexOf('welcome_after_register=1') !== -1;
          }

          function clearFlag(){
              try{ localStorage.removeItem('welcome_after_register'); }catch(_e){}
              document.cookie='welcome_after_register=; path=/; max-age=0; samesite=Lax';
          }

          function wasJustShown(){
              var ts = wmWelcomeLastOpenTs;
              if(!ts) return false;
              return (Date.now() - ts) < 20000;
          }
          
          window.addEventListener('welcomeModalReady', function(){
              setTimeout(openWelcome, 500);
          });
          
          if(hasFlag()){
              if(wasJustShown()){
                  clearFlag();
              } else {
                  setTimeout(openWelcome, 1000);
              }
          } else {
              var tries=0, limit=180;
              var timer=setInterval(function(){
                  if(hasFlag()){
                      clearInterval(timer);
                      if(wasJustShown()){
                          clearFlag();
                      } else {
                          setTimeout(openWelcome, 500);
                      }
                  } else if(++tries>=limit){
                      clearInterval(timer);
                  }
              },1000);
          }
      })();

  /* ========================================================== */
  /* REMOVE modal erro rede */
  /* ========================================================== */
      (function() {
          'use strict';
          
          function removerModalErroRede() {
              const dialogs = document.querySelectorAll('.ui-dialog, .ui-popup, [class*="ui-dialog"], [class*="ui-popup"]');
              
              dialogs.forEach(function(dialog) {
                  const texto = (dialog.textContent || '').toLowerCase();
                  
                  if (texto.includes('conexão de rede está anormal') || 
                      texto.includes('conexao de rede esta anormal') ||
                      texto.includes('rede está anormal') ||
                      texto.includes('rede esta anormal') ||
                      texto.includes('atendimento ao cliente') ||
                      (texto.includes('lembrete') && texto.includes('rede'))) {
                      
                      dialog.remove();
                      
                      const overlay = document.querySelector('.ui-overlay, [class*="ui-overlay"]');
                      if (overlay) {
                          overlay.remove();
                      }
                  }
              });
          }
          
          if (typeof MutationObserver !== 'undefined') {
              const observer = new MutationObserver(function(mutations) {
                  removerModalErroRede();
              });
              
              if (document.readyState === 'loading') {
                  document.addEventListener('DOMContentLoaded', function() {
                      observer.observe(document.body, {
                          childList: true,
                          subtree: true
                      });
                      removerModalErroRede();
                  });
              } else {
                  observer.observe(document.body, {
                      childList: true,
                      subtree: true
                  });
                  removerModalErroRede();
              }
          }
          
          // Evita loop agressivo (100ms) que pode deixar o site pesado.
          // O MutationObserver acima já cobre praticamente tudo; mantemos apenas um fallback mais lento.
          setInterval(removerModalErroRede, 2000);
  
          // W1: no botão de Login/Registro, troca o spinner por "Fazendo login..." com pontinhos.
          (function installW1LoginDots(){
              var installed = false;
              var MIN_MS = 1600; // tempo mínimo (W1 costuma segurar um pouco mais mesmo com conexão rápida)
              function normalizeLabel(text){
                  var t = (text || '').trim().toLowerCase();
                  if (t.includes('registro') || t.includes('registr') || t.includes('cadastrar')) return 'Cadastrando';
                  return 'Fazendo login';
              }
              function clear(btn){
                  var start = 0;
                  try { start = parseInt(btn.getAttribute('data-wm-dots-start') || '0', 10) || 0; } catch(_e){ start = 0; }
                  var elapsed = start ? (Date.now() - start) : MIN_MS;
                  var wait = Math.max(0, MIN_MS - elapsed);
                  setTimeout(function(){
                      try { btn.removeAttribute('data-wm-dots-loading'); } catch(e){}
                      try { btn.removeAttribute('data-wm-dots-start'); } catch(e){}
                      var ov = btn.querySelector('._wm-login-loading');
                      if (ov) ov.remove();
                  }, wait);
              }
              function attach(){
                  if (installed) return;
                  installed = true;
  
                  document.addEventListener('click', function(ev){
                      var target = ev.target;
                      if (!target || !target.closest) return;
                      var btn = target.closest('button');
                      if (!btn) return;
                      if (!btn.closest('._submits_1s1bl_30')) return;
  
                      var textEl = btn.querySelector('.ui-button__text');
                      var label = normalizeLabel(textEl ? textEl.textContent : '');
  
                      btn.setAttribute('data-wm-dots-loading', '1');
                      btn.setAttribute('data-wm-dots-start', String(Date.now()));
  
                      var content = btn.querySelector('.ui-button__content') || btn;
                      var overlay = btn.querySelector('._wm-login-loading');
                      if (!overlay) {
                          overlay = document.createElement('span');
                          overlay.className = '_wm-login-loading';
                          overlay.innerHTML =
                              '<span class="_wm-login-loading-text"></span>'
                              + '<span class="_wm-dot">.</span><span class="_wm-dot">.</span><span class="_wm-dot">.</span>';
                          content.appendChild(overlay);
                      }
                      var labelEl = overlay.querySelector('._wm-login-loading-text');
                      if (labelEl) labelEl.textContent = label + ' ';
  
                      // Limpa quando o estado de loading/disabled some (ou quando o modal fecha).
                      var obs = new MutationObserver(function(){
                          if (!document.contains(btn)) { try { obs.disconnect(); } catch(e){}; return; }
                          var disabled = !!btn.disabled || btn.getAttribute('aria-disabled') === 'true';
                          var cls = btn.className || '';
                          var looksLoading = disabled || /loading/i.test(cls);
                          if (!looksLoading) {
                              try { obs.disconnect(); } catch(e){}
                              clear(btn);
                          }
                      });
                      try {
                          obs.observe(btn, { attributes: true, attributeFilter: ['class', 'disabled', 'aria-disabled'] });
                      } catch(e){}
  
                      // Fallback: não deixa preso para sempre.
                      setTimeout(function(){
                          if (!document.contains(btn)) return;
                          clear(btn);
                          try { obs.disconnect(); } catch(e){}
                      }, 60000);
                  }, true);
              }
  
              if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', attach);
              else attach();
          })();
  
          // Intercepta clique nos floats (fast entry): se não logado, abre login em vez do erro
          (function(){
              function isLoggedIn(){
                  try {
                      var appEl = document.querySelector('#app');
                      if(!appEl || !appEl.__vue_app__) return false;
                      var provides = appEl.__vue_app__._context.provides;
                      var pinia = null;
                      var syms = Object.getOwnPropertySymbols(provides);
                      for(var i=0;i<syms.length;i++){
                          var sv = provides[syms[i]];
                          if(sv && sv._s instanceof Map){ pinia = sv; break; }
                      }
                      if(!pinia) return false;
                      var userStore = pinia._s.get('user') || pinia._s.get('userInfo') || pinia._s.get('loginRegister');
                      if(userStore){
                          if(typeof userStore.isLogined !== 'undefined') return !!userStore.isLogined;
                          if(typeof userStore.hasLogined !== 'undefined') return !!userStore.hasLogined;
                          if(typeof userStore.token !== 'undefined') return !!userStore.token;
                      }
                      // fallback: procura qualquer store com hasLogined
                      var loggedIn = false;
                      pinia._s.forEach(function(store){
                          if(store && (store.hasLogined || store.isLogined)) loggedIn = true;
                      });
                      return loggedIn;
                  } catch(e){ return false; }
              }
  
              function openLogin(){
                  try {
                      var appEl = document.querySelector('#app');
                      if(!appEl || !appEl.__vue_app__) return;
                      var provides = appEl.__vue_app__._context.provides;
                      var pinia = null;
                      var syms = Object.getOwnPropertySymbols(provides);
                      for(var i=0;i<syms.length;i++){
                          var sv = provides[syms[i]];
                          if(sv && sv._s instanceof Map){ pinia = sv; break; }
                      }
                      if(!pinia) return;
                      var store = pinia._s.get('loginRegister');
                      if(store && store.openLoginRegister) store.openLoginRegister({});
                  } catch(e){}
              }
  
          document.addEventListener('click', function(e){
                  // Não interceptar clique no botão de fechar do float (deve funcionar logado ou não)
                  try {
                      var t0 = e.target;
                      for (var k0 = 0; k0 < 6 && t0; k0++) {
                          var c0 = (t0.className && typeof t0.className === 'string') ? t0.className : '';
                          if (t0.tagName === 'IMG' && (c0.indexOf('closeIcon') !== -1 || c0.indexOf('_closeIcon_') !== -1)) return;
                          t0 = t0.parentElement;
                      }
                  } catch (_e0) {}

                  // Verifica se o clique foi em um fast entry button
                  var tgt = e.target;
                  var el = tgt;
                  for(var i=0; i<8; i++){
                      if(!el) break;
                      var cls = (el.className && typeof el.className === 'string') ? el.className : '';
                      if(cls.indexOf('fastBtn') !== -1 || cls.indexOf('_fastBtn_') !== -1 || cls.indexOf('fastImg') !== -1 || cls.indexOf('_fastImg_') !== -1){
                          if(!isLoggedIn()){
                              e.stopImmediatePropagation();
                              e.preventDefault();
                              openLogin();
                              return;
                          }
                          break;
                      }
                      el = el.parentElement;
                  }
              }, true);
          })();
  
          if (typeof window.fetch !== 'undefined') {
              const originalFetch = window.fetch;
              window.fetch = function(...args) {
                  const url = args[0];
                  
                  if (typeof url === 'string' && url.includes('logoutGame')) {
  
                      return Promise.resolve({
                          ok: true,
                          status: 200,
                          statusText: 'OK',
                          json: function() {
                              return Promise.resolve({
                                  code: 1,
                                  msg: '返回成功',
                                  time: Date.now(),
                                  data: {
                                      game_gold: 0,
                                      code: 1,
                                      bonus: '0',
                                      totalGold: '0',
                                      bonusRequireBet: '0',
                                      auditMode: 1
                                  }
                              });
                          },
                          text: function() {
                              return Promise.resolve(JSON.stringify({
                                  code: 1,
                                  msg: '返回成功',
                                  time: Date.now(),
                                  data: {
                                      game_gold: 0,
                                      code: 1,
                                      bonus: '0',
                                      totalGold: '0',
                                      bonusRequireBet: '0',
                                      auditMode: 1
                                  }
                              }));
                          }
                      });
                  }
                  
                  return originalFetch.apply(this, args);
              };
          }
          
          if (typeof XMLHttpRequest !== 'undefined') {
              const originalOpen = XMLHttpRequest.prototype.open;
              const originalSend = XMLHttpRequest.prototype.send;
              
              XMLHttpRequest.prototype.open = function(method, url, ...rest) {
                  this._url = url;
                  return originalOpen.apply(this, [method, url, ...rest]);
              };
              
              XMLHttpRequest.prototype.send = function(...args) {
                  if (this._url && this._url.includes('logoutGame')) {
  
                      setTimeout(() => {
                          Object.defineProperty(this, 'status', { value: 200, writable: false });
                          Object.defineProperty(this, 'statusText', { value: 'OK', writable: false });
                          Object.defineProperty(this, 'responseText', { 
                              value: JSON.stringify({
                                  code: 1,
                                  msg: '返回成功',
                                  time: Date.now(),
                                  data: {
                                      game_gold: 0,
                                      code: 1,
                                      bonus: '0',
                                      totalGold: '0',
                                      bonusRequireBet: '0',
                                      auditMode: 1
                                  }
                              }), 
                              writable: false 
                          });
                          Object.defineProperty(this, 'readyState', { value: 4, writable: false });
                          
                          if (this.onreadystatechange) {
                              this.onreadystatechange();
                          }
                          if (this.onload) {
                              this.onload();
                          }
                      }, 10);
                      
                      return;
                  }
                  
                  return originalSend.apply(this, args);
              };
          }
          
      })();

        /* ========================================================== */
        /* RECENT subgame tabs cleanup */
        /* ========================================================== */
      /* Recent subgame tabs cleanup - keeps the native first tab and hides empty duplicates */
      (function() {
          'use strict';
  
          function isRecentSubgamePage() {
              try {
                  var url = new URL(window.location.href);
                  return url.pathname === '/home/subgame' && url.searchParams.get('gameCategoryId') === '100';
              } catch (_) {
                  return false;
              }
          }
  
          function getTabLabel(tab) {
              if (!tab) return '';
              var textEl = tab.querySelector('[class*="_text-box_"]');
              var text = textEl ? textEl.textContent : tab.textContent;
              return (text || '').replace(/\s+/g, ' ').trim();
          }
  
          function isMeaningfulRecentTab(tab, index) {
              var label = getTabLabel(tab);
              if (label) return true;
              if (index === 0) return true;
              return tab.classList.contains('ui-tab--active');
          }
  
          function cleanupRecentSubgameTabs() {
              if (!isRecentSubgamePage()) return;
  
              var navs = document.querySelectorAll('.ui-tabs__nav, [class*="_main_"][class*="ui-tabs__nav"]');
              navs.forEach(function(nav) {
                  var tabs = Array.prototype.slice.call(nav.querySelectorAll(':scope > .ui-tab'));
                  if (tabs.length <= 1) return;
  
                  var visibleCount = 0;
                  tabs.forEach(function(tab, index) {
                      var keep = isMeaningfulRecentTab(tab, index);
                      tab.style.display = keep ? '' : 'none';
                      if (keep) visibleCount++;
                  });
  
                  if (visibleCount === 0 && tabs[0]) {
                      tabs[0].style.display = '';
                  }
              });
          }
  
          cleanupRecentSubgameTabs();
  
          new MutationObserver(function() {
              cleanupRecentSubgameTabs();
          }).observe(document.documentElement, {
              childList: true,
              subtree: true,
              attributes: true,
              attributeFilter: ['class']
          });
  
          window.addEventListener('popstate', function() {
              setTimeout(cleanupRecentSubgameTabs, 80);
          });
      })();

  /* ========================================================== */
  /* MODAL DEPOSITO (W1 parity) */
  /* ========================================================== */
      /* ══════════════════════════════════════════════
         Deposit Modal Enhancer — W1 visual parity
      ══════════════════════════════════════════════ */
      (function() {
          'use strict';
  
          /* ── First-deposit bonus status ──
             Fetch once; if user already used their bonus, suppress all bonus UI. */
          var _bonusUsado = false;
          (function() {
              fetch('/hall/api/finance/pay/checkDepositBonus', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}', credentials:'include'})
                  .then(function(r) { return r.json(); })
                  .then(function(d) { if (d && d.bonusUsado) _bonusUsado = true; })
                  .catch(function() {});
          })();
  
          function findPinia() {
              try {
                  var appEl = document.querySelector('#app');
                  if (!appEl || !appEl.__vue_app__) return null;
                  var provides = appEl.__vue_app__._context.provides;
                  var syms = Object.getOwnPropertySymbols(provides);
                  for (var i = 0; i < syms.length; i++) {
                      var sv = provides[syms[i]];
                      if (sv && sv._s instanceof Map) return sv;
                  }
              } catch(_) {}
              return null;
          }
  
          function getBalanceStr() {
              try {
                  var pinia = findPinia();
                  if (!pinia) return '0,00';
                  var gold = null;
                  pinia._s.forEach(function(store) {
                      if (gold !== null) return;
                      var ui = store.userInfos;
                      if (ui && typeof ui.game_gold !== 'undefined') gold = parseFloat(ui.game_gold);
                      else if (typeof store.game_gold !== 'undefined') gold = parseFloat(store.game_gold);
                  });
                  if (gold === null) return '0,00';
                  return gold.toLocaleString('pt-BR', {minimumFractionDigits:2, maximumFractionDigits:2});
              } catch(_) { return '0,00'; }
          }
  
          /* parse "1.000" → 1000, "+50" → 50 */
          function parsePtBr(str) {
              return parseFloat((str||'').replace(/\+/g,'').replace(/\./g,'').replace(',','.')) || 0;
          }
  
          var _wmDepositOpenMeta = { source: null, ts: 0 };
  
          function markDepositOpenSource(source) {
              _wmDepositOpenMeta = {
                  source: source || 'unknown',
                  ts: Date.now()
              };
          }
  
          function getRecentDepositOpenSource() {
              if (!_wmDepositOpenMeta.ts) return null;
              if (Date.now() - _wmDepositOpenMeta.ts > 2500) return null;
              return _wmDepositOpenMeta.source;
          }
  
          function getActiveAmount(modal) {
              var item = modal.querySelector('._recommend-amount_1o0k6_41 ._item_9a274_34._active_9a274_117');
              if (item) {
                  var el = item.querySelector('._label_9a274_49');
                  if (el) return parsePtBr(el.textContent);
              }
              /* fallback: read from typed input */
              var input = modal.querySelector('._amount-input_1o0k6_56 input, input._input_9a274_1, ._recommend-amount_1o0k6_41 input');
              if (!input) input = modal.querySelector('input[type="text"], input[type="number"], input:not([type="hidden"])');
              if (input && input.value) return parsePtBr(input.value) || 0;
              return 0;
          }
  
          function getActiveBonus(modal) {
              var item = modal.querySelector('._recommend-amount_1o0k6_41 ._item_9a274_34._active_9a274_117');
              if (item) {
                  /* prefer our injected bonus row, fall back to original badge */
                  var el = item.querySelector('._wm-bonus-row') || item.querySelector('.ui-badge__content');
                  return el ? parsePtBr(el.textContent) : 0;
              }
              /* for typed amount: find best matching button (highest btn amount ≤ typed amount) */
              var input = modal.querySelector('._amount-input_1o0k6_56 input, input._input_9a274_1, ._recommend-amount_1o0k6_41 input');
              if (!input) input = modal.querySelector('input[type="text"], input[type="number"], input:not([type="hidden"])');
              if (input && input.value) {
                  var typedAmt = parsePtBr(input.value);
                  var items = modal.querySelectorAll('._recommend-amount_1o0k6_41 ._item_9a274_34');
                  var bestBonus = 0, bestAmt = -1;
                  for (var i = 0; i < items.length; i++) {
                      var labelEl = items[i].querySelector('._label_9a274_49');
                      if (!labelEl) continue;
                      var btnAmt = parsePtBr(labelEl.textContent);
                      if (btnAmt <= typedAmt && btnAmt > bestAmt) {
                          var bonusEl = items[i].querySelector('._wm-bonus-row') || items[i].querySelector('.ui-badge__content');
                          var bonusVal = bonusEl ? parsePtBr(bonusEl.textContent) : 0;
                          if (bonusVal > 0) {
                              bestAmt   = btnAmt;
                              bestBonus = bonusVal;
                          }
                      }
                  }
                  return bestBonus;
              }
              return 0;
          }
  
          /* Return the bonus tier amount that applies to the current selection/typed value.
             - If a button is active, use its amount (e.g. 100).
             - If user typed a value, pick the best tier (highest btn amount <= typed) that has a bonus.
             - If nothing matches, fall back to the smallest tier (typically 50). */
          function getActiveBonusTierAmount(modal) {
              var item = modal.querySelector('._recommend-amount_1o0k6_41 ._item_9a274_34._active_9a274_117');
              if (item) {
                  var el = item.querySelector('._label_9a274_49');
                  return el ? (parsePtBr(el.textContent) || 0) : 0;
              }
  
              var input = modal.querySelector('._amount-input_1o0k6_56 input, input._input_9a274_1, ._recommend-amount_1o0k6_41 input');
              if (!input) input = modal.querySelector('input[type="text"], input[type="number"], input:not([type="hidden"])');
              var typedAmt = (input && input.value) ? parsePtBr(input.value) : 0;
  
              var items = modal.querySelectorAll('._recommend-amount_1o0k6_41 ._item_9a274_34');
              var bestAmt = 0;
              var minAmt = 0;
              for (var i = 0; i < items.length; i++) {
                  var labelEl = items[i].querySelector('._label_9a274_49');
                  if (!labelEl) continue;
                  var btnAmt = parsePtBr(labelEl.textContent);
                  if (!minAmt || (btnAmt > 0 && btnAmt < minAmt)) minAmt = btnAmt;
  
                  var bonusEl = items[i].querySelector('._wm-bonus-row') || items[i].querySelector('.ui-badge__content');
                  var bonusVal = bonusEl ? parsePtBr(bonusEl.textContent) : 0;
                  if (bonusVal <= 0) continue;
  
                  if (typedAmt >= btnAmt && btnAmt > bestAmt) bestAmt = btnAmt;
              }
  
              return bestAmt || minAmt || 50;
          }
  
          function isHeaderActionTarget(modal, target) {
              try {
                  if (!modal || !target || !target.closest) return false;
                  var clickable = target.closest('button,[role="button"],.ui-button,.ui-popup__close,[class*="_header_"] i,[class*="_header_"] svg');
                  if (!clickable || !modal.contains(clickable)) return false;
  
                  var modalRect = modal.getBoundingClientRect();
                  var rect = clickable.getBoundingClientRect();
                  var headerBottom = modalRect.top + Math.min(96, Math.max(64, modalRect.height * 0.18));
  
                  if (rect.bottom > headerBottom) return false;
                  if (rect.width < 20 || rect.height < 20) return false;
  
                  return true;
              } catch (_) {
                  return false;
              }
          }
  
          function isTopHeaderDepositTrigger(target) {
              try {
                  if (!target || !target.closest) return false;
                  return !!target.closest('#depositClick, ._reCharge_1wuau_54, #gn-deposit-btn');
              } catch (_) {
                  return false;
              }
          }
  
          function isBottomNavDepositTrigger(target) {
              try {
                  if (!target || !target.closest) return false;
                  var tab = target.closest('.ui-tab, [id^="ui-tabs-"]');
                  if (!tab) return false;
                  return /dep[oó]sito/i.test((tab.textContent || '').trim());
              } catch (_) {
                  return false;
              }
          }
  
          function findBottomNavDepositTrigger() {
              try {
                  var tabs = document.querySelectorAll('.ui-tab, [id^="ui-tabs-"]');
                  for (var i = 0; i < tabs.length; i++) {
                      if (/dep[oó]sito/i.test((tabs[i].textContent || '').trim())) {
                          return tabs[i];
                      }
                  }
              } catch (_) {}
              return null;
          }
  
          function rerouteHeaderDepositToBottomNav(e) {
              try {
                  var trigger = e.target && e.target.closest
                      ? e.target.closest('#depositClick, ._reCharge_1wuau_54, #gn-deposit-btn')
                      : null;
                  if (!trigger) return false;
  
                  var bottomNavTrigger = findBottomNavDepositTrigger();
                  if (!bottomNavTrigger) return false;
  
                  markDepositOpenSource('bottomnav');
                  e.preventDefault();
                  e.stopPropagation();
                  if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
  
                  setTimeout(function() {
                      try { bottomNavTrigger.click(); } catch (_) {}
                  }, 0);
                  return true;
              } catch (_) {
                  return false;
              }
          }
  
          function isModalStillVisible(modal) {
              if (!modal || !modal.isConnected) return false;
              var rect = modal.getBoundingClientRect();
              var style = window.getComputedStyle(modal);
              return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
          }
  
          function installHeaderCloseBridge(modal) {
              if (!modal || modal._wmHeaderCloseBridgeDone) return;
              modal._wmHeaderCloseBridgeDone = true;
  
              modal.addEventListener('click', function(e) {
                  if (!modal._wmOpenedFromHeader) return;
                  if (modal._wmAutoClosing) return;
                  if (!isHeaderActionTarget(modal, e.target)) return;
  
                  var target = e.target.closest('button,[role="button"],.ui-popup__close,[class*="_header_"] i,[class*="_header_"] svg') || e.target;
                  setTimeout(function() {
                      if (!isModalStillVisible(modal)) return;
                      if (!target || !target.isConnected || typeof target.click !== 'function') return;
                      modal._wmAutoClosing = true;
                      try { target.click(); } catch (_) {}
                      setTimeout(function() { modal._wmAutoClosing = false; }, 220);
                  }, 120);
              }, true);
          }
  
          /* ── 1. "Método de Pagamento" + balance header (uses W1 currency-info-box classes) ── */
          function injectMethodHeader(modal) {
              if (modal.querySelector('._wm-method-hdr')) return;
              var placeholder = modal.querySelector('._content_1m3jl_96, .ui-placeholder');
              if (!placeholder) return;
  
              /* Grab BRL flag img src from whatever is already in the DOM */
              var currImgUrl = '';
              var existImg = document.querySelector('img._icon-currency_1gbcf_80[src], img[alt="."][src*="BRL"]');
              if (existImg) currImgUrl = existImg.src;
  
              /* Grab the frame background-image from the existing currency box */
              var frameBgAttr = '';
              var existFrame = document.querySelector('._currency-box_1gbcf_70[style]');
              if (existFrame) frameBgAttr = ' style="' + existFrame.getAttribute('style') + '"';
  
              var div = document.createElement('div');
              div.className = '_wm-method-hdr';
              div.style.cssText = 'display:flex;align-items:center;justify-content:space-between;'
                  + 'padding:.12rem .2rem .1rem;'
                  + 'border-top:var(--lobby__px,1px) solid var(--skin__border,rgba(255,255,255,.08));';
              div.innerHTML =
                  '<span style="font-size:.22rem;font-weight:600;color:#fff!important;">M\u00e9todo de Pagamento</span>'
                  + '<div class="_currency-info-box_1gbcf_30 currency-info-box" style="cursor:default;">'
                  + '<div class="lobby-image lobby-image--use-bg _currency-box_1gbcf_70"' + frameBgAttr + '>'
                  + (currImgUrl
                      ? '<img class="lobby-image _icon-currency_1gbcf_80" src="' + currImgUrl + '" alt=".">'
                      : '<span style="font-size:.32rem;line-height:1;">\uD83C\uDDE7\uD83C\uDDF7</span>')
                  + '</div>'
                  + '<div class="_currency-info_1gbcf_30 currency-info-custom">'
                  + '<div class="_currency-content-wrap_1gbcf_132">'
                  + '<div class="_currency-count_1gbcf_90" dir="ltr"><span class="_wm-bal">' + getBalanceStr() + '</span></div>'
                  + '</div>'
                  + '<div class="_icon-content_1gbcf_118 icon-content _refresh-icon_1gbcf_178">'
                  + '<i style="display:inline-flex;justify-content:center;align-items:center;">'
                  + '<svg width="1em" height="1em" fill="currentColor"><use xlink:href="#comm_icon_sx"></use></svg>'
                  + '</i>'
                  + '</div>'
                  + '</div>'
                  + '</div>';
  
              placeholder.insertBefore(div, placeholder.firstChild);
  
              /* passive balance poll from Pinia */
              setInterval(function() {
                  var el = div.querySelector('._wm-bal');
                  if (el && document.body.contains(div)) el.textContent = getBalanceStr();
              }, 1500);
  
              /* inject spin keyframe once */
              if (!document.getElementById('_wm-spin-style')) {
                  var ks = document.createElement('style');
                  ks.id = '_wm-spin-style';
                  ks.textContent = '@keyframes _wmSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}';
                  document.head.appendChild(ks);
              }
  
              /* refresh icon — fetches live balance from API */
              var refreshWrap = div.querySelector('._refresh-icon_1gbcf_178');
              if (refreshWrap) {
                  refreshWrap.style.cursor = 'pointer';
                  refreshWrap.addEventListener('click', function() {
                      var iconI = refreshWrap.querySelector('i');
                      if (iconI) iconI.style.animation = '_wmSpin 0.7s linear infinite';
  
                      fetch('/hall/api/gameCenter/gameApi/logout', {
                          method: 'POST',
                          headers: {'Content-Type': 'application/json'},
                          body: JSON.stringify({gameId: 0})
                      })
                      .then(function(r) { return r.json(); })
                      .then(function(json) {
                          var gold = json && json.data && typeof json.data.game_gold !== 'undefined'
                              ? parseFloat(json.data.game_gold)
                              : null;
                          if (gold !== null && !isNaN(gold)) {
                              var balEl = div.querySelector('._wm-bal');
                              if (balEl) balEl.textContent = gold.toLocaleString('pt-BR', {minimumFractionDigits:2, maximumFractionDigits:2});
                          }
                      })
                      .catch(function(){})
                      .then(function() {
                          if (iconI) iconI.style.animation = '';
                      });
                  });
              }
          }
  
          /* ── 2. Hide unwanted elements ── */
          function hideWarnTips(modal) {
              var tips = modal.querySelector('._warn-tips_7i1n5_30');
              if (tips) tips.style.display = 'none';
          }
  
          function hideAllCorners(modal) {
              modal.querySelectorAll('._corner_9a274_89').forEach(function(el) {
                  el.style.display = 'none';
              });
          }
  
          /* Make the existing provider-grid item look like W1 (icon on top, text below) */
          function ensureGrupoW1PixCard(modal) {
              if (!modal) return;
  
              /* Remove any previously injected duplicate */
              modal.querySelectorAll('.wm-deposit-provider-card').forEach(function(el) {
                  try { el.remove(); } catch(_) {}
              });
  
              /* Prefer the requested remote URL (and keep SVG fallback for WebViews without AVIF) */
              var ICON_URL = '/assets/images/finance-1703844434990-456885.avif';
              /* AVIF pode falhar em alguns WebViews; use SVG inline como fallback estável */
              var ICON_SVG = ''
                  + '<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\">'
                  + '<g transform=\"translate(32 32) rotate(45) translate(-32 -32)\">'
                  + '<rect x=\"18\" y=\"18\" width=\"14\" height=\"14\" rx=\"3\" fill=\"#14cbb8\"/>'
                  + '<rect x=\"32\" y=\"18\" width=\"14\" height=\"14\" rx=\"3\" fill=\"#14cbb8\"/>'
                  + '<rect x=\"18\" y=\"32\" width=\"14\" height=\"14\" rx=\"3\" fill=\"#14cbb8\"/>'
                  + '<rect x=\"32\" y=\"32\" width=\"14\" height=\"14\" rx=\"3\" fill=\"#14cbb8\"/>'
                  + '</g>'
                  + '</svg>';
              var ICON_DATA = 'data:image/svg+xml,' + encodeURIComponent(ICON_SVG)
                  .replace(/'/g, '%27').replace(/\"/g, '%22');
  
              /* Also update the native <img> src so DOM shows the right URL too */
              try {
                  var pg = modal.querySelector('._online_4x35f_30 > ._grid_9a274_30:not(._channel_1bpdc_30)');
                  if (pg) {
                      var img0 = pg.querySelector('img._icon_9a274_43');
                      if (img0) {
                          img0.setAttribute('src', ICON_URL);
                          img0.setAttribute('data-src', ICON_URL);
                      }
                      var lbl0 = pg.querySelector('._item_9a274_34:first-child ._label_9a274_49');
                      if (lbl0) lbl0.textContent = 'Grupo W1...';
                  }
              } catch(_) {}
  
              /* Vue keeps re-rendering this grid; DOM edits won't stick reliably.
                 Force the look via CSS: hide native <img> and draw our icon using ::before. */
              var st = document.getElementById('_wm-provider-css-v2');
              if (!st) {
                  st = document.createElement('style');
                  st.id = '_wm-provider-css-v2';
                  document.head.appendChild(st);
              }
              /* Refresh only if changed (avoids expensive style recalculation loops) */
              var nextCss = [
                      /* Provider grid (not channel grid) */
                      '._main-recharge_1m3jl_30 ._online_4x35f_30 > ._grid_9a274_30:not(._channel_1bpdc_30){',
                      '  justify-content:flex-start!important;',
                      '  align-items:flex-start!important;',
                      '  gap:.14rem!important;',
                      '}',
                      /* Only first provider item (Grupo W1-PIX in our layout) */
                      '._main-recharge_1m3jl_30 ._online_4x35f_30 > ._grid_9a274_30:not(._channel_1bpdc_30) ._item_9a274_34:first-child{',
                      '  display:flex!important;flex-direction:column!important;',
                      '  align-items:center!important;justify-content:flex-start!important;',
                      '  padding:.06rem .08rem .08rem!important;gap:.04rem!important;',
                      '  border-radius:.12rem!important;',
                      '  background:color-mix(in srgb,var(--skin__primary,#06d0df) 14%, transparent)!important;',
                      '  overflow:hidden!important;',
                      '  box-sizing:border-box!important;',
                      '  height:auto!important;min-height:0.98rem!important;',
                      '  width:1.28rem!important;max-width:45vw!important;',
                      '  justify-self:start!important;align-self:start!important;',
                      '  grid-column:auto!important;grid-row:auto!important;',
                      '}',
                      '._main-recharge_1m3jl_30 ._online_4x35f_30 > ._grid_9a274_30:not(._channel_1bpdc_30) ._item_9a274_34:first-child img._icon_9a274_43{',
                      '  display:none!important;',
                      '}',
                      '._main-recharge_1m3jl_30 ._online_4x35f_30 > ._grid_9a274_30:not(._channel_1bpdc_30) ._item_9a274_34:first-child::before{',
                      '  content:\"\";',
                      '  width:.54rem;height:.54rem;',
                      '  background:#fff;',
                      '  border-radius:.08rem;',
                      '  background-image:url(\"' + ICON_URL + '\"),url(\"' + ICON_DATA + '\");',
                      '  background-size:92% 92%;',
                      '  background-repeat:no-repeat;',
                      '  background-position:center;',
                      '  flex-shrink:0;',
                      '  display:block;',
                      '}',
                      '._main-recharge_1m3jl_30 ._online_4x35f_30 > ._grid_9a274_30:not(._channel_1bpdc_30) ._item_9a274_34:first-child ._label-container_9a274_49{',
                      '  padding:0!important;margin:0!important;width:100%!important;',
                      '}',
                      '._main-recharge_1m3jl_30 ._online_4x35f_30 > ._grid_9a274_30:not(._channel_1bpdc_30) ._item_9a274_34:first-child ._label_9a274_49{',
                      '  color:var(--skin__primary,#06d0df)!important;',
                      '  font-size:.19rem!important;font-weight:600!important;line-height:1.0!important;',
                      '  padding:0!important;margin:0!important;',
                      '  max-width:1.12rem!important;text-align:center!important;',
                      '  white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;',
                      '}',
  
                      /* Channel grid (BRL-PIX) should be 2x2 like W1 */
                      '._main-recharge_1m3jl_30 ._grid_9a274_30._channel_1bpdc_30{',
                      '  grid-template-columns:repeat(2,1fr)!important;',
                      '  gap:.14rem!important;',
                      '}',
                      '._main-recharge_1m3jl_30 ._grid_9a274_30._channel_1bpdc_30 ._item_9a274_34{',
                      '  background:color-mix(in srgb,var(--skin__primary,#06d0df) 10%, transparent)!important;',
                      '  border-color:color-mix(in srgb,var(--skin__primary,#06d0df) 35%, transparent)!important;',
                      '}',
                      '._main-recharge_1m3jl_30 ._grid_9a274_30._channel_1bpdc_30 ._item_9a274_34._active_9a274_117{',
                      '  background:color-mix(in srgb,var(--skin__primary,#06d0df) 16%, transparent)!important;',
                      '  border-color:color-mix(in srgb,var(--skin__primary,#06d0df) 75%, transparent)!important;',
                      '}',
                      '._main-recharge_1m3jl_30 ._grid_9a274_30._channel_1bpdc_30 ._item_9a274_34._active_9a274_117 ._label_9a274_49{',
                      '  color:var(--skin__primary,#06d0df)!important;',
                      '}',
                  ].join('');
              if (st.textContent !== nextCss) st.textContent = nextCss;
  
              return;
  
              /* Ensure hidden items stay hidden even if Vue touches inline styles */
              if (!document.getElementById('_wm-provider-hide-style')) {
                  var stHide = document.createElement('style');
                  stHide.id = '_wm-provider-hide-style';
                  stHide.textContent =
                      '._main-recharge_1m3jl_30 [data-wm-provider-hidden=\"1\"]{display:none!important;}'
                      + '._main-recharge_1m3jl_30 [data-wm-provider-clone=\"1\"]{display:flex!important;}';
                  document.head.appendChild(stHide);
              }
  
              /* We will HIDE the native horizontal item (Vue keeps overwriting its layout),
                 and inject a cloned card that matches W1; clicking it triggers the hidden item. */
              function ensureClone(providerGrid, nativeItem) {
                  if (!providerGrid || !nativeItem) return;
  
                  /* Replace clone (Vue can re-render the grid and bring back the native item) */
                  providerGrid.querySelectorAll('[data-wm-provider-clone="1"]').forEach(function(el) {
                      try { el.remove(); } catch(_) {}
                  });
  
                  var clone = document.createElement('div');
                  clone.setAttribute('data-wm-provider-clone', '1');
                  clone.className = (nativeItem.className || 'ui-badge__wrapper _item_9a274_34');
  
                  /* Force W1-like square layout */
                  clone.style.setProperty('display', 'flex', 'important');
                  clone.style.setProperty('flex-direction', 'column', 'important');
                  clone.style.setProperty('align-items', 'flex-start', 'important');
                  clone.style.setProperty('justify-content', 'flex-start', 'important');
                  clone.style.setProperty('padding', '.14rem .14rem .12rem', 'important');
                  clone.style.setProperty('gap', '.10rem', 'important');
                  clone.style.setProperty('border-radius', '.12rem', 'important');
                  clone.style.setProperty('background', 'rgba(0,0,0,.06)', 'important');
                  clone.style.setProperty('overflow', 'hidden', 'important');
                  clone.style.setProperty('width', '1.9rem', 'important');
                  clone.style.setProperty('max-width', '60vw', 'important');
                  clone.style.setProperty('justify-self', 'start', 'important');
                  clone.style.setProperty('align-self', 'start', 'important');
                  clone.style.setProperty('grid-column', 'auto', 'important');
  
                  /* Icon box */
                  var box = document.createElement('div');
                  box.className = 'wm-provider-iconbox';
                  box.style.cssText =
                      'width:.62rem;height:.62rem;background:#fff;border-radius:.08rem;'
                      + 'display:flex;align-items:center;justify-content:center;overflow:hidden;';
                  var img = document.createElement('img');
                  img.alt = '.';
                  img.src = ICON_URL;
                  img.style.cssText = 'width:100%;height:100%;object-fit:contain;display:block;';
                  box.appendChild(img);
  
                  /* Label */
                  var lc = document.createElement('div');
                  lc.className = '_label-container_9a274_49';
                  lc.style.cssText = 'padding:0;margin:0;width:100%;';
                  var sp = document.createElement('span');
                  sp.className = '_label_9a274_49';
                  sp.setAttribute('dir', 'ltr');
                  sp.textContent = 'Grupo W1-PIX';
                  sp.style.cssText =
                      'color:var(--skin__primary,#06d0df)!important;'
                      + 'font-size:.22rem!important;font-weight:600!important;line-height:1.2!important;'
                      + 'max-width:1.10rem!important;text-align:left!important;'
                      + 'white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;';
                  lc.appendChild(sp);
  
                  clone.appendChild(box);
                  clone.appendChild(lc);
  
                  /* Clicking the clone should behave like clicking the original item */
                  clone.addEventListener('click', function(e) {
                      e.preventDefault();
                      e.stopPropagation();
                      try { nativeItem.click(); } catch(_) {}
                  }, true);
  
                  /* Insert at top of provider grid */
                  providerGrid.insertBefore(clone, providerGrid.firstChild);
              }
  
              /* Provider grid is the one that contains _icon_9a274_43 */
              var providerGrid = null;
              modal.querySelectorAll('._grid_9a274_30').forEach(function(g) {
                  if (providerGrid) return;
                  if (g.querySelector('img._icon_9a274_43')) providerGrid = g;
              });
              if (!providerGrid) return;
  
              /* Make the provider grid not stretch the single item into a full-width "button" */
              providerGrid.style.setProperty('justify-content', 'flex-start', 'important');
              providerGrid.style.setProperty('align-items', 'flex-start', 'important');
              providerGrid.style.setProperty('gap', '.14rem', 'important');
  
              var natives = [];
              providerGrid.querySelectorAll('._item_9a274_34').forEach(function(item) {
                  var label = item.querySelector('._label_9a274_49');
                  if (!label) return;
                  var txt = (label.textContent || '').trim();
                  if (!/Grupo\\s*W1-PIX/i.test(txt)) return;
                  natives.push(item);
              });
              if (!natives.length) return;
  
              /* Hide ALL native items (Vue may create duplicates) */
              natives.forEach(function(item) {
                  item.setAttribute('data-wm-provider-hidden', '1');
  
                  var badge = item.querySelector('.ui-badge.ui-badge--fixed');
                  if (badge) badge.style.display = 'none';
                  var corner = item.querySelector('._corner_9a274_89');
                  if (corner) corner.style.display = 'none';
  
                  if (item.dataset) item.dataset._wmProviderCardDone = '1';
              });
  
              /* Recreate the clone on top from the first native item */
              ensureClone(providerGrid, natives[0]);
          }
  
          /* Provider enforcer: Vue can update without adding nodes (attribute-only). Observe the provider grid only. */
          function installProviderEnforcer(modal) {
              if (!modal || modal._wmProviderEnforcer) return;
              /* Provider card is now forced via CSS; no need for an attribute observer (expensive). */
              if (document.getElementById('_wm-provider-css-v2')) return;
              modal._wmProviderEnforcer = true;
  
              function findProviderGrid() {
                  var pg = null;
                  modal.querySelectorAll('._grid_9a274_30').forEach(function(g) {
                      if (pg) return;
                      if (g.querySelector('img._icon_9a274_43') || g.querySelector('[data-wm-provider-clone=\"1\"]')) pg = g;
                  });
                  return pg;
              }
  
              var raf = 0;
              function schedule() {
                  if (raf) return;
                  raf = requestAnimationFrame(function() {
                      raf = 0;
                      try { ensureGrupoW1PixCard(modal); } catch(_) {}
                  });
              }
  
              var pg0 = findProviderGrid();
              if (pg0) schedule();
  
              /* Observe modal subtree for provider grid changes, but cheap: only schedule via RAF */
              try {
                  new MutationObserver(function(muts) {
                      for (var i = 0; i < muts.length; i++) {
                          var t = muts[i].target;
                          if (!t || t.nodeType !== 1) continue;
                          var cls = typeof t.className === 'string' ? t.className : '';
                          if (cls.indexOf('_grid_9a274_30') !== -1 || cls.indexOf('_item_9a274_34') !== -1) {
                              schedule();
                              return;
                          }
                          if (t.closest && (t.closest('._grid_9a274_30') || t.closest('._item_9a274_34'))) {
                              schedule();
                              return;
                          }
                      }
                  }).observe(modal, {subtree:true, childList:true, attributes:true, attributeFilter:['class','style','src','data-src']});
              } catch(_) {}
          }
  
          /* Show provider grid (W1 card) and add BRL-PIX range text (lightweight + idempotent) */
          function hideProviderGrid(modal) {
              var RANGE_TEXT = '(R$10-50000)';
  
              modal.querySelectorAll('._grid_9a274_30').forEach(function(grid) {
                  var isProviderGrid = !!grid.querySelector('._icon_9a274_43');
                  var isChannelGrid = grid.classList && grid.classList.contains('_channel_1bpdc_30');
  
                  if (isProviderGrid) {
                      /* Previously we hid it — now just ensure it's visible, without forcing layout. */
                      if (grid.style && grid.style.display === 'none') grid.style.removeProperty('display');
                      var next = grid.nextElementSibling;
                      if (next && next.className && next.className.indexOf('_line_1vtak_30') !== -1) {
                          if (next.style && next.style.display === 'none') next.style.removeProperty('display');
                      }
                      return;
                  }
  
                  if (isChannelGrid) {
                      grid.querySelectorAll('._item_9a274_34').forEach(function(item) {
                          if (item.dataset && item.dataset._wmPixRangeDone === '1') return;
  
                          var lc = item.querySelector('._label-container_9a274_49');
                          var labelEl = lc ? lc.querySelector('._label_9a274_49') : null;
                          if (!lc || !labelEl) return;
  
                          var raw = (labelEl.textContent || '').trim();
                          if (raw !== 'BRL-PIX') return;
  
                          if (!lc.querySelector('.wm-deposit-range')) {
                              lc.style.setProperty('display', 'flex', 'important');
                              lc.style.setProperty('flex-direction', 'column', 'important');
                              lc.style.setProperty('align-items', 'center', 'important');
                              lc.style.setProperty('justify-content', 'center', 'important');
  
                               var range = document.createElement('span');
                               range.className = 'wm-deposit-range';
                               range.textContent = RANGE_TEXT;
                               range.style.cssText =
                                   'font-size:.18rem;'
                                   + 'font-weight:500;'
                                   + 'line-height:1.1;'
                                   + 'margin-top:.02rem;'
                                   + 'color:rgba(255,255,255,.55);'
                                   + 'text-align:center;'
                                   + 'white-space:nowrap;';
                               lc.appendChild(range);
                           }
  
                          item.dataset._wmPixRangeDone = '1';
                      });
                      return;
                  }
  
                  /* fallback: keep existing active colour tweak */
                  grid.querySelectorAll('._item_9a274_34').forEach(function(item) {
                      var labelEl = item.querySelector('._label_9a274_49');
                      var isActive = /_active_/.test(item.className || '');
                      if (!labelEl) return;
                      labelEl.style.setProperty('color', isActive ? '#ff1f3d' : '#fff', 'important');
                  });
              });
          }
  
          /* ── 3. Transform amount buttons → two-row layout with bonus bg ── */
          function transformAmountBtns(modal) {
              var grid = modal.querySelector('._recommend-amount_1o0k6_41');
              if (!grid) return;
              grid.querySelectorAll('._item_9a274_34').forEach(function(item) {
                  if (item._wmBtn) return;
                  var labelEl = item.querySelector('._label_9a274_49');
                  if (!labelEl) return;
                  item._wmBtn = true;
  
                  var badgeEl = item.querySelector('.ui-badge__content');
                  var bonus   = badgeEl ? badgeEl.textContent.trim() : '';
  
                  /* hide floating badge (corner already hidden by hideAllCorners) */
                  var badge = item.querySelector('.ui-badge.ui-badge--fixed');
                  if (badge) badge.style.display = 'none';
  
                  /* Make item a flex column — overrides W1 scoped CSS with !important */
                  item.style.setProperty('display',        'flex',    'important');
                  item.style.setProperty('flex-direction', 'column',  'important');
                  item.style.setProperty('align-items',    'stretch', 'important');
                  item.style.setProperty('padding',        '0',       'important');
                  item.style.setProperty('overflow',       'hidden',  'important');
  
                  var lc = item.querySelector('._label-container_9a274_49');
                  if (lc) {
                      /* label-container fills the item via flex:1 */
                      lc.style.setProperty('flex',           '1',       'important');
                      lc.style.setProperty('display',        'flex',    'important');
                      lc.style.setProperty('flex-direction', 'column',  'important');
                      lc.style.setProperty('align-items',    'stretch', 'important');
                      lc.style.setProperty('width',          '100%',    'important');
                      lc.style.setProperty('padding',        '0',       'important');
                      lc.style.setProperty('box-sizing',     'border-box', 'important');
                      lc.style.setProperty('gap',            '0',       'important');
                      lc.style.setProperty('overflow',       'hidden',  'important');
                      lc.classList.remove('_ml_9a274_62');
                      labelEl.style.cssText = 'font-size:.22rem;font-weight:600;'
                          + 'color:var(--skin__text_primary,#fff);line-height:1.3;'
                          + 'text-align:center;padding:.07rem .1rem .05rem;display:block;';
                      if (bonus && !_bonusUsado && !lc.querySelector('._wm-bonus-row')) {
                          var bonusEl = document.createElement('div');
                          bonusEl.className = '_wm-bonus-row';
                          bonusEl.style.cssText = 'font-size:.18rem;font-weight:600;color:#FFAA09;'
                              + 'text-align:center;padding:.05rem .04rem .07rem;'
                              + 'background:color-mix(in srgb,var(--skin__accent_3,#FFAA09) 15%,transparent);';
                          var bonusNum = parsePtBr(bonus);
                          bonusEl.textContent = '+' + bonusNum.toLocaleString('pt-BR', {minimumFractionDigits:2, maximumFractionDigits:2});
                          lc.appendChild(bonusEl);
                      }
                  }
              });
          }
  
          /* gift image URLs — local path, fallback to W1 CDN */
          /* Remove the "active" filled treatment: keep selection only via border */
          function normalizeRecommendAmountStyles(modal) {
              var grid = modal && modal.querySelector ? modal.querySelector('._recommend-amount_1o0k6_41') : null;
              if (!grid) return;
  
              grid.querySelectorAll('._item_9a274_34').forEach(function(item) {
                  var isActive = item.classList && item.classList.contains('_active_9a274_117');
                  var labelEl = item.querySelector('._label_9a274_49');
                  var bonusRow = item.querySelector('._wm-bonus-row');
  
                  /* Vue sets active color inline with !important: force white always */
                  if (labelEl) {
                      labelEl.style.setProperty('color', '#fff', 'important');
                      /* Some builds use text-fill for colored numbers; lock it too */
                      labelEl.style.setProperty('-webkit-text-fill-color', '#fff', 'important');
                  }
  
                  /* W1 style: all amount buttons have a subtle background; active differs by border only */
                  item.style.setProperty(
                      'background',
                      'color-mix(in srgb,var(--skin__primary,#06d0df) 10%, transparent)',
                      'important'
                  );
                  item.style.setProperty('box-shadow', 'none', 'important');
  
                  /* Bottom bonus band stays gold/yellow like W1 */
                  if (bonusRow) {
                      bonusRow.style.setProperty(
                          'background',
                          'color-mix(in srgb,var(--skin__accent_3,#FFAA09) 15%, transparent)',
                          'important'
                      );
                  }
  
                  /* Border-only selection (no label color change) */
                  item.style.setProperty(
                      'border-color',
                      isActive
                          ? 'color-mix(in srgb,var(--skin__primary,#06d0df) 78%, transparent)'
                          : 'color-mix(in srgb,var(--skin__primary,#06d0df) 35%, transparent)',
                      'important'
                  );
              });
          }
  
          /* Vue can rewrite inline styles on the active item; keep the "value" label white via a tiny observer */
          function installRecommendAmountEnforcer(modal) {
              if (!modal || modal._wmRecAmtEnforcer) return;
              var grid = modal.querySelector && modal.querySelector('._recommend-amount_1o0k6_41');
              if (!grid) return;
              modal._wmRecAmtEnforcer = true;
  
              var raf = 0;
              function schedule() {
                  if (raf) return;
                  raf = requestAnimationFrame(function() {
                      raf = 0;
                      try { normalizeRecommendAmountStyles(modal); } catch(_) {}
                  });
              }
  
              schedule();
              try {
                  new MutationObserver(function() { schedule(); })
                      .observe(grid, {subtree:true, childList:true, attributes:true, attributeFilter:['class','style']});
              } catch(_) {}
          }
  
          var GIFT_IMG_COLOR = '/siteadmin/skin/lobby_asset/common/common/deposit/img_czjl_mccz.avif';
          var GIFT_IMG_GREY  = '/siteadmin/skin/lobby_asset/common/common/deposit/img_czjl_je2.avif';
          var GIFT_IMG_COLOR_FB = '/assets/images/img_czjl_mccz.avif';
          var GIFT_IMG_GREY_FB  = '/assets/images/img_czjl_je2.avif';
          var TIMER_IMG_LOCAL   = '/siteadmin/skin/lobby_asset/common/common/deposit/img_czjl_xs.avif';
          var TIMER_IMG_FB      = '/assets/images/img_czjl_xs.avif';
          var CHECK_SVG = '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 20 15">'
              + '<path d="M1234.22-597.615l-6.584-5.628a1.524,1.524,0,0,1-.149-2.141,1.5,1.5,0,0,1,2.128-.15'
              + 'l5.438,4.648,9.417-10.834a1.5,1.5,0,0,1,2.128-.15,1.525,1.525,0,0,1,.149,2.141'
              + 'l-10.4,11.964a1.5,1.5,0,0,1-1.139.522A1.494,1.494,0,0,1,1234.22-597.615Z"'
              + ' transform="translate(-1227.117 612.242)" fill="#04BE02"></path></svg>';
  
          /* ── 4. "Oferta de Depósito" card ── */
          function injectOfertaSection(modal) {
              if (_bonusUsado) return; // Usuário já usou o bônus de primeiro depósito
              if (modal.querySelector('._wm-oferta')) return;
              var submitWrap = modal.querySelector('._btn-submit-wrap_tlnrj_46');
              if (!submitWrap) return;
  
              var deadline = Date.now() + 12 * 3600 * 1000;
              function pad(n) { return String(n).padStart(2, '0'); }
              function timerText() {
                  var d  = Math.max(0, deadline - Date.now());
                  var h  = Math.floor(d / 3600000);
                  var m  = Math.floor((d % 3600000) / 60000);
                  var s  = Math.floor((d % 60000) / 1000);
                  var cs = Math.floor((d % 1000) / 10);
                  return h + ':' + pad(m) + ':' + pad(s) + '.' + pad(cs);
              }
  
              var card = document.createElement('div');
              card.className = '_wm-oferta';
              card.style.cssText =
                  'margin:.1rem .16rem;border-radius:.12rem;'
                  + 'background:rgba(255,170,9,0.08);'
                  + 'border:1px solid rgba(255,170,9,0.30);'
                  + 'padding:.14rem .16rem;';
              card.innerHTML =
                  /* header row */
                  '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.1rem;">'
                  + '<div style="display:flex;align-items:center;gap:.08rem;">'
                  + '<img src="' + GIFT_IMG_COLOR + '" onerror="this.onerror=null;this.src=\'' + GIFT_IMG_COLOR_FB + '\'" style="width:.32rem;height:.32rem;object-fit:contain;" alt="">'
                  + '<span style="font-size:.2rem;font-weight:700;color:#fff!important;">Oferta de Dep\u00f3sito</span>'
                  + '</div>'
                  /* W1-style _limited-time badge: [⚡ LT] [diagonal] [time] */
                  + '<div style="display:inline-flex;align-items:stretch;border-radius:.08rem;overflow:hidden;flex-shrink:0;height:.3rem;">'
                  /* left section: lightning + LT */
                  + '<div style="display:flex;align-items:center;gap:.03rem;'
                  + 'background:#e5463e;padding:0 .06rem 0 .06rem;">'
                  + '<img src="' + TIMER_IMG_LOCAL + '" onerror="this.onerror=null;this.src=\'' + TIMER_IMG_FB + '\'" style="width:.18rem;height:.18rem;object-fit:contain;" alt="">'
                  + '<span style="font-size:.15rem;font-weight:700;color:#fff;letter-spacing:.01rem;">LT</span>'
                  + '</div>'
                  /* diagonal divider */
                  + '<div style="width:.16rem;background:#e5463e;position:relative;flex-shrink:0;">'
                  + '<div style="position:absolute;inset:0;background:rgba(0,0,0,.25);'
                  + 'clip-path:polygon(40% 0,100% 0,60% 100%,0% 100%);"></div>'
                  + '</div>'
                  /* right section: countdown */
                  + '<div style="display:flex;align-items:center;'
                  + 'background:rgba(0,0,0,.22);padding:0 .08rem 0 .02rem;">'
                  + '<span class="_wm-oferta-tmr-count" style="font-size:.15rem;font-weight:600;color:#fff;">' + timerText() + '</span>'
                  + '</div>'
                  + '</div>'
                  + '</div>'
                  /* dashed separator */
                  + '<div style="text-align:center;font-size:.15rem;color:rgba(255,255,255,.45);margin-bottom:.1rem;">'
                  + '----- Participou automaticamente das seguintes atividades -----'
                  + '</div>'
                  /* bonus row — greyed when no amount, lit when condition met */
                  + '<div class="_wm-oferta-rows">'
                  + '<div class="_wm-oferta-row" style="display:flex;align-items:center;justify-content:space-between;'
                  + 'border-radius:.08rem;padding:.08rem .1rem;'
                  + 'background:rgba(255,255,255,.04);'
                  + 'opacity:.45;filter:grayscale(1);'
                  + 'transition:opacity .2s,filter .2s,background .2s;">'
                  + '<div style="display:flex;align-items:center;gap:.08rem;">'
                  + '<img class="_wm-gift-img" src="' + GIFT_IMG_GREY_FB + '" onerror="this.onerror=null;this.src=\'' + GIFT_IMG_GREY_FB + '\'" style="width:.36rem;height:.36rem;object-fit:contain;" alt="">'
                  + '<span class="_wm-oferta-title" style="font-size:.18rem;font-weight:600;color:rgba(255,255,255,.35);">B\u00f4nus extra de dep\u00f3sito inicial</span>'
                  + '</div>'
                  + '<div style="display:flex;align-items:center;gap:.06rem;flex-shrink:0;margin-left:.1rem;">'
                  + '<span class="_wm-oferta-cond" style="font-size:.15rem;color:rgba(255,255,255,.45);'
                  + 'text-align:right;line-height:1.3;">'
                  + 'Primeiro dep\u00f3sito \u2265 50</span>'
                  + '<span class="_wm-cond-check" style="display:none;width:.28rem;height:.28rem;color:#04BE02;flex-shrink:0;">' + CHECK_SVG + '</span>'
                  + '</div>'
                  + '</div>'
                  + '</div>';
  
              /* expand toggle sits OUTSIDE the card (sibling below it, like W1) */
              var expandBtn = document.createElement('div');
              expandBtn.className = '_wm-expand-btn';
              expandBtn.style.cssText =
                  'text-align:center;padding:.08rem 0 .04rem;cursor:pointer;'
                  + 'font-size:.18rem;color:var(--skin__primary,#1678ff);user-select:none;';
  
              submitWrap.parentNode.insertBefore(card, submitWrap);
              submitWrap.parentNode.insertBefore(expandBtn, submitWrap);
  
              /* Expandir / Passar toggle logic */
              var rowsEl  = card.querySelector('._wm-oferta-rows');
              var expanded = true;
              function setExpanded(v) {
                  expanded = v;
                  rowsEl.style.display = v ? '' : 'none';
                  expandBtn.textContent = v ? 'Passar \u2227' : 'Expandir \u2228';
              }
              setExpanded(true); /* start expanded */
              expandBtn.addEventListener('click', function() { setExpanded(!expanded); });
  
              var tmrEl = card.querySelector('._wm-oferta-tmr-count');
              var tmrInt = setInterval(function() {
                  if (!document.body.contains(card)) {
                      clearInterval(tmrInt);
                      return;
                  }
                  if (tmrEl) tmrEl.textContent = timerText();
              }, 1000);
          }
  
          /* ── 5. Sticky bottom bar (W1 _sticky-bottom_13mvs_45 pattern) ── */
          function injectStickyBottom(modal) {
              if (modal.querySelector('._wm-sticky-bottom')) return;
              var submitWrap = modal.querySelector('._btn-submit-wrap_tlnrj_46');
              if (!submitWrap) return;
  
              /* ── Capture theme colours from real elements before hiding anything ── */
  
              /* 1. Background: walk up from submit button until we find a real bg colour */
              var detectedBg = '';
              var bgWalk = submitWrap.parentElement;
              while (bgWalk && bgWalk !== document.documentElement) {
                  var bgVal = getComputedStyle(bgWalk).backgroundColor;
                  if (bgVal && bgVal !== 'rgba(0, 0, 0, 0)' && bgVal !== 'transparent') {
                      detectedBg = bgVal;
                      break;
                  }
                  bgWalk = bgWalk.parentElement;
              }
  
              /* 2. Button colour classes: copy from the real Vue submit button */
              var realBtn = submitWrap.querySelector('.ui-button');
              var btnVariantClasses = 'ui-button--default ui-button--normal';
              if (realBtn) {
                  var copied = Array.from(realBtn.classList)
                      .filter(function(c) { return c.startsWith('ui-button--'); })
                      .join(' ');
                  if (copied) btnVariantClasses = copied;
              }
  
              /* hide the original full-width button after reading its classes */
              submitWrap.style.setProperty('display', 'none', 'important');
  
              /* ── Inject full CSS into <head> once ── */
              /* W1 scoped CSS doesn't cover our injected element, so we own all styles */
              var css = document.getElementById('_wm-sticky-css');
              if (!css) {
                  css = document.createElement('style');
                  css.id = '_wm-sticky-css';
                  document.head.appendChild(css);
              }
              var bg = detectedBg || '#111';
              css.textContent = [
                  /* container */
                  '._wm-sticky-bottom{',
                  '  position:sticky;bottom:0;left:0;right:0;',
                  '  background:' + bg + ';',
                  '  padding:.18rem .24rem .22rem;',
                  '  border-top:1px solid rgba(255,255,255,.10);',
                  '  border-radius:.24rem .24rem 0 0;',
                  '  box-shadow:0 -3px 16px rgba(0,0,0,.30);',
                  '  z-index:2;',
                  '}',
                  /* inner flex column */
                  '._wm-sticky-bottom ._money-box_13mvs_77{',
                  '  display:flex;flex-direction:column;gap:.10rem;',
                  '}',
                  /* top row: "Depósito [amount]" ←→ button */
                  '._wm-sticky-bottom ._money_13mvs_77{',
                  '  display:flex;align-items:center;gap:.12rem;',
                  '}',
                  '._wm-sticky-bottom ._money_13mvs_77>span:first-child{',
                  '  font-size:.26rem;font-weight:700;color:rgba(255,255,255,.95);white-space:nowrap;flex-shrink:0;',
                  '}',
                  '._wm-sticky-bottom ._count_13mvs_91{',
                  '  font-size:.36rem;font-weight:700;color:#fff;flex:1;min-width:0;',
                  '}',
                  '._wm-sticky-bottom .ui-badge__wrapper{flex-shrink:0;}',
                  /* the deposit button (base sizing only — colour from ui-button-- classes) */
                  '._wm-sticky-bottom ._btn_13mvs_126{',
                  '  min-width:1.5rem!important;',
                  '  padding:.08rem .18rem!important;',
                  '  height:auto!important;',
                  '  min-height:.64rem!important;',
                  '  border-radius:.12rem!important;',
                  '  font-size:.24rem!important;',
                  '  font-weight:600!important;',
                  '  white-space:normal!important;',
                  '  line-height:1.15!important;',
                  '  text-align:center!important;',
                  '}',
                  /* ── disabled state (no amount selected) ── */
                  '._wm-sticky-bottom._amount-not-entered_13mvs_134 ._money_13mvs_77>span:first-child,',
                  '._wm-sticky-bottom._amount-not-entered_13mvs_134 ._count_13mvs_91{display:none!important;}',
                  '._wm-sticky-bottom._amount-not-entered_13mvs_134 .ui-badge__wrapper{width:100%;}',
                  '._wm-sticky-bottom._amount-not-entered_13mvs_134 ._btn_13mvs_126{',
                  '  width:100%!important;',
                  '  background:rgba(255,255,255,.12)!important;',
                  '  color:rgba(255,255,255,.35)!important;',
                  '  box-shadow:none!important;border:none!important;',
                  '  cursor:not-allowed!important;',
                  '}',
                  /* ── gift / bonus row ── */
                  '._wm-sticky-bottom ._gift_13mvs_67{',
                  '  display:flex;flex-direction:column;',
                  '  font-size:.22rem;color:rgba(255,255,255,.65);',
                  '  line-height:1.35;gap:.02rem;',
                  '  transition:opacity .2s;',
                  '}',
                  '._wm-sticky-bottom._amount-not-entered_13mvs_134 ._gift_13mvs_67{',
                  '  display:none!important;',
                  '}',
                  '._wm-sticky-bottom ._text_13mvs_108{color:rgba(255,255,255,.45);}',
                  '._wm-sticky-bottom ._wm-gift-values{display:flex;align-items:center;flex-wrap:wrap;gap:.03rem;}',
                  '._wm-sticky-bottom ._reward_13mvs_80{color:#FFAA09;font-weight:600;}',
                  '._wm-sticky-bottom ._wm-sticky-from{font-weight:500;color:rgba(255,255,255,.65);}',
                  '._wm-sticky-bottom ._wm-sticky-total{font-weight:500;color:rgba(255,255,255,.65);}',
                  '._wm-sticky-bottom ._wm-sticky-simple-total{font-weight:500!important;color:rgba(255,255,255,.65)!important;}',
                  '._wm-sticky-bottom ._icon_13mvs_118{',
                  '  width:.32rem!important;height:.32rem!important;',
                  '  object-fit:contain;vertical-align:middle;',
                  '}',
                  /* ── Full-screen deposit modal ── */
                  /* Expand the panel to fill viewport height — leave .ui-popup untouched
                     so W1's native close/back mechanism keeps working on first click */
                  '._main-recharge_1m3jl_30{',
                  '  min-height:calc(var(--lobby__vh,1vh)*100)!important;',
                  '  display:flex!important;flex-direction:column!important;',
                  '  border-radius:0!important;',
                  '}',
                  /* Inner scroll container stretches to fill remaining space */
                  '._main-recharge_1m3jl_30 ._scroll-y_1m3jl_70,',
                  '._main-recharge_1m3jl_30 [class*="_scroll"]{',
                  '  flex:1 1 auto!important;',
                  '  min-height:0!important;',
                  '  overflow-y:auto!important;',
                  '}',
              ].join('');
  
              var sticky = document.createElement('div');
              sticky.className = '_wm-sticky-bottom _amount-not-entered_13mvs_134';
              sticky.innerHTML =
                  '<div class="_money-box_13mvs_77">'
                  /* top row: "Depósito [amount]" + button */
                  + '<div class="_money_13mvs_77">'
                  + '<span>Dep\u00f3sito</span>'
                  + '<span class="_count_13mvs_91 _wm-sticky-amount"></span>'
                  + '<div class="ui-badge__wrapper" style="--badge-gift-space:0;">'
                  + '<button type="button" class="ui-button ' + btnVariantClasses + ' _btn_13mvs_126 _wm-submit-btn">'
                  + '<div class="ui-button__content"><span class="ui-button__text">Deposite agora</span></div>'
                  + '</button>'
                  + '</div>'
                  + '</div>'
                  /* bonus row: "Receba até" label then values on second line */
                  + '<div class="_gift_13mvs_67">'
                  + '<span class="_text_13mvs_108">Receba at\u00e9</span>'
                  + '<div class="_wm-gift-values">'
                  + '<span class="_wm-sticky-from">--</span>&nbsp;+&nbsp;'
                  + '<img class="_icon_13mvs_118 _wm-sticky-gift-img" src="' + GIFT_IMG_GREY_FB + '" onerror="this.onerror=null;this.src=\'' + GIFT_IMG_GREY_FB + '\'" alt=".">'
                  + '&nbsp;<span class="_reward_13mvs_80 _wm-sticky-bonus">--</span>&nbsp;=&nbsp;'
                  + '<span class="_wm-sticky-total">--</span>&nbsp;BRL'
                  + '</div>'
                  + '</div>'
                  + '</div>';
  
              /* append to modal (sticky position works within modal scroll container) */
              modal.appendChild(sticky);
  
  
              /* delegate click to the real Vue button */
              var wmBtn = sticky.querySelector('._wm-submit-btn');
              if (wmBtn) {
                  wmBtn.addEventListener('click', function() {
                      var real = submitWrap.querySelector('.ui-button');
                      if (real) real.click();
                  });
              }
          }
  
          /* ── Reactive update (fires on click) ── */
          function updateReactive(modal) {
              var amount = getActiveAmount(modal);
              var bonus  = getActiveBonus(modal);
              var tierAmt = getActiveBonusTierAmount(modal);
              var met    = (amount >= tierAmt && amount > 0);
  
              var fmt2   = function(n) { return n.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2}); };
              var fmtAmt = function(n) { return (n===Math.floor(n)) ? n.toLocaleString('pt-BR') : fmt2(n); };
  
              /* Keep recommend buttons consistent after Vue toggles _active_ */
              normalizeRecommendAmountStyles(modal);
  
              /* ── Amount input: red border when empty, green when selected ── */
              var amtInput = modal.querySelector('input[placeholder]');
              if (amtInput) {
                  /* style the closest wrapper div that carries the visible border */
                  var inputWrap = amtInput.parentElement;
                  while (inputWrap && inputWrap !== modal) {
                      var cs = getComputedStyle(inputWrap);
                      if (cs.borderWidth !== '0px' || cs.borderStyle !== 'none') break;
                      inputWrap = inputWrap.parentElement;
                  }
                  if (inputWrap && inputWrap !== modal) {
                      inputWrap.style.setProperty('border-color',
                          amount > 0 ? '#04BE02' : '#ff3b30', 'important');
                  }
              }
  
              /* ── Oferta card gift image: grey until condition met ── */
              var ofertaGiftImg = modal.querySelector('._wm-gift-img');
              if (ofertaGiftImg) {
                  ofertaGiftImg.src = met ? GIFT_IMG_COLOR_FB : GIFT_IMG_GREY_FB;
                  ofertaGiftImg.onerror = function() {
                      this.onerror = null;
                      this.src = met ? GIFT_IMG_COLOR_FB : GIFT_IMG_GREY_FB;
                  };
                  ofertaGiftImg.style.filter     = met ? '' : 'grayscale(1)';
                  ofertaGiftImg.style.transition = 'filter .2s';
              }
  
              /* ── Oferta card: grey until condition met; then white text + check ── */
              var ofertaRow = modal.querySelector('._wm-oferta-row');
              if (ofertaRow) {
                  if (!met) {
                      /* value < 50 → whole row greyed (W1 behavior) */
                      ofertaRow.style.background  = 'rgba(255,255,255,.04)';
                      ofertaRow.style.opacity      = '0.45';
                      ofertaRow.style.filter       = 'grayscale(1)';
                      ofertaRow.style.transition   = 'opacity .2s, filter .2s, background .2s';
                  } else {
                      /* value ≥ 50 → gold highlight, full color */
                      ofertaRow.style.background  = 'rgba(255,170,9,0.10)';
                      ofertaRow.style.opacity      = '1';
                      ofertaRow.style.filter       = '';
                  }
              }
              var check = modal.querySelector('._wm-cond-check');
              if (check) check.style.display = met ? 'inline-flex' : 'none';
  
              var ofertaTitle = modal.querySelector('._wm-oferta-title');
              if (ofertaTitle) {
                  ofertaTitle.style.setProperty('color', met ? '#fff' : 'rgba(255,255,255,.35)', 'important');
              }
  
              /* update condition label with selected amount */
              var condSpan = modal.querySelector('._wm-oferta-cond');
              if (condSpan) {
                  /* W1: show the tier threshold (e.g. selected 100 => ≥ 100, typed 51 => ≥ 50) */
                  condSpan.textContent = 'Primeiro dep\u00f3sito \u2265 ' + (tierAmt ? fmtAmt(tierAmt) : '50');
                  condSpan.style.setProperty('color', met ? '#fff' : 'rgba(255,255,255,.35)', 'important');
              }
  
              /* ── Sticky bottom ── */
              var sticky = modal.querySelector('._wm-sticky-bottom');
              if (!sticky) return;
  
              var amtSpan  = sticky.querySelector('._wm-sticky-amount');
              var fromEl   = sticky.querySelector('._wm-sticky-from');
              var bonusEl  = sticky.querySelector('._wm-sticky-bonus');
              var totalEl  = sticky.querySelector('._wm-sticky-total');
  
              /* Sticky gift image: swap between grey (je2) and colorful (mccz) */
              var stickyGiftImg = sticky.querySelector('._wm-sticky-gift-img');
              if (stickyGiftImg) {
                  if (amount > 0) {
                      stickyGiftImg.src = GIFT_IMG_COLOR_FB;
                      stickyGiftImg.onerror = function() { this.onerror = null; this.src = GIFT_IMG_COLOR_FB; };
                  } else {
                      stickyGiftImg.src = GIFT_IMG_GREY_FB;
                      stickyGiftImg.onerror = function() { this.onerror = null; this.src = GIFT_IMG_GREY_FB; };
                  }
                  stickyGiftImg.style.filter = '';
              }
  
              var wmBtn = sticky.querySelector('._wm-submit-btn');
              var btnTxt = wmBtn ? wmBtn.querySelector('.ui-button__text') : null;
              var giftRow = sticky.querySelector('._gift_13mvs_67');
  
              if (amount > 0) {
                  /* any amount selected → activate button */
                  sticky.classList.remove('_amount-not-entered_13mvs_134');
                  if (wmBtn) wmBtn.disabled = false;
                  if (btnTxt) btnTxt.innerHTML = 'Deposite<br>agora';
                  if (amtSpan) amtSpan.textContent = fmtAmt(amount);
  
                  /* always show gift row when amount > 0 */
                  if (giftRow) {
                      giftRow.style.removeProperty('display');
                      var giftValues = giftRow.querySelector('._wm-gift-values');
                      var simpleSpan = giftRow.querySelector('._wm-sticky-simple-total');
                      if (bonus > 0) {
                          /* full breakdown: from + icon + bonus = total */
                          if (fromEl)  fromEl.textContent  = fmt2(amount);
                          if (bonusEl) bonusEl.textContent = fmt2(bonus);
                          if (totalEl) totalEl.textContent = fmt2(amount + bonus);
                          if (giftValues) giftValues.style.removeProperty('display');
                          if (simpleSpan) simpleSpan.style.setProperty('display', 'none', 'important');
                      } else {
                          /* no bonus → "Receba até X,XX BRL" only */
                          if (giftValues) giftValues.style.setProperty('display', 'none', 'important');
                          if (!simpleSpan) {
                              simpleSpan = document.createElement('span');
                              simpleSpan.className = '_wm-sticky-simple-total';
                              simpleSpan.style.cssText = 'font-size:.24rem;font-weight:500;color:rgba(255,255,255,.9);';
                              giftRow.appendChild(simpleSpan);
                          }
                          simpleSpan.textContent = fmt2(amount) + ' BRL';
                          simpleSpan.style.removeProperty('display');
                      }
                  }
              } else {
                  /* no amount → disabled state */
                  sticky.classList.add('_amount-not-entered_13mvs_134');
                  if (wmBtn) wmBtn.disabled = true;
                  if (btnTxt) btnTxt.innerHTML = 'Deposite agora';
                  if (amtSpan) amtSpan.textContent = '';
                  if (giftRow) giftRow.style.setProperty('display', 'none', 'important');
              }
          }
  
          /* ── Bootstrap ── */
          function enhanceModal(modal) {
              if (modal._wmDepDone) return;
              modal._wmDepDone = true;
              modal._wmOpenedFromHeader = (getRecentDepositOpenSource() === 'header');
  
              setTimeout(function() {
                  injectMethodHeader(modal);
                  hideWarnTips(modal);
                  hideAllCorners(modal);
                  hideProviderGrid(modal);
                  ensureGrupoW1PixCard(modal);
                  installProviderEnforcer(modal);
                  transformAmountBtns(modal);
                  installRecommendAmountEnforcer(modal);
                  injectOfertaSection(modal);
                  injectStickyBottom(modal);
                  installHeaderCloseBridge(modal);
                  updateReactive(modal);
  
                  /* Provider is now forced by CSS; no retry timer needed. */
  
                  /* Watch only for structural changes (new nodes) — NOT attribute changes.
                     Watching attributes caused an infinite loop:
                     updateReactive writes textContent → triggers childList → loops forever. */
                  new MutationObserver(function(muts) {
                      var hasNew = false;
                      for (var i = 0; i < muts.length; i++) {
                          if (muts[i].addedNodes.length > 0) { hasNew = true; break; }
                      }
                      if (!hasNew) return;
                      if (modal._wmObsRaf) return;
                      modal._wmObsRaf = requestAnimationFrame(function() {
                          modal._wmObsRaf = 0;
                          hideWarnTips(modal);
                          hideAllCorners(modal);
                          hideProviderGrid(modal);
                          ensureGrupoW1PixCard(modal);
                          installProviderEnforcer(modal);
                          transformAmountBtns(modal);
                          installRecommendAmountEnforcer(modal);
                          injectOfertaSection(modal);
                          injectStickyBottom(modal);
                      });
                  }).observe(modal, {childList:true, subtree:true});
  
                  modal.addEventListener('pointerdown', function(e) {
                      if (isHeaderActionTarget(modal, e.target)) {
                          modal._wmHeaderActionTs = Date.now();
                      }
                  }, true);
  
                  /* Reactive update on click — let Vue process the _active_ class first */
                  modal.addEventListener('click', function(e) {
                      if (isHeaderActionTarget(modal, e.target)) return;
                      if (modal._wmHeaderActionTs && Date.now() - modal._wmHeaderActionTs < 400) return;
                      setTimeout(function() { updateReactive(modal); }, 60);
                  }, true);
  
                  /* Reactive update on input — user typing a custom amount */
                  modal.addEventListener('input', function() {
                      setTimeout(function() { updateReactive(modal); }, 60);
                  }, true);
              }, 80);
          }
  
          new MutationObserver(function(mutations) {
              mutations.forEach(function(m) {
                  m.addedNodes.forEach(function(node) {
                      if (node.nodeType !== 1) return;
                      var target = node.classList && node.classList.contains('_main-recharge_1m3jl_30')
                          ? node
                          : node.querySelector && node.querySelector('._main-recharge_1m3jl_30');
                      if (target) enhanceModal(target);
                  });
              });
          }).observe(document.documentElement, {childList:true, subtree:true});
  
           document.addEventListener('click', function(e) {
               if (rerouteHeaderDepositToBottomNav(e)) {
                   return;
               }
               if (isTopHeaderDepositTrigger(e.target)) {
                   markDepositOpenSource('header');
                   return;
               }
               if (isBottomNavDepositTrigger(e.target)) {
                   markDepositOpenSource('bottomnav');
               }
           }, true);
       })();

  /* ========================================================== */
  /* FIX lobby-image #undefined */
  /* ========================================================== */
      /* ── Fix broken lobby-image icons rendered with <use xlink:href="#undefined"> ── */
      (function(){
          var PAY_ICON = '/siteadmin/skin/lobby_asset/common/web/common/comm_icon_pay_3.avif';
          var PAY_ICON_FB = '/assets/images/comm_icon_pay_3.avif';
          var GANT_ICON = '/siteadmin/skin/lobby_asset/common/web/common/comm_icon_tc_gant.svg';
  
          function replaceWithImage(el, src, fallback) {
              el.innerHTML = '';
              var img = document.createElement('img');
              img.src = src;
              if (fallback) {
                  img.onerror = function() { this.onerror = null; this.src = fallback; };
              }
              img.alt = '.';
              img.style.cssText = 'width:1em;height:1em;object-fit:contain;display:inline-block;vertical-align:middle;';
              el.appendChild(img);
              el.setAttribute('data-status', 'success');
          }
  
          function fixIcon(el) {
              if (el._wmPayFixed) return;
              el._wmPayFixed = true;
              replaceWithImage(el, PAY_ICON, PAY_ICON_FB);
          }
  
          function fixGantIcon(el) {
              if (el._wmGantFixed) return;
              el._wmGantFixed = true;
              replaceWithImage(el, GANT_ICON);
          }
  
          function isBrokenUseIcon(el) {
              if (!el || !el.querySelector) return false;
              var use = el.querySelector('use');
              if (!use) return false;
              var href = use.getAttribute('xlink:href') || use.getAttribute('href') || '';
              return href === '#undefined' || href.indexOf('undefined') !== -1;
          }
  
          function scanAndFix(root) {
              if (!(root || document).querySelectorAll) return;
  
              var waitEls = (root || document).querySelectorAll('.lobby-image[data-src*="comm_icon_tc_dengdai"]');
              for (var i = 0; i < waitEls.length; i++) {
                  if (isBrokenUseIcon(waitEls[i]) || !waitEls[i].querySelector('img')) fixIcon(waitEls[i]);
              }
  
              var gantEls = (root || document).querySelectorAll('.lobby-image[data-src*="comm_icon_tc_gant"]');
              for (var j = 0; j < gantEls.length; j++) {
                  if (isBrokenUseIcon(gantEls[j]) || !gantEls[j].querySelector('img')) fixGantIcon(gantEls[j]);
              }
          }
  
          /* Initial scan */
          if (document.readyState === 'loading') {
              document.addEventListener('DOMContentLoaded', function() { scanAndFix(); });
          } else {
              scanAndFix();
          }
  
          /* Watch for dynamically added elements */
          new MutationObserver(function(muts) {
              muts.forEach(function(m) {
                  m.addedNodes.forEach(function(node) {
                      if (node.nodeType !== 1) return;
                      if (node.matches && node.matches('.lobby-image[data-src*="comm_icon_tc_dengdai"]')) {
                          fixIcon(node);
                      } else if (node.matches && node.matches('.lobby-image[data-src*="comm_icon_tc_gant"]')) {
                          fixGantIcon(node);
                      } else if (node.querySelectorAll) {
                          scanAndFix(node);
                      }
                  });
              });
          }).observe(document.documentElement, {childList:true, subtree:true});
       })();

  /* ========================================================== */
  /* FIX lobby-image--use-bg (retry background images) */
  /* ========================================================== */
      (function(){
          var WM_BG_SELECTOR = '.lobby-image--use-bg';
          var WM_BG_RETRY_CLASS = 'wm-game-bg-retry';

          // Inject loading placeholder CSS. Keep the spinner scoped to elements
          // explicitly accepted by this fixer so header/buttons/banners are not affected.
          (function(){
              var s = document.createElement('style');
              s.textContent = '@keyframes wm-spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}.lobby-image--use-bg.wm-game-bg-retry[data-status="loading"]{background-color:#1a1a2e !important;background-image:none !important;position:relative !important;}.lobby-image--use-bg.wm-game-bg-retry[data-status="loading"]::after{content:"" !important;position:absolute !important;top:50% !important;left:50% !important;width:32px !important;height:32px !important;margin:-16px 0 0 -16px !important;border:3px solid rgba(255,255,255,0.2) !important;border-top-color:#fff !important;border-radius:50% !important;animation:wm-spin .7s linear infinite !important;pointer-events:none !important;z-index:10 !important;}.lobby-image--use-bg.wm-game-bg-retry[data-status="error"]{background-color:#1a1a2e !important;background-image:none !important;}';
              (document.head || document.documentElement).appendChild(s);
          })();

          // Some theme bundles normalize external image URLs to same-origin paths (e.g. https://localhost/zg5zlyoyg/...),
          // which breaks on local HTTPS (invalid cert) and also 404s because that path doesn't exist locally.
          // This patch rewrites those URLs back to their real hosts in a best-effort way.
          (function(){
              function rewriteBadUrl(u) {
                  try {
                      if (!u) return u;
                      // absolute path (no scheme) -> keep for later
                      // Handle same-origin "proxy-like" paths created by the bundle:
                      // 1) /zg5zlyoyg/... -> ImageKit
                      // 2) /images?q=tbn:... -> encrypted-tbn0.gstatic.com/images?...
                      var urlObj = null;
                      try { urlObj = new URL(u, String(location.href || '')); } catch (_e) { urlObj = null; }
                      var href = urlObj ? urlObj.toString() : String(u);
                      var host = urlObj ? String(urlObj.hostname || '').toLowerCase() : '';
                      var path = urlObj ? String(urlObj.pathname || '') : '';
                      var search = urlObj ? String(urlObj.search || '') : '';
                      // Only rewrite if it is pointing to localhost/current host, otherwise keep as-is.
                      // ImageKit path on ANY host that isn't ImageKit itself -> redirect
                      if (host !== 'ik.imagekit.io' && /^\/?zg5zlyoyg\//i.test(path)) {
                          var ikPath = (path.charAt(0) === '/' ? '' : '/') + path;
                          ikPath = ikPath.replace(/\/Provedores\/(WG_banner|PP_banner|JDB_banner|TADA_banner|PG_hot_banner)\.png$/i, '/Provedores/$1.avif');
                          return 'https://ik.imagekit.io' + ikPath + search;
                      }
                      // iGameWin path on any non-igamewin host
                      if (host !== 'igamewin.com' && /^\/storage\/igamewin\//i.test(path)) {
                          return 'https://igamewin.com' + (path.charAt(0) === '/' ? '' : '/') + path + search;
                      }
                      // Google image thumbnails proxied through current host
                      if (/^\/images$/i.test(path) && /[?&]q=tbn:/i.test(search)) {
                          return 'https://encrypted-tbn0.gstatic.com' + path + search;
                      }
                      // Also handle raw relative "/images?q=tbn:..." (no hostname)
                      if (/^\/images\\?q=tbn:/i.test(String(u))) {
                          return 'https://encrypted-tbn0.gstatic.com' + String(u);
                      }
                      // Also handle raw relative "/storage/igamewin/..."
                      if (/^\/storage\/igamewin\//i.test(String(u))) {
                          return 'https://igamewin.com' + String(u);
                      }
                      return href;
                  } catch (_e2) {
                      return u;
                  }
              }

              // Patch Image.src assignment (covers bundles that use new Image()).
              try {
                  var imgProto = (window.Image && window.Image.prototype) ? window.Image.prototype : null;
                  if (imgProto) {
                      var desc = Object.getOwnPropertyDescriptor(imgProto, 'src');
                      if (desc && desc.set && !imgProto.__wmSrcPatched) {
                          Object.defineProperty(imgProto, 'src', {
                              configurable: true,
                              enumerable: desc.enumerable,
                              get: desc.get,
                              set: function(v) {
                                  try { return desc.set.call(this, rewriteBadUrl(v)); } catch (_e3) { return desc.set.call(this, v); }
                              }
                          });
                          imgProto.__wmSrcPatched = true;
                      }
                  }
              } catch (_e4) {}

              // Patch fetch (some loaders download images as blobs via fetch/XHR).
              try {
                  if (typeof window.fetch === 'function' && !window.__wmFetchPatched) {
                      var _wmOrigFetch = window.fetch;
                      window.fetch = function(input, init) {
                          try {
                              if (typeof input === 'string') {
                                  input = rewriteBadUrl(input);
                              } else if (input && typeof input.url === 'string') {
                                  // Request object: rebuild if possible
                                  var newUrl = rewriteBadUrl(input.url);
                                  if (newUrl !== input.url && typeof Request === 'function') {
                                      input = new Request(newUrl, input);
                                  }
                              }
                          } catch (_e5) {}
                          return _wmOrigFetch.call(this, input, init);
                      };
                      window.__wmFetchPatched = true;
                  }
              } catch (_e6) {}

              // Patch XMLHttpRequest.open (bundle uses XHR for blob downloads).
              try {
                  var xhrProto = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
                  if (xhrProto && !xhrProto.__wmOpenPatched) {
                      var _wmOrigOpen = xhrProto.open;
                      xhrProto.open = function(method, url, async, user, password) {
                          try { url = rewriteBadUrl(url); } catch (_e7) {}
                          return _wmOrigOpen.call(this, method, url, async, user, password);
                      };
                      xhrProto.__wmOpenPatched = true;
                  }
              } catch (_e8) {}

              // Patch CSSStyleDeclaration.setProperty to remember last non-placeholder background-image per element.
              // Helps recover when the framework swaps back to the transparent placeholder after a failed render.
              try {
                  var styleProto = window.CSSStyleDeclaration && window.CSSStyleDeclaration.prototype;
                  if (styleProto && !styleProto.__wmSetPropPatched && typeof styleProto.setProperty === 'function') {
                      var _wmOrigSetProperty = styleProto.setProperty;
                      styleProto.setProperty = function(prop, value, priority) {
                          try {
                              if (prop === 'background-image' || prop === 'backgroundImage') {
                                  var v = String(value || '');
                                  if (v && v.indexOf('url(') !== -1) {
                                      var m = v.match(/url\\((['\"]?)(.*?)\\1\\)/i);
                                      var u = m && m[2] ? m[2] : '';
                                      if (u) {
                                          // store only real urls, not transparent placeholder
                                          if (!(typeof u === 'string' && u.indexOf('data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAY') === 0)) {
                                              u = rewriteBadUrl(u);
                                              var owner = this.ownerElement || this._element || null;
                                              if (owner && owner.setAttribute) owner.setAttribute('data-wm-bg-src', u);
                                          }
                                      }
                                  }
                              }
                          } catch (_e9) {}
                          return _wmOrigSetProperty.call(this, prop, value, priority);
                      };
                      styleProto.__wmSetPropPatched = true;
                  }
              } catch (_e10) {}

              // Patch direct el.style.backgroundImage = "..." assignment.
              // The framework uses this instead of setProperty, so the above patch never fires.
              try {
                  var csProto = window.CSSStyleDeclaration && window.CSSStyleDeclaration.prototype;
                  if (csProto && !csProto.__wmBgImgDescPatched) {
                      var origDesc = Object.getOwnPropertyDescriptor(csProto, 'backgroundImage');
                      if (origDesc && origDesc.set) {
                          var _wmOrigBgSet = origDesc.set;
                          var _wmBgPatchQueue = [];
                          var _wmBgPatchTimer = 0;
                          Object.defineProperty(csProto, 'backgroundImage', {
                              configurable: true,
                              enumerable: origDesc.enumerable !== false,
                              get: origDesc.get,
                              set: function(val) {
                                  var didRewrite = false;
                                  try {
                                      var v = String(val || '');
                                      if (v && v.indexOf('url(') !== -1) {
                                          var m = v.match(/url\((['"]?)(.*?)\1\)/i);
                                          var u = m && m[2] ? m[2] : '';
                                          if (u && u.indexOf('data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAY') !== 0) {
                                              var rewritten = rewriteBadUrl(u);
                                              if (rewritten !== u) {
                                                  val = 'url("' + rewritten.replace(/"/g, '%22') + '")';
                                                  didRewrite = true;
                                              }
                                          }
                                      }
                                  } catch (_eBgPatch) {}
                                  var ret = _wmOrigBgSet.call(this, val);
                                  // Schedule ensureBgLoaded for the owning element after rewrite
                                  if (didRewrite) {
                                      try {
                                          var self = this;
                                          _wmBgPatchQueue.push(self);
                                          if (!_wmBgPatchTimer) {
                                              _wmBgPatchTimer = setTimeout(function() {
                                                  _wmBgPatchTimer = 0;
                                                  var q = _wmBgPatchQueue.splice(0);
                                                  for (var qi = 0; qi < q.length; qi++) {
                                                      try {
                                                          var els = document.querySelectorAll(WM_BG_SELECTOR);
                                                          for (var ei = 0; ei < els.length; ei++) {
                                                              if (els[ei].style === q[qi]) {
                                                                  ensureBgLoaded(els[ei]);
                                                                  break;
                                                              }
                                                          }
                                                      } catch (_eQ) {}
                                                  }
                                              }, 50);
                                          }
                                      } catch (_eSchedule) {}
                                  }
                                  return ret;
                              }
                          });
                          csProto.__wmBgImgDescPatched = true;
                      }
                  }
              } catch (_e11) {}
          })();

          var MAX_RETRIES = 2;
          var LOAD_TIMEOUT_MS = 8000;
          var RETRY_BACKOFF_BASE_MS = 800;

          // --- WM Debug Logger ---
          var _wmLog = [];
          var _wmLogTimer = 0;
          var _wmLogStartTs = Date.now ? Date.now() : +new Date();
          function wmLog(type, url, status, detail, attempt) {
              try {
                  _wmLog.push({
                      type: type || 'info',
                      url: (url || '').substring(0, 300),
                      status: status || '',
                      detail: (detail || '').substring(0, 200),
                      attempt: attempt || 0,
                      elapsed: (Date.now ? Date.now() : +new Date()) - _wmLogStartTs
                  });
                  if (!_wmLogTimer) {
                      _wmLogTimer = setTimeout(wmLogFlush, 3000);
                  }
              } catch (_eLog) {}
          }
          function wmLogFlush() {
              _wmLogTimer = 0;
              if (!_wmLog.length) return;
              var batch = _wmLog.splice(0, 50);
              try {
                  fetch('/hall/api/wm/log', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ entries: batch })
                  }).catch(function(){});
              } catch (_eFlush) {}
          }
          // --- End WM Debug Logger ---

          function nowTs() { return Date.now ? Date.now() : +new Date(); }

          function extractUrlFromBg(bg) {
              try {
                  if (!bg || bg === 'none') return '';
                  // bg example: url("https://...") or url(https://...)
                  var m = String(bg).match(/url\((['"]?)(.*?)\1\)/i);
                  return m && m[2] ? m[2] : '';
              } catch (_e) { return ''; }
          }

          function isTransparent1pxPlaceholder(u) {
              try {
                  if (!u) return false;
                  // Theme uses a 1x1 transparent gif placeholder (see commonChunk: const El = data:image/gif;base64,...)
                  return typeof u === 'string'
                      && u.indexOf('data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAY') === 0;
              } catch (_e) { return false; }
          }

          function getDataSrc(el) {
              try {
                  if (!el || !el.getAttribute) return '';
                  return String(el.getAttribute('data-src') || '');
              } catch (_e) { return ''; }
          }

          function getRememberedSrc(el) {
              try {
                  if (!el || !el.getAttribute) return '';
                  return String(el.getAttribute('data-wm-bg-src') || '');
              } catch (_e) { return ''; }
          }

          function hasBadLocalhostUrl(u) {
              try {
                  return !!(u && /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])/i.test(String(u)));
              } catch (_e) { return false; }
          }

          function isBadProxyBgUrl(rawUrl) {
              try {
                  if (!rawUrl) return false;
                  var u = new URL(String(rawUrl), String(location.href || ''));
                  var host = String(u.hostname || '').toLowerCase();
                  var path = String(u.pathname || '');
                  var search = String(u.search || '');
                  if (hasBadLocalhostUrl(u.toString())) return true;
                  if (host !== 'ik.imagekit.io' && /^\/?zg5zlyoyg\//i.test(path)) return true;
                  if (host !== 'igamewin.com' && /^\/storage\/igamewin\//i.test(path)) return true;
                  if (host !== 'encrypted-tbn0.gstatic.com' && /^\/images$/i.test(path) && /[?&]q=tbn:/i.test(search)) return true;
                  return false;
              } catch (_e) {
                  return /^\/images\?q=tbn:|^\/storage\/igamewin\/|^\/?zg5zlyoyg\//i.test(String(rawUrl || ''));
              }
          }

          function getCurrentGameCategoryId() {
              try {
                  var url = new URL(window.location.href);
                  return String(url.searchParams.get('gameCategoryId') || '');
              } catch (_e) { return ''; }
          }

          function getElementGameCategoryId(el) {
              try {
                  var p = el;
                  var depth = 0;
                  while (p && p.nodeType === 1 && depth < 8) {
                      var v = '';
                      if (p.getAttribute) {
                           v = p.getAttribute('data-game-category-id')
                               || p.getAttribute('data-category-id')
                               || p.getAttribute('gameCategoryId')
                               || p.getAttribute('gamecategoryid')
                               || '';
                          if (!v && p.getAttribute('href')) {
                              try {
                                  var hrefUrl = new URL(p.getAttribute('href'), String(location.href || ''));
                                  v = hrefUrl.searchParams.get('gameCategoryId') || '';
                              } catch (_eHref) {}
                          }
                      }
                      if (v !== '') return String(v);
                      p = p.parentElement;
                      depth++;
                  }
              } catch (_e) {}
              return getCurrentGameCategoryId();
          }

          function isAllowedGameCategory(cat) {
              cat = String(cat || '');
              return cat === '0' || cat === '3';
          }

          function isExcludedBgArea(el) {
              try {
                  if (!el || !el.closest) return false;
                  return !!el.closest(
                      'header,footer,nav,.lobby-base-header,.ui-button,button,' +
                      '._banner-container_1xtky_30,[class*="_banner-container_"],[class*="_banner-box-"],[class*="_banner-item_"],' +
                      '._currency-box_1gbcf_70,[class*="_currency-box_"],[class*="_un-login-info_"],[class*="_login-btn_"],[class*="_register-btn_"]'
                  );
              } catch (_e) { return false; }
          }

          function hasGameCardHint(el) {
              try {
                  if (!el) return false;
                  if (el.closest && el.closest(
                      '.gn-game-card,.esp-card,[data-especial-id],[data-game-id],[data-gameid],[data-game-name],' +
                      '.landscape-left-right,.poster-box,.poster-image,.game-platform-name,' +
                      '[class*="_poster-box"],[class*="_poster-image"],[class*="_game-name"],[class*="_tab-game-list"],[class*="_pages-game-sub"]'
                  )) return true;
                  try {
                      var ds0 = getDataSrc(el);
                      var bg0 = '';
                      try { bg0 = (el.style && el.style.backgroundImage) ? el.style.backgroundImage : ''; } catch (_eBg0) {}
                      var u0 = extractUrlFromBg(bg0) || ds0 || getRememberedSrc(el);
                      if (/\/game_pictures\/|\/storage\/igamewin\/|\/zg5zlyoyg\//i.test(String(u0 || ''))) return true;
                  } catch (_eUrlHint) {}
                  var p = el;
                  var depth = 0;
                  while (p && p.nodeType === 1 && depth < 6) {
                      var cls = typeof p.className === 'string' ? p.className : '';
                      if (/(^|\s|_)(game|subgame|tab-game|game-list|game-card|gameContent|pages-game|poster-image|poster-box|landscape-left-right)(\s|_|-)/i.test(cls)) return true;
                      if (p.querySelector && p.querySelector('.name-inner,.esp-card-name')) return true;
                      p = p.parentElement;
                      depth++;
                  }
              } catch (_e) {}
              return false;
          }

          function isEligibleBgRetryTarget(el) {
              try {
                  if (!el || el.nodeType !== 1 || !el.matches || !el.matches(WM_BG_SELECTOR)) return false;
                  if (isExcludedBgArea(el)) return false;
                  if (String(location.pathname || '').indexOf('/home/subgame') === 0) return false;
                  var cat = getElementGameCategoryId(el);
                  return cat !== '' && isAllowedGameCategory(cat);
              } catch (_e) { return false; }
          }

          function enableBgRetryClass(el) {
              try {
                  if (el && el.classList && !el.classList.contains(WM_BG_RETRY_CLASS)) {
                      el.classList.add(WM_BG_RETRY_CLASS);
                  }
              } catch (_e) {}
          }

          function disableBgRetryClass(el) {
              try {
                  if (el && el.classList && el.classList.contains(WM_BG_RETRY_CLASS)) {
                      el.classList.remove(WM_BG_RETRY_CLASS);
                  }
              } catch (_e) {}
          }

          function normalizePossiblyBadUrl(rawUrl) {
              try {
                  if (!rawUrl) return rawUrl;
                  // keep data/blob as-is
                  if (rawUrl.indexOf('data:') === 0 || rawUrl.indexOf('blob:') === 0) return rawUrl;
                  var u = new URL(rawUrl, String(location.href || ''));
                  var host = (u.hostname || '').toLowerCase();
                  var pathname = String(u.pathname || '');
                  // Fix common provider banners that only exist as .avif on ImageKit
                  pathname = pathname.replace(/\/Provedores\/(WG_banner|PP_banner|JDB_banner|TADA_banner|PG_hot_banner)\.png$/i, '/Provedores/$1.avif');
                  u.pathname = pathname;
                  // If the path is an ImageKit path but the host is NOT imagekit, redirect to ImageKit.
                  // This catches cases where the framework generates URLs like https://1x-rb77.com/zg5zlyoyg/...
                  // ImageKit path on ANY host that isn't ImageKit -> redirect
                  if (host !== 'ik.imagekit.io' && /^\/?zg5zlyoyg\//i.test(u.pathname || '')) {
                      wmLog('rewrite', rawUrl, 'imagekit-path-wrong-host', 'host=' + host, 0);
                      return 'https://ik.imagekit.io' + (u.pathname.charAt(0) === '/' ? '' : '/') + u.pathname + (u.search || '');
                  }
                  // iGameWin path on any non-igamewin host
                  if (host !== 'igamewin.com' && /^\/storage\/igamewin\//i.test(u.pathname || '')) {
                      wmLog('rewrite', rawUrl, 'igamewin-path-wrong-host', 'host=' + host, 0);
                      return 'https://igamewin.com' + u.pathname + (u.search || '');
                  }
                  // Google thumbnails proxied through current host
                  if (/^\/images$/i.test(u.pathname || '') && /[?&]q=tbn:/i.test(u.search || '')) {
                      return 'https://encrypted-tbn0.gstatic.com' + u.pathname + (u.search || '');
                  }

                  if (host === 'localhost' || host === '127.0.0.1' || host === '::1') {
                      wmLog('rewrite', rawUrl, 'localhost-detected', 'host=' + host, 0);
                      var curHost = (location && location.host) ? String(location.host) : '';
                      var curIsLocal = /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(curHost);
                      if (curHost) {
                          return (curIsLocal ? 'http://' : (location.protocol || 'https:') + '//') + curHost + (u.pathname || '') + (u.search || '');
                      }
                      return (curIsLocal ? 'http://' : 'http://') + host + (u.pathname || '') + (u.search || '');
                  }
                  return u.toString();
              } catch (_e) {
                  return rawUrl;
              }
          }

          function withCacheBust(url, attempt) {
              try {
                  if (!url) return url;
                  // Avoid breaking data/blob
                  if (url.indexOf('data:') === 0 || url.indexOf('blob:') === 0) return url;
                  var sep = url.indexOf('?') === -1 ? '?' : '&';
                  return url + sep + 'wm_img_retry=' + encodeURIComponent(String(attempt)) + '&wm_ts=' + String(nowTs());
              } catch (_e) { return url; }
          }

          function buildUrlCandidates(url) {
              try {
                  if (!url) return [url];
                  if (url.indexOf('data:') === 0 || url.indexOf('blob:') === 0) return [url];
                  var u = new URL(url, String(location.href || ''));
                  var host = String(u.hostname || '').toLowerCase();
                  var path = String(u.pathname || '');
                  var m = path.match(/\.([a-z0-9]+)$/i);
                  if (!m) return [u.toString()];
                  var ext = m[1].toLowerCase();
                  var exts = ['avif', 'webp', 'png', 'jpg', 'jpeg'];
                  if (exts.indexOf(ext) === -1) return [u.toString()];

                  // ImageKit: CDN may return 404 on first request while doing origin-pull.
                  // Don't cycle formats — just retry the same URL (retries handle the propagation delay).
                  if (host === 'ik.imagekit.io') {
                      return [u.toString()];
                  }

                  // Prefer modern formats first, but keep original as first candidate.
                  var preferred = exts.slice();
                  // Move original ext to front
                  preferred = [ext].concat(preferred.filter(function(e){ return e !== ext; }));

                  var out = [];
                  preferred.forEach(function(e){
                      var nu = new URL(u.toString());
                      nu.pathname = path.replace(/\.[a-z0-9]+$/i, '.' + e);
                      out.push(nu.toString());
                  });
                  // Dedup
                  var seen = {};
                  return out.filter(function(x){ if (seen[x]) return false; seen[x]=1; return true; });
              } catch (_e) {
                  return [url];
              }
          }

          function markLoaded(el) {
              try { el.setAttribute('data-status', 'success'); } catch (_e) {}
          }

          function markLoading(el) {
              try {
                  el.setAttribute('data-status', 'loading');
                  // Remove inline background-image so the CSS loading spinner can show
                  if (el.style) {
                      if (!el._wmBgSavedInline && el.style.backgroundImage) {
                          el._wmBgSavedInline = el.style.backgroundImage;
                      }
                      el.style.removeProperty('background-image');
                  }
              } catch (_e) {}
          }

          function markError(el) {
              try {
                  el.setAttribute('data-status', 'error');
                  if (el.style) el.style.removeProperty('background-image');
              } catch (_e) {}
          }

          function ensureBgLoaded(el) {
              if (!el || el.nodeType !== 1) return;
              if (!isEligibleBgRetryTarget(el)) return;
              enableBgRetryClass(el);

              // If this element already loaded successfully, skip entirely to avoid spinner flash on scroll.
              if (el._wmBgLoadedUrl && el.getAttribute('data-status') === 'success') {
                  var curBg = '';
                  try { curBg = (el.style && el.style.backgroundImage) ? el.style.backgroundImage : ''; } catch (_eCur) {}
                  var curUrl = extractUrlFromBg(curBg);
                  if (curUrl && !isTransparent1pxPlaceholder(curUrl) && !isBadProxyBgUrl(curUrl)) {
                      return;
                  }
                  // Background was cleared by framework but we have the loaded URL — restore it.
                  if (!curUrl || isTransparent1pxPlaceholder(curUrl)) {
                      try {
                          el.style.backgroundImage = 'url("' + String(el._wmBgLoadedUrl).replace(/"/g, '%22') + '")';
                      } catch (_eRestore) {}
                      markLoaded(el);
                      return;
                  }
              }

              // App sometimes marks "success" before the network fetch finishes.
              // We'll still probe the URL, but only change status on real failures.
              var currentStatus = '';
              try { currentStatus = el.getAttribute ? (el.getAttribute('data-status') || '') : ''; } catch (_e0) {}

              var bg = '';
              try {
                  bg = (el.style && el.style.backgroundImage) ? el.style.backgroundImage : '';
                  if (!bg) bg = window.getComputedStyle ? getComputedStyle(el).backgroundImage : '';
              } catch (_e) {}

              var originalUrl = extractUrlFromBg(bg);
              var originalUrlFromBg = !!(originalUrl && !isTransparent1pxPlaceholder(originalUrl));
              // If background is missing or is the transparent placeholder, fall back to data-src (the bundle keeps full URL there).
                  if (!originalUrl || isTransparent1pxPlaceholder(originalUrl)) {
                      var ds = getDataSrc(el);
                      if (ds) originalUrl = ds;
                      if (!originalUrl) {
                          var rs = getRememberedSrc(el);
                          if (rs) originalUrl = rs;
                      }
                      if (!originalUrl && el._wmBgSavedInline) {
                          originalUrl = extractUrlFromBg(String(el._wmBgSavedInline || ''));
                      }
                  }
              if (!originalUrl) return;
              // If still the placeholder, nothing we can do until the app provides the real URL.
              if (isTransparent1pxPlaceholder(originalUrl)) return;
              var originalRawUrl = originalUrl;
              var originalUrlWasBadProxy = isBadProxyBgUrl(originalRawUrl);
              originalUrl = normalizePossiblyBadUrl(originalUrl);
              var originalUrlWasRewritten = String(originalUrl || '') !== String(originalRawUrl || '');

              // If a real image is already visible, do not flip the card back to loading
              // on IntersectionObserver/scroll re-entry.
              if (!el._wmBgForcedUrl && originalUrl && !isTransparent1pxPlaceholder(originalUrl) && !originalUrlWasBadProxy && !originalUrlWasRewritten) {
                  if (originalUrlFromBg || el._wmBgLoadedUrl === originalUrl) {
                      try { el._wmBgLoadedUrl = originalUrl; } catch (_eLoadedMemo) {}
                      markLoaded(el);
                      return;
                  }
              }

              // Allow forcing alternative URLs after failures (format fallback).
              if (el._wmBgForcedUrl) {
                  originalUrl = String(el._wmBgForcedUrl);
              } else {
                  // First time on a URL: create candidates (avif/webp/png/jpg/jpeg)
                  if (!el._wmBgCandidates || el._wmBgCandidatesKey !== originalUrl) {
                      el._wmBgCandidates = buildUrlCandidates(originalUrl);
                      el._wmBgCandidatesKey = originalUrl;
                      el._wmBgCandidateIndex = 0;
                  }
                  if (el._wmBgCandidates && el._wmBgCandidates.length > 0) {
                      var idx = typeof el._wmBgCandidateIndex === 'number' ? el._wmBgCandidateIndex : 0;
                      if (idx >= 0 && idx < el._wmBgCandidates.length) {
                          originalUrl = el._wmBgCandidates[idx];
                      }
                  }
              }

              // Don't spam retries for the same element when user keeps scrolling.
              try {
                  var lastFailAt = typeof el._wmBgLastFailAt === 'number' ? el._wmBgLastFailAt : 0;
                  if (lastFailAt && (nowTs() - lastFailAt) < 250) return;
              } catch (_e0b) {}

              // Debounce per element+url
              var key = originalUrl;
              if (el._wmBgLastKey === key && el._wmBgInFlight) return;
              if (el._wmBgLastKey !== key) {
                  el._wmBgAttempts = 0;
              }
              el._wmBgLastKey = key;

              var attempt = (typeof el._wmBgAttempts === 'number' ? el._wmBgAttempts : 0);
              el._wmBgInFlight = true;
              // Always show loading state while probing (framework may lie about success)
              try {
                  markLoading(el);
              } catch (_e1) {}

              var img = new Image();
              var done = false;
              var timer = 0;
              var tryDecode = true;

              function cleanup() {
                  done = true;
                  el._wmBgInFlight = false;
                  try { if (timer) clearTimeout(timer); } catch (_e) {}
              }

              function succeed(src) {
                  cleanup();
                  if (isTransparent1pxPlaceholder(src)) return;
                  wmLog('success', src, 'loaded', 'attempt=' + attempt + ' candidates=' + (el._wmBgCandidates ? el._wmBgCandidates.length : 0), attempt);
                  try {
                      el.style.backgroundImage = 'url(\"' + String(src).replace(/\"/g, '%22') + '\")';
                      el._wmBgLoadedUrl = String(src);
                  } catch (_e) {}
                  markLoaded(el);
              }

              function fail() {
                  cleanup();
                  try { el._wmBgLastFailAt = nowTs(); } catch (_e0c) {}
                  wmLog('fail', originalUrl, 'error', 'attempt=' + attempt + '/' + MAX_RETRIES + ' candidateIdx=' + (el._wmBgCandidateIndex || 0), attempt);
                  // Try next candidate format before counting as a real failure.
                  try {
                      if (el._wmBgCandidates && el._wmBgCandidates.length > 1) {
                          var curIdx = typeof el._wmBgCandidateIndex === 'number' ? el._wmBgCandidateIndex : 0;
                          if (curIdx < el._wmBgCandidates.length - 1) {
                              el._wmBgCandidateIndex = curIdx + 1;
                              el._wmBgForcedUrl = null;
                              // Reset attempts for the new candidate
                              el._wmBgAttempts = 0;
                              setTimeout(function(){ ensureBgLoaded(el); }, 120);
                              return;
                          }
                      }
                  } catch (_e0d) {}
                  // Only flip to error if the app didn't already consider it success.
                  if (attempt < MAX_RETRIES) {
                      el._wmBgAttempts = attempt + 1;
                      // retry with cache-bust to avoid a cached failure/cancel
                      var wait = RETRY_BACKOFF_BASE_MS * Math.pow(1.6, attempt);
                      if (wait > 8000) wait = 8000;
                      setTimeout(function(){
                          ensureBgLoaded(el);
                      }, wait);
                      return;
                  }
                  if (currentStatus !== 'success') markError(el);
              }

              img.onload = function(){
                  if (done) return;
                  // Some browsers fire onload but decode fails later (corrupted/partial).
                  try {
                      if (tryDecode && img.decode) {
                          img.decode().then(function(){ if (!done) succeed(originalUrl); }).catch(function(){ if (!done) fail(); });
                          return;
                      }
                  } catch (_e3) {}
                  succeed(originalUrl);
              };
              img.onerror = function(){ if (!done) fail(); };
              timer = setTimeout(function(){ if (!done) fail(); }, LOAD_TIMEOUT_MS);

              // Always probe with cache-bust to avoid sticky cached failures (reduces need for Ctrl+F5).
              var probeUrl = withCacheBust(originalUrl, attempt);
              wmLog('probe', probeUrl, 'loading', 'original=' + originalUrl.substring(0, 150) + ' attempt=' + attempt, attempt);
              try { img.decoding = 'async'; } catch (_e) {}
              try { img.src = probeUrl; } catch (_e2) { fail(); }
          }

          function observeExisting(root) {
              if (!(root || document).querySelectorAll) return;
              var list = (root || document).querySelectorAll(WM_BG_SELECTOR);
              for (var i = 0; i < list.length; i++) {
                  tryObserve(list[i]);
              }
          }

          var io = null;
          function tryObserve(el) {
              if (!el) return;
              if (!isEligibleBgRetryTarget(el)) {
                  disableBgRetryClass(el);
                  return;
              }
              enableBgRetryClass(el);
              if (!el._wmBgObserved) {
                  el._wmBgObserved = true;
                  try {
                      var bg0 = (el.style && el.style.backgroundImage) ? el.style.backgroundImage : '';
                      var u0 = extractUrlFromBg(bg0);
                      if (u0 && !isTransparent1pxPlaceholder(u0) && !isBadProxyBgUrl(u0)) {
                          // Framework already loaded a valid image — mark it so watchdog won't overwrite
                          el._wmBgLoadedUrl = u0;
                          markLoaded(el);
                          if (io) io.observe(el);
                          return;
                      }
                      if (!u0 || isTransparent1pxPlaceholder(u0) || isBadProxyBgUrl(u0)) markLoading(el);
                  } catch (_eMarkEarly) {}
                  if (io) {
                      io.observe(el);
                  } else {
                      setTimeout(function(){ ensureBgLoaded(el); }, 0);
                  }
              }
              // Even if already observed, re-check if the current bg is a bad/proxied URL
              try {
                  var bg = (el.style && el.style.backgroundImage) ? el.style.backgroundImage : '';
                  var u = extractUrlFromBg(bg);
                  if (u && isBadProxyBgUrl(u)) {
                      ensureBgLoaded(el);
                  }
              } catch (_eTryObs) {}
          }

          function setupIO() {
              try {
                  if (!('IntersectionObserver' in window)) return null;
                  return new IntersectionObserver(function(entries){
                      entries.forEach(function(entry){
                          if (entry && entry.isIntersecting && entry.target) {
                              var t = entry.target;
                              if (t._wmBgLoadedUrl && t.getAttribute('data-status') === 'success') {
                                  // Verify background is still present; if cleared, let ensureBgLoaded restore it
                                  try {
                                      var cbg = (t.style && t.style.backgroundImage) ? t.style.backgroundImage : '';
                                      var cu = extractUrlFromBg(cbg);
                                      if (cu && !isTransparent1pxPlaceholder(cu) && !isBadProxyBgUrl(cu)) return;
                                  } catch (_eIoChk) { return; }
                              }
                              ensureBgLoaded(t);
                          }
                      });
                  }, { root: null, rootMargin: '200px 0px', threshold: 0.01 });
              } catch (_e) { return null; }
          }

          function boot() {
              io = setupIO();
              observeExisting();

              // Scan new nodes / style changes (many lists render asynchronously)
              new MutationObserver(function(mutations){
                  mutations.forEach(function(m){
                      if (m.type === 'childList') {
                          m.addedNodes && m.addedNodes.forEach(function(node){
                              if (!node || node.nodeType !== 1) return;
                              if (node.matches && node.matches(WM_BG_SELECTOR)) {
                                  tryObserve(node);
                              } else if (node.querySelectorAll) {
                                  observeExisting(node);
                              }
                          });
                      } else if (m.type === 'attributes') {
                          var t = m.target;
                          if (t && t.nodeType === 1 && t.matches && t.matches(WM_BG_SELECTOR)) {
                              tryObserve(t);
                              if (t._wmBgLoadedUrl && t.getAttribute('data-status') === 'success') {
                                  try {
                                      var bgChk = (t.style && t.style.backgroundImage) ? t.style.backgroundImage : '';
                                      var uChk = extractUrlFromBg(bgChk);
                                      if (uChk && !isTransparent1pxPlaceholder(uChk) && !isBadProxyBgUrl(uChk)) {
                                          return;
                                      }
                                  } catch (_eChk) { return; }
                              }
                              try {
                                  var st = t.getAttribute('data-status');
                                  if (st === 'error' || st === 'loading') {
                                      ensureBgLoaded(t);
                                  } else {
                                      var bg = '';
                                      try { bg = (t.style && t.style.backgroundImage) ? t.style.backgroundImage : ''; } catch (_e0) {}
                                      var u = extractUrlFromBg(bg);
                                      if (!u || isTransparent1pxPlaceholder(u) || isBadProxyBgUrl(u)) {
                                          ensureBgLoaded(t);
                                      }
                                  }
                              } catch (_e2) {}
                          }
                      }
                  });
              }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'data-status'] });

              // When the user returns to the tab, recheck visible elements.
              document.addEventListener('visibilitychange', function(){
                  if (document.visibilityState === 'visible') observeExisting();
              });

              // Network flaps: when connection comes back, retry errored cards.
              window.addEventListener('online', function(){
                  try { observeExisting(); } catch (_e) {}
              });

              // Watchdog: some flows set data-status="success" but keep the transparent placeholder (or no bg) until a hard refresh.
              // Periodically attempt to recover visible cards using their data-src.
              (function(){
                  var TIMER_MS = 1500;
                  var MAX_PER_TICK = 25;
                  var API_ENDPOINT = '/hall/api/wm/resolve-banners';

                  function getGameNameFromCard(el) {
                      try {
                          if (!el) return '';
                          var nameEl = el.querySelector && el.querySelector('.name-inner');
                          if (nameEl && nameEl.textContent) return String(nameEl.textContent || '').trim();
                          return '';
                      } catch (_e) { return ''; }
                  }

                  var _wmResolveInFlight = false;
                  function resolveViaApi(names, cb) {
                      if (!names || !names.length) return cb && cb(null);
                      if (_wmResolveInFlight) return cb && cb(null);
                      _wmResolveInFlight = true;
                      try {
                          fetch(API_ENDPOINT, {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ names: names })
                          }).then(function(r){ return r.json(); })
                            .then(function(j){
                                _wmResolveInFlight = false;
                                cb && cb(j && j.data ? j.data : null);
                            })
                            .catch(function(){
                                _wmResolveInFlight = false;
                                cb && cb(null);
                            });
                      } catch (_e2) {
                          _wmResolveInFlight = false;
                          cb && cb(null);
                      }
                  }

                  function inViewport(el) {
                      try {
                          if (!el || !el.getBoundingClientRect) return false;
                          var r = el.getBoundingClientRect();
                          if (!r || (r.width <= 2 && r.height <= 2)) return false;
                          var vh = window.innerHeight || document.documentElement.clientHeight || 0;
                          var vw = window.innerWidth || document.documentElement.clientWidth || 0;
                          return r.bottom >= -50 && r.right >= -50 && r.top <= (vh + 50) && r.left <= (vw + 50);
                      } catch (_e) { return false; }
                  }
                  function bgLooksEmpty(el) {
                      try {
                          var bg = '';
                          try { bg = (el.style && el.style.backgroundImage) ? el.style.backgroundImage : ''; } catch (_e0) {}
                          if (!bg) {
                              try { bg = window.getComputedStyle ? getComputedStyle(el).backgroundImage : ''; } catch (_e1) {}
                          }
                          var u = extractUrlFromBg(bg);
                          if (!u || isTransparent1pxPlaceholder(u)) return true;
                          // Treat localhost/127.0.0.1 URLs as "empty" — they need rewriting
                          if (isBadProxyBgUrl(u)) return true;
                          return false;
                      } catch (_e2) { return false; }
                  }
                  function tick(){
                      try {
                          if (document.visibilityState === 'hidden') return;
                          var els = document.querySelectorAll(WM_BG_SELECTOR);
                          var processed = 0;
                          var needResolve = [];
                          var resolveEls = [];
                          for (var i = 0; i < els.length; i++) {
                              if (processed >= MAX_PER_TICK) break;
                              var el = els[i];
                              if (!inViewport(el)) continue;
                              // Skip elements already successfully loaded (but only if bg is still present)
                              if (el._wmBgLoadedUrl && el.getAttribute('data-status') === 'success') {
                                  if (!bgLooksEmpty(el)) continue;
                              }
                              if (!bgLooksEmpty(el)) {
                                  // Element has a non-empty, non-localhost bg. Check if it's stuck
                                  // (all retries exhausted but image never rendered visibly).
                                  try {
                                      var att = typeof el._wmBgAttempts === 'number' ? el._wmBgAttempts : 0;
                                      var bgUrl = extractUrlFromBg((el.style && el.style.backgroundImage) || '');
                                      var isIk = bgUrl && bgUrl.indexOf('ik.imagekit.io') !== -1;
                                      // ImageKit URLs don't cycle formats, so resolve via API after just 1 failure
                                      var stuckThreshold = isIk ? 1 : MAX_RETRIES;
                                      if (att >= stuckThreshold && !el._wmBgResolved) {
                                          var nm0 = getGameNameFromCard(el);
                                          wmLog('watchdog-stuck', bgUrl, 'stuck', 'game=' + nm0 + ' attempts=' + att + ' ik=' + isIk, att);
                                          if (nm0) {
                                              needResolve.push(nm0);
                                              resolveEls.push(el);
                                              processed++;
                                          }
                                      }
                                  } catch (_eStuck) {}
                                  continue;
                              }
                              var ds = getDataSrc(el);
                              if (!ds) {
                                  // try remembered URL
                                  var rs = getRememberedSrc(el);
                                  if (rs) {
                                      processed++;
                                      ensureBgLoaded(el);
                                      continue;
                                  }
                                  // finally, resolve by game name via backend
                                  var nm = getGameNameFromCard(el);
                                  if (nm) {
                                      needResolve.push(nm);
                                      resolveEls.push(el);
                                      processed++;
                                  }
                                  continue;
                              }
                              processed++;
                              ensureBgLoaded(el);
                          }
                          if (needResolve.length) {
                              wmLog('watchdog-resolve', needResolve.join(','), 'resolving', 'count=' + needResolve.length, 0);
                              // dedup
                              var seen = {};
                              needResolve = needResolve.filter(function(nm){ if (seen[nm]) return false; seen[nm]=1; return true; });
                              resolveViaApi(needResolve, function(map){
                                  if (!map) return;
                                  try {
                                      for (var k = 0; k < resolveEls.length; k++) {
                                          var el2 = resolveEls[k];
                                          var nm2 = getGameNameFromCard(el2);
                                          if (!nm2) continue;
                                          var u = map[nm2];
                                          if (u) {
                                              wmLog('api-resolved', u, 'resolved', 'game=' + nm2, 0);
                                              el2._wmBgResolved = true;
                                              el2._wmBgAttempts = 0;
                                              el2._wmBgCandidates = null;
                                              el2._wmBgForcedUrl = String(u);
                                              try { el2.setAttribute('data-wm-bg-src', String(u)); } catch (_e3) {}
                                              ensureBgLoaded(el2);
                                          }
                                      }
                                  } catch (_e4) {}
                              });
                          }
                      } catch (_e3) {}
                  }
                  // Run early ticks to catch elements set before observer was active
                  setTimeout(tick, 300);
                  setTimeout(tick, 1000);
                  setTimeout(tick, 2000);
                  setTimeout(tick, 3500);
                  setInterval(function(){
                      if ('requestIdleCallback' in window) {
                          try { window.requestIdleCallback(tick, { timeout: 800 }); return; } catch (_e4) {}
                      }
                      tick();
                  }, TIMER_MS);
              })();
          }

          if (document.readyState === 'loading') {
              document.addEventListener('DOMContentLoaded', boot);
          } else {
              boot();
          }

          // Flush logs before page unload
          try {
              window.addEventListener('beforeunload', function() {
                  wmLog('page-unload', location.href, 'unloading', 'totalLogs=' + _wmLog.length, 0);
                  if (_wmLog.length) {
                      try {
                          navigator.sendBeacon('/hall/api/wm/log', JSON.stringify({ entries: _wmLog.splice(0, 50) }));
                      } catch (_eBeacon) { wmLogFlush(); }
                  }
              });
          } catch (_eUnload) {}
      })();

  /* ========================================================== */
  /* FIX <img> elements (retry broken img src with rewritten URL) */
  /* ========================================================== */
      (function(){
          var MAX_IMG_RETRIES = 2;
          var handled = new WeakSet();

          function rewriteImgUrl(u) {
              try {
                  if (!u) return '';
                  if (u.indexOf('data:') === 0 || u.indexOf('blob:') === 0) return '';
                  var urlObj = null;
                  try { urlObj = new URL(u, String(location.href || '')); } catch (_e) { return ''; }
                  var host = String(urlObj.hostname || '').toLowerCase();
                  var path = String(urlObj.pathname || '');
                  var search = String(urlObj.search || '');
                  var curHost = (location && location.hostname) ? String(location.hostname).toLowerCase() : '';
                  var needsRewrite = (host === 'localhost' || host === '127.0.0.1' || host === '::1' || (curHost && host === curHost));
                  if (!needsRewrite) return '';
                  if (/^\/?zg5zlyoyg\//i.test(path)) {
                      var ikPath = (path.charAt(0) === '/' ? '' : '/') + path;
                      return 'https://ik.imagekit.io' + ikPath + search;
                  }
                  if (/^\/storage\/igamewin\//i.test(path)) {
                      return 'https://igamewin.com' + path + search;
                  }
                  if (/^\/images$/i.test(path) && /[?&]q=tbn:/i.test(search)) {
                      return 'https://encrypted-tbn0.gstatic.com' + path + search;
                  }
                  // For other localhost URLs, switch to http to avoid cert errors
                  if (curHost && /^https:/i.test(u) && /^(localhost|127\.0\.0\.1|\[::1\])/i.test(curHost)) {
                      return u.replace(/^https:/i, 'http:');
                  }
                  return '';
              } catch (_e) { return ''; }
          }

          document.addEventListener('error', function(e) {
              try {
                  var el = e.target;
                  if (!el || el.tagName !== 'IMG') return;
                  if (handled.has(el)) return;
                  var src = el.getAttribute('src') || '';
                  if (!src || src.indexOf('data:') === 0 || src.indexOf('blob:') === 0) return;
                  var retries = parseInt(el.getAttribute('data-wm-img-retry') || '0', 10);
                  if (retries >= MAX_IMG_RETRIES) return;

                  var newSrc = rewriteImgUrl(src);
                  if (newSrc && newSrc !== src) {
                      el.setAttribute('data-wm-img-retry', String(retries + 1));
                      el.src = newSrc;
                      return;
                  }
                  handled.add(el);
              } catch (_e) {}
          }, true);
      })();

  /* ========================================================== */
  /* DEPOSIT pending badge */
  /* ========================================================== */
      (function(){
          var ENDPOINT = '/hall/api/finance/deposit/pendingCount';
          var BADGE_ID = '_wm-dep-badge';
  
          function findDepositTabItem() {
              // Find the <i> with the deposit icon SVG
              var icon = document.querySelector('i.lobby-image[data-src*="comm_icon_cz_jl"], .lobby-image[data-src*="comm_icon_cz_jl"]');
              if (!icon) return null;
              // Walk up to find the tab/nav item container (max 8 levels)
              var el = icon;
              for (var i = 0; i < 8; i++) {
                  if (!el.parentElement || el.parentElement === document.body) break;
                  el = el.parentElement;
                  var cls = typeof el.className === 'string' ? el.className : '';
                  // Stop at a tab item or nav item container
                  if (/ui-tab\b|_tab-item|_nav-item|_btm-nav-item|_tabbar-item/.test(cls)) return el;
              }
              // Fallback: return 3 levels up from the icon
              el = icon;
              for (var j = 0; j < 3; j++) {
                  if (!el.parentElement) break;
                  el = el.parentElement;
              }
              return el;
          }
  
          function getOrCreateCustomBadge() {
              var existing = document.getElementById(BADGE_ID);
              if (existing) return existing;
              var container = findDepositTabItem();
              if (!container) return null;
              if (window.getComputedStyle(container).position === 'static') {
                  container.style.position = 'relative';
              }
              // Outer wrapper mirrors W1's ui-badge structure
              var badge = document.createElement('div');
              badge.id = BADGE_ID;
              badge.className = 'ui-badge ui-badge--auto ui-badge--fixed ui-badge--rtl';
              badge.style.cssText =
                  'position:absolute;top:23px;right:16px;'
                  + 'z-index:1;display:none;'
                  + '--badge-bg-color:var(--skin__accent_2);';
              var inner = document.createElement('div');
              inner.className = 'ui-badge__content';
              badge.appendChild(inner);
              container.appendChild(badge);
              return badge;
          }
  
          function applyCount(count) {
              // 1) Try W1 native badge wrapper
              document.querySelectorAll('._unpaid-count_1arm9_64').forEach(function(wrap){
                  var badge = wrap.querySelector('.ui-badge');
                  var content = wrap.querySelector('.ui-badge__content');
                  if (!badge || !content) return;
                  if (count > 0) {
                      content.textContent = count > 99 ? '99+' : String(count);
                      badge.style.display = '';
                  } else {
                      badge.style.display = 'none';
                  }
              });
  
              // 2) Fallback: custom badge using ui-badge structure
              var custom = getOrCreateCustomBadge();
              if (custom) {
                  var content = custom.querySelector('.ui-badge__content');
                  if (count > 0) {
                      if (content) content.textContent = count > 99 ? '99+' : String(count);
                      custom.style.display = '';
                  } else {
                      custom.style.display = 'none';
                  }
              }
          }
  
          var _wmPendingInFlight = false;
          var _wmPendingTimer = 0;
          var _wmPendingLastTs = 0;
  
          function refresh(){
              if (document.visibilityState === 'hidden') return;
              if (_wmPendingInFlight) return;
              _wmPendingInFlight = true;
              _wmPendingLastTs = Date.now();
  
              fetch(ENDPOINT, {credentials:'same-origin', cache:'no-store'})
                  .then(function(r){ return r.json(); })
                  .then(function(d){
                      var count = parseInt(d && d.data ? d.data.pendingCount : 0, 10) || 0;
                      applyCount(count);
                  })
                  .catch(function(){})
                  .finally(function(){ _wmPendingInFlight = false; });
          }
  
          function schedule(ms){
              if (_wmPendingTimer) clearTimeout(_wmPendingTimer);
              _wmPendingTimer = setTimeout(function(){
                  _wmPendingTimer = 0;
                  refresh();
                  schedule(60000);
              }, ms);
          }
  
          /* Run at most once per minute, and pause when tab is hidden */
          schedule(1200);
          window.addEventListener('focus', function(){ refresh(); schedule(60000); });
          document.addEventListener('visibilitychange', function(){
              if (document.visibilityState === 'visible') { refresh(); schedule(60000); }
          });
          window.addEventListener('popstate', function(){ setTimeout(function(){ refresh(); }, 300); });
  
          new MutationObserver(function(muts){
              var found = false;
              muts.forEach(function(m){
                  m.addedNodes.forEach(function(n){
                      if (n.nodeType !== 1) return;
                      if ((n.classList && n.classList.contains('_unpaid-count_1arm9_64'))
                          || (n.querySelector && n.querySelector('._unpaid-count_1arm9_64'))
                          || (n.querySelector && n.querySelector('[data-src*="comm_icon_cz_jl"]'))) {
                          found = true;
                      }
                  });
              });
              if (found) setTimeout(function(){
                  /* avoid bursts */
                  if (Date.now() - _wmPendingLastTs > 1500) refresh();
              }, 400);
          }).observe(document.documentElement, {childList:true, subtree:true});
  
          setTimeout(refresh, 1500);
      })();

  /* ========================================================== */
  /* ACTIVE TAB bg fix */
  /* ========================================================== */
      /* ── Active-tab background fix — btn_zc avif substitui por var(--skin__primary) ── */
      (function(){
          if (document.getElementById('_wm-tab-bg-css')) return;
          var s = document.createElement('style');
          s.id = '_wm-tab-bg-css';
          s.textContent =
              /* ── Step 1: Strip the broken avif/png background-image from every btn_zc element ── */
              '[data-src*="btn_zc"],[style*="btn_zc"]{background-image:none!important;}'
  
              /* ── Step 2: Default ALL btn_zc elements to transparent (specificity 0,1,0) ──
                 Covers both inactive and the "outer" active wrapper tabs.                    */
              +'[data-src*="btn_zc"],[style*="btn_zc"]{background-color:transparent!important;}'
  
              /* ── Step 3: Active tabs → skin__primary (specificity 0,2,0 — overrides step 2) ──
                 Handles all active-detection patterns:
                   a) ui-tab--active parent  (task tab, generic line tab)
                   b) *active* in own class  (cashback, platform, label tabs)            */
              +'.ui-tab--active [data-src*="btn_zc"],'
              +'[data-src*="btn_zc"][class*="active"],'
              +'[style*="btn_zc"][class*="active"],'
              +'.ui-tab--active [style*="btn_zc"]'
              +'{background-color:var(--skin__primary)!important;}';
          document.head.appendChild(s);
  
          /* Fix _label_9a274_ active color: rgb(255,31,61)!important → var(--skin__primary)
             Inline !important cannot be overridden by CSS — requires JS setProperty. */
          function fixTabLabelColor(){
              document.querySelectorAll('[class*="_label_"]').forEach(function(el){
                  if (el.style.getPropertyPriority('color') !== 'important') return;
                  var isActive = !!el.closest(
                      '[class*="_is-active_"],[class*="-active_"],[class*="_active-"],'
                      +'[class*="_active_"],[class*="--active"],[class*="ui-tab--active"]'
                  );
                  el.style.setProperty('color', isActive ? 'var(--skin__primary)' : '#fff', 'important');
              });
          }
          new MutationObserver(fixTabLabelColor).observe(document.documentElement, {childList:true, subtree:true, attributeFilter:['style']});
          setTimeout(fixTabLabelColor, 300);
      })();

  /* ========================================================== */
  /* FLOATBOX scroll-hide */
  /* ========================================================== */
      /* ── FloatBox scroll-hide — visible by default, hides while scrolling, shows immediately on stop ── */
      (function(){
          var HIDE_CLASS = '_wm-fb-hidden';
          var _timer = null, _styleInjected = false, _listenersAdded = false;
  
          /* Broad selector — matches any W1 floatBox regardless of build hash */
          function getFloat(){
              return document.querySelector('[class*="_floatBox_"],[class*="floatBox"],[class*="_float-box_"],[class*="float-btn"],[class*="_suspend_"],[class*="_drag-float_"]');
          }
  
          function injectStyle(){
              if (_styleInjected) return;
              _styleInjected = true;
              var s = document.createElement('style');
              s.id = '_wm-fb-style';
              /* Show: instant (no transition). Hide: quick slide-out to the right. */
              s.textContent =
                  '[class*="_floatBox_"],[class*="floatBox"],[class*="_float-box_"],[class*="_suspend_"],[class*="_drag-float_"]{'
                  +'transition:none!important;}'
                  +'[class*="_floatBox_"].'+HIDE_CLASS+',[class*="floatBox"].'+HIDE_CLASS
                  +',[class*="_float-box_"].'+HIDE_CLASS+',[class*="_suspend_"].'+HIDE_CLASS+',[class*="_drag-float_"].'+HIDE_CLASS+'{'
                  +'transform:translateX(58%)!important;'
                  +'transition:transform .18s ease!important;}';
              document.head.appendChild(s);
          }
  
          function hide(){ var f=getFloat(); if(f) f.classList.add(HIDE_CLASS); }
          function show(){ var f=getFloat(); if(f) f.classList.remove(HIDE_CLASS); }
  
          function onScroll(){
              hide();
              clearTimeout(_timer);
              _timer = setTimeout(show, 150);
          }
  
          function addListeners(){
              if (_listenersAdded) return;
              _listenersAdded = true;
              /* capture:true intercepts scroll on ANY scrollable child element */
              document.addEventListener('scroll',    onScroll, {passive:true, capture:true});
              window.addEventListener('scroll',      onScroll, {passive:true});
          }
  
          function tryInit(){
              injectStyle();
              addListeners();
          }
  
          new MutationObserver(function(){ if(getFloat()) tryInit(); }).observe(document.documentElement,{childList:true,subtree:true});
          if(document.readyState!=='loading') tryInit(); else document.addEventListener('DOMContentLoaded', tryInit);
      })();

  /* ========================================================== */
  /* FLOATBOX close icon swap (W1) */
  /* ========================================================== */
      (function(){
          try { if (window.__wmFloatCloseIconSwapInstalled) return; } catch (_e0) {}
          try { window.__wmFloatCloseIconSwapInstalled = true; } catch (_e1) {}

          var TARGET_SRC = '/assets/images/kjrk_icon_guanbi.avif';
          var FROM_RE = /comm_icon_gb\.avif/i;
          var scheduled = false;
          var currentFloat = null;
          var mo = null;

          function findFloat(){
              return document.querySelector('[class*="_floatBox_"],[class*="floatBox"],[class*="_float-box_"],[class*="float-btn"],[class*="_suspend_"],[class*="_drag-float_"]');
          }

          function swap(){
              scheduled = false;
              var root = currentFloat || findFloat();
              if(!root) return;
              var icons = root.querySelectorAll('img[class*="_closeIcon_"],img[class*="closeIcon"]');
              for(var i=0;i<icons.length;i++){
                  var img = icons[i];
                  var src = (img.getAttribute('src') || '').trim();
                  if(src && FROM_RE.test(src) && src !== TARGET_SRC){
                      img.setAttribute('src', TARGET_SRC);
                  }
              }
          }

          function schedule(){
              if(scheduled) return;
              scheduled = true;
              try {
                  requestAnimationFrame(swap);
              } catch (_e2) {
                  setTimeout(swap, 16);
              }
          }

          function attach(){
              var f = findFloat();
              if(!f) return;
              if(f === currentFloat) { schedule(); return; }
              currentFloat = f;
              schedule();
              try { if(mo) mo.disconnect(); } catch (_e3) {}
              try {
                  mo = new MutationObserver(function(){ schedule(); });
                  mo.observe(currentFloat, {childList:true, subtree:true, attributes:true, attributeFilter:['src']});
              } catch (_e4) {}
          }

          try {
              // observa o DOM de forma leve só pra detectar o floatbox entrar/sair
              var rootObserver = new MutationObserver(function(){ attach(); });
              rootObserver.observe(document.documentElement, {childList:true, subtree:true});
          } catch (_e5) {}

          if(document.readyState!=='loading') attach(); else document.addEventListener('DOMContentLoaded', attach);
      })();

  /* ========================================================== */
  /* FLOATBOX close behavior (works logged or not) */
  /* ========================================================== */
      (function(){
          try { if (window.__wmFloatCloseBehaviorInstalled) return; } catch (_e0) {}
          try { window.__wmFloatCloseBehaviorInstalled = true; } catch (_e1) {}

          var LS_KEY = '__wmFloatClosedV1';
          var memClosed = null;

          function loadClosed(){
              if (memClosed) return memClosed;
              try {
                  var raw = localStorage.getItem(LS_KEY);
                  memClosed = raw ? JSON.parse(raw) : [];
                  if (!Array.isArray(memClosed)) memClosed = [];
              } catch (_e2) { memClosed = []; }
              return memClosed;
          }

          function saveClosed(list){
              try { localStorage.setItem(LS_KEY, JSON.stringify(list.slice(0, 60))); } catch (_e0) {}
          }

          function makeKey(btn){
              try {
                  var img = btn.querySelector('img[class*="_fastImg_"],img[class*="fastImg"]');
                  var txt = btn.querySelector('[class*="_fastText_"],[class*="fastText"]');
                  var src = img ? (img.getAttribute('src') || '') : '';
                  var label = '';
                  if (txt) label = (txt.getAttribute('data-text') || txt.textContent || '').trim();
                  return (src + '|' + label).trim();
              } catch (_e0) {
                  return '';
              }
          }

          function isCloseIcon(target){
              var el = target;
              for (var i=0;i<6 && el;i++){
                  if (el.tagName === 'IMG') {
                      var cls = (el.className && typeof el.className === 'string') ? el.className : '';
                      if (cls.indexOf('closeIcon') !== -1 || cls.indexOf('_closeIcon_') !== -1) return el;
                  }
                  el = el.parentElement;
              }
              return null;
          }

          function closestFastBtn(from){
              var el = from;
              for (var i=0;i<10 && el;i++){
                  var cls = (el.className && typeof el.className === 'string') ? el.className : '';
                  if (cls.indexOf('fastBtn') !== -1 || cls.indexOf('_fastBtn_') !== -1) return el;
                  el = el.parentElement;
              }
              return null;
          }

          function applyHidden(root){
              if (!root) return;
              var closed = loadClosed();
              if (!closed.length) return;
              var btns = root.querySelectorAll('div[class*="_fastBtn_"],div[class*="fastBtn"]');
              for (var i=0;i<btns.length;i++){
                  var key = makeKey(btns[i]);
                  if (key && closed.indexOf(key) !== -1) {
                      try { btns[i].remove(); } catch (_e0) {}
                  }
              }
          }

          function findFloat(){
              return document.querySelector('[class*="_floatBox_"],[class*="floatBox"],[class*="_float-box_"],[class*="float-btn"],[class*="_suspend_"],[class*="_drag-float_"]');
          }

          // Delegated click: close without requiring login
          document.addEventListener('click', function(e){
              var icon = isCloseIcon(e.target);
              if (!icon) return;
              var btn = closestFastBtn(icon);
              if (!btn) return;

              try {
                  e.preventDefault();
                  e.stopImmediatePropagation();
              } catch (_e0) {}

              var key = makeKey(btn);
              if (key) {
                  var closed = loadClosed();
                  if (closed.indexOf(key) === -1) {
                      closed.unshift(key);
                      saveClosed(closed);
                  }
              }

              try { btn.remove(); } catch (_e1) { btn.style.display = 'none'; }
          }, true);

          // Observe floatbox mount and apply hidden items
          (function(){
              var cur = null, mo = null;
              function attach(){
                  var f = findFloat();
                  if (!f) return;
                  if (f === cur) { applyHidden(cur); return; }
                  cur = f;
                  applyHidden(cur);
                  try { if (mo) mo.disconnect(); } catch (_e0) {}
                  try {
                      mo = new MutationObserver(function(){ applyHidden(cur); });
                      mo.observe(cur, {childList:true, subtree:true});
                  } catch (_e1) {}
              }
              try {
                  var rootObs = new MutationObserver(function(){ attach(); });
                  rootObs.observe(document.documentElement, {childList:true, subtree:true});
              } catch (_e2) {}
              if (document.readyState !== 'loading') attach();
              else document.addEventListener('DOMContentLoaded', attach, {once:true});
          })();
      })();

  /* ========================================================== */
  /* PERFIL /home/mine transform */
  /* ========================================================== */
      /* ── Profile page /home/mine → W1 style_7 transformation ── */
      (function(){
          'use strict';
          var CDN        = 'https://bukxb.w1-brocadepg.com/siteadmin/skin/lobby_asset/common/common/profile/';
          var CDN2       = '/siteadmin/skin/lobby_asset/common/web/common/';
          var CDN_EVENT  = 'https://bukxb.w1-brocadepg.com/siteadmin/skin/lobby_asset/common/common/event/';
          var CDN_ACTIVE = 'https://bukxb.w1-brocadepg.com/siteadmin/active/';
          var PFX = '_wm-w1p';
          var VER = '176';
          var lastMineNavAt = 0;
          var lastLoginModalAt = 0;
          var lastLogoutModalAt = 0;
          var _wmSvgCache = Object.create(null);
  
          function onMinePage(){ return /^\/home\/mine\/?$/.test(window.location.pathname); }
  
          function injectCSS(){
              var existing = document.getElementById(PFX+'-css');
              if (existing && existing.getAttribute('data-wm-ver') === VER) return;
              var cssText =
                  '[class*="_mine_"][class*="_container_"]{background-image:url("'+CDN+'style_7_topbg_yd.avif")!important;background-size:100% auto!important;background-position:top center!important;background-color:transparent!important;}'
                  +'.'+PFX+'-qf{background:var(--skin__bg_2,#1e2740);border-radius:.2rem;margin:.2rem .2rem .28rem;overflow:hidden;}'
                  +'.'+PFX+'-qf-title{font-size:.28rem;font-weight:700;color:var(--skin__text_1,#e4e9f4);padding:.24rem .24rem .1rem;}'
                  +'.'+PFX+'-qf-grid{display:grid;grid-template-columns:repeat(4,1fr);list-style:none;margin:0;padding:0 0 .2rem;}'
                  +'.'+PFX+'-qf-item{display:flex;flex-direction:column;align-items:center;padding:.18rem 0 .1rem;cursor:pointer;-webkit-tap-highlight-color:transparent;}'
                  +'.'+PFX+'-qf-item:active{opacity:.7;}'
                  +'.'+PFX+'-icon{position:relative;width:.68rem;height:.68rem;margin-bottom:.06rem;flex-shrink:0;}'
                  +'.'+PFX+'-icon i{display:flex!important;width:100%!important;height:100%!important;align-items:center;justify-content:center;}'
                  +'.'+PFX+'-icon i svg{width:100%!important;height:100%!important;}'
                  +'.'+PFX+'-icon i+i{position:absolute!important;top:0;left:0;width:100%!important;height:100%!important;}'
                  +'.'+PFX+'-garantia-check{width:.07rem!important;height:.07rem!important;}'
                  +'.'+PFX+'-garantia-check svg{width:.07rem!important;height:.07rem!important;}'
                  +'.'+PFX+'-lbl{font-size:.22rem;color:var(--skin__text_2,#7d8fb3);text-align:center;line-height:1.3;word-break:break-word;max-width:1.1rem;padding:0 .04rem;}'
                  +'[class*="_mine_"][class*="_container_"] [class*="_un-login-info_"]{overflow:visible!important;position:relative;}'
                  +'.'+PFX+'-ul-login,.'+PFX+'-ul-reg{height:.5rem;width:1.2rem;border-radius:.1rem;font-size:.22rem;cursor:pointer;display:flex;align-items:center;justify-content:center;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;}'
                  +'.'+PFX+'-ul-login{background:var(--skin__primary);border:.01rem solid var(--skin__primary);color:var(--skin__text_primary,#fff);}'
                  +'.'+PFX+'-ul-reg{border:.01rem solid var(--skin__primary)!important;color:var(--skin__primary);background:transparent;margin-left:.2rem;}'
                  +'.'+PFX+'-ul-lion{width:1.98rem;height:2rem;position:absolute;bottom:-.4rem;right:.25rem;z-index:-1;flex-shrink:0;pointer-events:none;}'
                  +'.'+PFX+'-toast{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%) scale(.96);display:flex;align-items:center;gap:.18rem;min-width:4.3rem;max-width:5.8rem;padding:.24rem .32rem;background:#fff;color:#222;border-radius:.18rem;box-shadow:0 .12rem .32rem rgba(0,0,0,.18);z-index:99999;font-size:.22rem;opacity:0;pointer-events:none;transition:opacity .18s ease,transform .18s ease;}'
                  +'.'+PFX+'-toast.show{opacity:1;transform:translate(-50%,-50%) scale(1);}'
                  +'.'+PFX+'-toast-ic{width:.42rem;height:.42rem;border-radius:50%;background:#19c611;color:#fff;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.26rem;}'
                  +'.'+PFX+'-mask{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.32);z-index:99999;padding:.3rem;box-sizing:border-box;}'
                  +'.'+PFX+'-mask.show{display:flex;}'
                  +'.'+PFX+'-modal{width:min(6.2rem,calc(100vw - .6rem));background:var(--skin__bg_2,#064a7a);background:color-mix(in srgb, var(--skin__bg_2,#064a7a) 86%, transparent);backdrop-filter:blur(.18rem);-webkit-backdrop-filter:blur(.18rem);border:1px solid var(--skin__border, rgba(255,255,255,.10));border-radius:.22rem;overflow:hidden;padding:.38rem .34rem .32rem;box-sizing:border-box;text-align:center;box-shadow:0 .18rem .5rem rgba(0,0,0,.28);}'
                  +'.'+PFX+'-modal-title{display:block!important;visibility:visible!important;color:var(--skin__text_primary,#fff);font-size:.36rem;font-weight:700;margin:0 0 .18rem;}'
                  +'.'+PFX+'-modal-msg{display:block!important;visibility:visible!important;color:var(--skin__text_primary,#fff);font-size:.26rem;line-height:1.35;margin:0 0 .34rem;opacity:.95;}'
                  +'.'+PFX+'-modal-actions{display:flex;gap:.24rem;justify-content:space-between;}'
                  +'.'+PFX+'-btn{flex:1;height:.74rem;border-radius:.16rem;font-size:.26rem;display:flex;align-items:center;justify-content:center;cursor:pointer;user-select:none;-webkit-tap-highlight-color:transparent;}'
                  +'.'+PFX+'-btn-confirm{border:1px solid var(--skin__primary,#42d7ff);color:var(--skin__primary,#42d7ff);background:transparent;}'
                  +'.'+PFX+'-btn-cancel{background:var(--skin__primary,#42d7ff);color:var(--skin__text_primary,#fff);border:1px solid var(--skin__primary,#42d7ff);}'
                  +'[class*="_navCardContainer_"]{display:none!important;}'
                  +'[class*="_mine_"][class*="_container_"] [class*="_header-info_"]{overflow:visible!important;}';

              if (existing) {
                  existing.textContent = cssText;
                  existing.setAttribute('data-wm-ver', VER);
                  return;
              }
              var s = document.createElement('style');
              s.id = PFX+'-css';
              s.setAttribute('data-wm-ver', VER);
              s.textContent = cssText;
              document.head.appendChild(s);
          }
  
          var QF = [
              {lbl:'Juros',            i:'style_7_icon_lxb.svg',       i2:'style_7_icon_lxb1.svg',      href:'/home/yuebao'},
              {lbl:'Meus Registros',   i:'style_7_icon_zdjl.svg',      i2:'style_7_icon_zdjl1.svg',     href:'/home/records'},
              {lbl:'Gestão de saques', i:'style_7_icon_txgl.svg',      i2:'style_7_icon_txgl1.svg',     href:'/home/withdraw?active=0'},
              {lbl:'VIP',              i:'style_7_icon_vip.svg',        i2:'style_7_icon_vip1.svg',      href:'/home/vip'},
               {lbl:'Ofertas',          i:'style_7_icon_fxzq.svg',       i2:'style_7_icon_fxzq1.svg',     href:'/home/event'},
              {lbl:'Garantia\u00a0de\nplatform...', i:'style_7_icon_dblbz.svg',     i2:'style_7_icon_dblbz1.svg',    href:null},
              {lbl:'Dados',            i:'style_7_icon_list_grzl.svg',  i2:'style_7_icon_list_grzl1.svg',href:'/home/setting'},
              {lbl:'Segurança',        i:'style_7_icon_aqzx.svg',       i2:'style_7_icon_aqzx1.svg',     href:'/home/security'},
              {lbl:'Idioma',           i:'style_7_icon_yyxz.svg',       i2:'style_7_icon_yyxz1.svg',     href:null},
              {lbl:'FAQ',              i:'style_7_icon_cjwt.svg',       i2:'style_7_icon_cjwt1.svg',     href:'/home/notice?noticeType=4'},
              {lbl:'Bônus de Sugestão',i:'style_7_icon_yjfk.svg',       i2:'style_7_icon_yjfk1.svg',     href:'/home/notice?noticeType=5'},
              {lbl:'Faça login no...', i:'style_7_icon_dlsb.svg', i2:'style_7_icon_dlsb1.svg', href:'/home/device-info'},
          ];
  
          function fetchLobbySvg(src){
              if(!_wmSvgCache[src]){
                  _wmSvgCache[src] = fetch(src,{mode:'cors'})
                      .then(function(r){ return r.ok?r.text():Promise.reject(r.status); });
              }
              return _wmSvgCache[src];
          }
  
          function buildLobbySvgNode(txt){
              var tmp=document.createElement('div');
              tmp.innerHTML=txt;
              var svg=tmp.querySelector('svg');
              if(!svg) return null;
              svg.setAttribute('width','1em');
              svg.setAttribute('height','1em');
              svg.style.cssText='width:1em;height:1em;display:block;overflow:visible;';
              svg.setAttribute('fill','currentColor');
              tmp.querySelectorAll('path,circle,rect,polygon,polyline,ellipse,g').forEach(function(node){
                  if (node.getAttribute('fill') !== 'none') {
                      node.setAttribute('fill','currentColor');
                      node.style.fill = 'currentColor';
                  }
                  if (node.getAttribute('stroke') && node.getAttribute('stroke') !== 'none') {
                      node.setAttribute('stroke','currentColor');
                      node.style.stroke = 'currentColor';
                  }
                  if (!node.getAttribute('fill') && !node.getAttribute('stroke') && /^(path|circle|rect|polygon|polyline|ellipse)$/i.test(node.tagName)) {
                      node.style.fill = 'currentColor';
                  }
              });
              return svg;
          }
  
          function preloadMineVisualAssets(){
              var assets = {};
              QF.forEach(function(it){
                  // Alguns SVGs nesse CDN retornam 403 (hotlink/arquivo bloqueado) e poluem o console.
                  // Como esses itens usam fallback/inline, não precisamos pré-carregar esses casos.
                  var blockPrimary = (it.i === 'style_7_icon_dblbz.svg');
                  var blockOverlay = (it.i2 === 'style_7_icon_aqzx1.svg' || it.i2 === 'style_7_icon_dblbz1.svg');

                  if(it.i && !blockPrimary) assets[CDN + it.i] = true;
                  if(it.i2 && !blockPrimary && !blockOverlay) assets[CDN + it.i2] = true;
              });
              assets[CDN + 'style_7_icon_tc.svg'] = true;
              assets[CDN + 'style_7_icon_tc1.svg'] = true;
              assets[CDN2 + 'comm_icon_fh.svg'] = true;
              Object.keys(assets).forEach(function(src){
                  fetchLobbySvg(src).catch(function(){});
              });
          }
  
  
          function mkLobbyIcon(src, color){
              var el = document.createElement('i');
              el.style.cssText = 'display:inline-flex;justify-content:center;align-items:center;color:'+color+';width:.36rem;height:.36rem;flex-shrink:0;';
              fetchLobbySvg(src)
                  .then(function(txt){
                      var svg=buildLobbySvgNode(txt); if(!svg) return;
                      el.appendChild(svg);
                  })
                  .catch(function(){
                      var img=new Image(); img.src=src;
                      img.style.cssText='width:1em;height:1em;display:block;filter:brightness(0) invert(1);';
                      el.appendChild(img);
                  });
              return el;
          }
  
          preloadMineVisualAssets();
  
          function mkGarantiaIcon(){
              var wrap = document.createElement('div');
              wrap.className = PFX+'-garantia';
              wrap.style.cssText = 'position:relative;width:.42rem;height:.42rem;display:flex;align-items:center;justify-content:center;overflow:visible;margin-top:.04rem;margin-bottom:-.1rem;transform:translateX(.04rem);';
  
              function mkInlineGarantia(svgText, color, extraStyle){
                  var el = document.createElement('i');
                  el.style.cssText = 'display:inline-flex;justify-content:center;align-items:center;color:'+color+';flex-shrink:0;'+(extraStyle||'');
                  el.innerHTML = svgText;
                  return el;
              }
  
              var check = mkInlineGarantia(
                  '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 28 28"><g transform="translate(6.8 7.1) scale(.68)"><path d="M1234.22-597.615l-6.584-5.628a1.524,1.524,0,0,1-.149-2.141,1.5,1.5,0,0,1,2.128-.15l5.438,4.648,9.417-10.834a1.5,1.5,0,0,1,2.128-.15,1.525,1.525,0,0,1,.149,2.141l-10.4,11.964a1.5,1.5,0,0,1-1.139.522A1.494,1.494,0,0,1,1234.22-597.615Z" transform="translate(-1227.117 612.242)"></path></g></svg>',
                  '#fff',
                  'position:absolute;left:68%;top:53%;transform:translate(-50%,-50%);transform-origin:center;width:.06rem;height:.06rem;font-size:.06rem;z-index:3;'
              );
              check.className = PFX+'-garantia-check';
              var shield = mkInlineGarantia(
                  '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 85 85"><path fill-rule="evenodd" clip-rule="evenodd" d="M41.2215 2.09408C42.2554 1.45301 43.5586 1.45302 44.5925 2.09408C51.7799 6.55081 61.1337 14.4166 74.4473 15.8438C75.9908 16.0092 77.2737 17.26 77.3609 18.8944L77.3623 18.9112L77.3651 19.0357L77.3665 19.0525L77.4308 31.3153L77.456 37.6572C76.5581 37.1116 75.4284 36.7598 74.1032 36.8921V36.8893C74.0499 36.8939 73.9966 36.9016 73.9438 36.9075C73.9276 36.9095 73.911 36.9095 73.8948 36.9117C72.4168 37.0895 71.1387 37.7733 70.1867 38.8014C69.2817 39.779 68.8213 40.8987 68.567 41.7667C68.0767 43.4408 68.0327 45.3411 68.0327 46.6987C68.0326 47.0641 68.012 47.6578 67.9515 48.4052C67.126 48.1801 66.3258 48.1386 65.7037 48.1898C63.9472 48.3345 62.1713 49.1815 60.8725 50.7537L60.6193 51.0782C58.5462 53.885 58.6524 55.5047 54.5893 57.29L54.5347 57.3152L54.4816 57.3404C50.8288 59.0672 45.8198 62 42.9042 67.6156C39.9885 62 34.9795 59.0672 31.3267 57.3404L31.2736 57.3152L31.219 57.29C27.156 55.5047 27.2618 53.8845 25.189 51.0782C23.8736 49.2978 21.9783 48.3442 20.1046 48.1898C19.4823 48.1385 18.6815 48.1798 17.8554 48.4052C17.7949 47.6579 17.7757 47.0641 17.7757 46.6987C17.7757 45.3409 17.7318 43.4409 17.2414 41.7667C16.9869 40.8986 16.5268 39.7775 15.6216 38.8C14.6695 37.772 13.3903 37.0907 11.9121 36.9131L11.9135 36.9117C11.8445 36.9034 11.775 36.8954 11.7051 36.8893L11.7037 36.8921C10.382 36.7604 9.2545 37.1097 8.35791 37.653C8.38644 29.9593 8.43399 21.8383 8.44883 19.0525V19.0385L8.45163 18.914L8.45302 18.8944C8.5401 17.2619 9.81997 16.0116 11.361 15.8438L11.9863 15.771L13.192 15.6046C25.545 13.6937 34.3666 6.34461 41.2215 2.09408Z"></path></svg>',
                  'var(--skin__accent_1,#24e000)',
                  'position:absolute;inset:0;width:100%;height:100%;font-size:.42rem;z-index:1;transform:translateX(.08rem) scale(1.2) translateY(.045rem);transform-origin:center;'
              );
              var detail = mkInlineGarantia(
                  '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 85 85"><path d="M47.6062 69.4243C48.8922 68.8555 50.3091 68.7062 51.6756 68.9966C53.0421 69.2871 54.2959 70.0039 55.2771 71.0522C56.258 72.1004 56.9244 73.4348 57.1941 74.8833C57.4636 76.3316 57.3248 77.8334 56.7957 79.1987C56.2662 80.5644 55.368 81.736 54.2127 82.561C53.0569 83.3861 51.6946 83.8285 50.3006 83.8286C48.4307 83.8285 46.6411 83.0335 45.325 81.6274C44.0098 80.2221 43.2734 78.32 43.2732 76.3403C43.2733 74.8637 43.6834 73.4176 44.4529 72.187L44.7566 71.7388C45.4998 70.7222 46.481 69.9223 47.6062 69.4243ZM39.8592 78.5552V69.1401H42.4451L42.45 83.4448H39.6277L33.6912 72.9341L33.6717 83.4448H31.1199L31.1521 69.1401H34.5066L39.8592 78.5552ZM50.3006 71.1997C49.0366 71.2013 47.8197 71.7393 46.9197 72.7007C46.0193 73.6629 45.5091 74.9721 45.5076 76.3403L45.5223 76.7212C45.5838 77.6068 45.8576 78.4627 46.3201 79.2026C46.849 80.0481 47.6001 80.7047 48.4734 81.0913C49.3465 81.4775 50.306 81.5779 51.2312 81.3813C52.1571 81.1845 53.0109 80.6983 53.6824 79.981C54.3538 79.2635 54.8134 78.3472 54.9998 77.3472C55.186 76.3467 55.0903 75.3081 54.7254 74.3667C54.3604 73.4256 53.7427 72.6235 52.9549 72.061C52.1675 71.4992 51.2436 71.1998 50.3006 71.1997ZM49.7352 73.5962H50.202V72.4673H50.8289V73.5903H51.0506C51.5033 73.5856 51.9426 73.7581 52.285 74.0747C52.4065 74.2136 52.5007 74.3783 52.5613 74.5571C52.6217 74.7358 52.6477 74.9261 52.6375 75.1157C52.649 75.379 52.5822 75.6403 52.4471 75.8608C52.3119 76.0811 52.1148 76.2503 51.8846 76.3442C52.1142 76.4388 52.3106 76.6085 52.4451 76.8286C52.5795 77.0488 52.6451 77.3092 52.6336 77.5718C52.6438 77.7616 52.6179 77.9525 52.5574 78.1313C52.4969 78.31 52.4024 78.4739 52.2811 78.6128C51.9278 78.9383 51.4728 79.1091 51.0066 79.0913H50.8357C50.8306 79.0913 50.8251 80.1913 50.825 80.2202L50.1971 80.2212V79.0913H49.7312V80.2202H49.1092V79.0913H47.9686V78.3452H48.5125C48.5391 78.3463 48.5669 78.3421 48.5916 78.3315C48.616 78.321 48.6377 78.3039 48.6561 78.2837C48.6876 78.2202 48.7035 78.1484 48.7 78.0767V74.6118C48.7038 74.5391 48.688 74.4662 48.6561 74.4019C48.6375 74.3817 48.6152 74.3654 48.5906 74.355C48.566 74.3446 48.539 74.3392 48.5125 74.3403H47.9686V73.5962H49.1131V72.4673H49.7352V73.5962ZM11.3299 41.1655C13.228 41.3307 13.4764 43.9724 13.4764 46.6958C13.4764 49.4166 14.1355 61.7641 23.5057 65.4966C22.8343 65.1016 15.7709 57.3925 18.2625 53.0503C18.7243 52.2461 20.6085 52.1102 21.7303 53.6284C23.1323 55.5268 24.0408 58.828 29.4871 61.2212C32.0977 62.4553 35.4614 64.1822 38.0535 66.98H31.1512C30.0347 66.9802 29.1153 67.8282 29.0027 68.9155L28.991 69.1362L28.9695 78.3804C22.951 74.6671 16.9324 70.1245 14.2195 65.5132C10.0959 58.5031 8.99162 53.6285 8.85332 48.0991C8.7708 44.7982 9.51458 40.9187 11.3299 41.1655ZM49.7156 78.2827H50.9549C50.9667 78.2827 51.5546 78.2846 51.5594 77.4829C51.5637 76.6812 50.9661 76.6788 50.9549 76.6782H49.7166L49.7156 78.2827ZM74.4725 41.1655C76.2879 40.9184 77.0315 44.7981 76.949 48.0991C76.8107 53.6285 75.7074 58.503 71.5838 65.5132C69.2319 69.5111 64.3738 73.4568 59.1844 76.856C59.2188 76.1966 59.1884 75.533 59.0896 74.8765L59.033 74.5405L58.9646 74.2065C58.5952 72.5456 57.7982 71.0079 56.6424 69.7729C55.408 68.4542 53.8168 67.5382 52.0633 67.1655C50.4179 66.816 48.7166 66.9633 47.1561 67.5825C49.8327 64.426 53.5222 62.5415 56.3152 61.2212C61.7617 58.828 62.67 55.5269 64.0721 53.6284C65.1936 52.1102 67.0766 52.2464 67.5389 53.0503C70.031 57.3929 62.967 65.1028 62.2967 65.4966C71.6671 61.7642 72.3259 49.4166 72.326 46.6958C72.326 43.9725 72.5747 41.331 74.4725 41.1655ZM49.7156 76.0122H50.9549C51.0442 76.0029 51.1317 75.9748 51.2107 75.9292C51.2897 75.8835 51.3596 75.8204 51.4158 75.7456C51.4719 75.6707 51.5134 75.5839 51.5379 75.4917C51.5623 75.3995 51.5703 75.3026 51.5594 75.2075C51.5724 75.1122 51.5665 75.0143 51.5428 74.9214C51.519 74.8285 51.4773 74.7415 51.4207 74.6665C51.3641 74.5916 51.2936 74.5293 51.2137 74.4849C51.1336 74.4404 51.045 74.4142 50.9549 74.4077H49.7166L49.7156 76.0122Z"></path></svg>',
                  '#fff',
                  'position:absolute;inset:0;width:100%;height:100%;font-size:.42rem;z-index:2;transform:translateX(.08rem) scale(1.18) translateY(.065rem);transform-origin:center;'
              );
  
              wrap.appendChild(shield);
              wrap.appendChild(detail);
              wrap.appendChild(check);
              return wrap;
          }
  
          var CI_DAYS = [
              {v:'1,00',today:true,l:'Dia 1'},{v:'3,00',l:'Dia 2'},{v:'9,00',l:'Dia 3'},{v:'15,00',l:'Dia 4'},
              {v:'17,00',l:'Dia 5'},{v:'27,00',l:'Dia 6'},{v:'47,00',l:'Dia 7'},
          ];
  
          function buildCI(){
              if (document.getElementById(PFX+'-ci')) return null;
              var wrap=document.createElement('div'); wrap.id=PFX+'-ci';
              wrap.style.cssText='position:relative;display:flex;flex-direction:column;margin:.3rem .25rem .2rem;border-radius:.2rem;padding:.1rem .2rem .2rem;background:var(--skin__bg_2,#1e2740);';
              var hdr=document.createElement('div'); hdr.style.cssText='display:flex;justify-content:space-between;align-items:center;';
              var left=document.createElement('div');
              var ttl=document.createElement('div'); ttl.style.cssText='font-size:.28rem;font-weight:700;color:var(--skin__lead,#e4e9f4);margin-bottom:.04rem;'; ttl.textContent='Check In Diário';
              var sub=document.createElement('div'); sub.style.cssText='font-size:.24rem;color:var(--skin__neutral_1,#7d8fb3);'; sub.textContent='Faça login todos os dias e aproveite inúmeros presentes!';
              left.appendChild(ttl); left.appendChild(sub);
              var moreBtn=document.createElement('div');
              moreBtn.style.cssText='position:relative;background:var(--skin__primary);color:var(--skin__text_primary,#fff);font-size:.22rem;line-height:.36rem;height:.36rem;padding:0 .06rem 0 .1rem;border-radius:0 1rem 1rem 0;cursor:pointer;width:1.23rem;margin-left:.45rem;display:flex;justify-content:space-between;align-items:center;flex-shrink:0;';
              var giftImg=document.createElement('img'); giftImg.src=CDN_EVENT+'qd_img_icon2.avif'; giftImg.style.cssText='position:absolute;left:-.43rem;top:-.1rem;width:.55rem;height:.56rem;pointer-events:none;'; giftImg.onerror=function(){this.style.display='none';};
              var moreTxt=document.createElement('div'); moreTxt.style.cssText='width:.89rem;text-align:center;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;color:#fff !important;'; moreTxt.textContent='Mais eventos';
              var arrI=mkLobbyIcon(CDN2+'comm_icon_fh.svg','#fff'); arrI.style.cssText='display:inline-flex;align-items:center;justify-content:center;font-size:.16rem;transform:scaleX(-1);margin-left:.02rem;flex-shrink:0;color:#fff;';
              moreBtn.appendChild(giftImg); moreBtn.appendChild(moreTxt); moreBtn.appendChild(arrI);
              moreBtn.onclick=function(){ window.history.pushState({},'','/home/event'); window.dispatchEvent(new PopStateEvent('popstate')); };
              hdr.appendChild(left); hdr.appendChild(moreBtn); wrap.appendChild(hdr);
              /* Scroll wrapper — arrows positioned relative to this */
              var scrollWrap=document.createElement('div'); scrollWrap.style.cssText='position:relative;margin-top:.2rem;';
              var content=document.createElement('div'); content.style.cssText='display:flex;gap:.105rem;overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none;padding-bottom:.05rem;';
              CI_DAYS.forEach(function(d){
                  var item=document.createElement('div');
                  item.style.cssText='width:1.01rem;height:1.32rem;background:var(--skin__bg_2,#1e2740);border-radius:.14rem;display:flex;flex-direction:column;align-items:center;justify-content:space-between;flex-shrink:0;box-sizing:border-box;padding:.06rem 0;border:.01rem solid '+(d.today?'var(--skin__accent_1,#e8b84c)':'var(--skin__border,#2a3555)')+';';
                  var amt=document.createElement('div'); amt.style.cssText='width:100%;font-size:.24rem;line-height:.33rem;text-align:center;color:var(--skin__accent_3,#e8b84c);overflow:hidden;white-space:nowrap;'; amt.textContent=d.v;
                  var box=document.createElement('div'); box.style.cssText='display:flex;align-items:center;justify-content:center;width:.48rem;height:.48rem;';
                  var pic=document.createElement('img'); pic.src=CDN_ACTIVE+'qd_style2_img_qdjb1.avif'; pic.style.cssText='display:block;width:100%;height:100%;'; pic.onerror=function(){this.style.display='none';}; box.appendChild(pic);
                  var cap=document.createElement('div'); cap.style.cssText='display:flex;align-items:center;justify-content:center;font-size:.2rem;color:var(--skin__lead,#e4e9f4);';
                  if(d.today) cap.setAttribute('data-ci-today','1');
                  if(d.today && isLoggedIn()){ var sb=document.createElement('button'); sb.style.cssText='width:.82rem;height:.28rem;border-radius:.5rem;font-size:.2rem;background:var(--skin__primary);border:none;color:var(--skin__text_primary,#fff);cursor:pointer;flex-shrink:0;'; sb.textContent='Entrar'; sb.onclick=function(){ window.history.pushState({},'','/home/task'); window.dispatchEvent(new PopStateEvent('popstate')); }; cap.appendChild(sb); }
                  else{ cap.textContent=d.l; }
                  item.appendChild(amt); item.appendChild(box); item.appendChild(cap); content.appendChild(item);
              });
              /* Left arrow */
              function mkArrowIcon(){ var ic=document.createElement('i'); ic.style.cssText='display:inline-flex;justify-content:center;align-items:center;color:#fff;width:.18rem;height:.18rem;flex-shrink:0;'; ic.innerHTML='<svg viewBox="0 0 21.999 35.998" width=".18rem" height=".18rem" fill="currentColor"><path d="M2209.279,137.564l-17.743-15.773a2.024,2.024,0,0,1-.271-.228,2.009,2.009,0,0,1,0-2.83,2.02,2.02,0,0,1,.274-.23l17.74-15.77a1.992,1.992,0,0,1,2.817,2.816l-16.422,14.6,16.422,14.6a1.992,1.992,0,0,1-2.817,2.817Z" transform="translate(-2190.681 -102.15)"/></svg>'; return ic; }
              /* Left arrow */
              var aL=document.createElement('div'); aL.style.cssText='display:none;position:absolute;width:.36rem;height:.36rem;border-radius:50%;align-items:center;justify-content:center;font-size:.36rem;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.2);z-index:2;left:0;cursor:pointer;';
              aL.appendChild(mkArrowIcon());
              aL.onclick=function(){ content.scrollBy({left:-220,behavior:'smooth'}); };
              /* Right arrow — scaleX(-1) flips the left-pointing icon to point right */
              var aR=document.createElement('div'); aR.style.cssText='display:flex;position:absolute;width:.36rem;height:.36rem;border-radius:50%;align-items:center;justify-content:center;font-size:.36rem;top:50%;transform:translateY(-50%) scaleX(-1);background:rgba(0,0,0,.2);z-index:2;right:0;cursor:pointer;';
              aR.appendChild(mkArrowIcon());
              aR.onclick=function(){ content.scrollBy({left:220,behavior:'smooth'}); };
              function syncArrows(){
                  var atStart=content.scrollLeft<=2;
                  var atEnd=content.scrollLeft>=content.scrollWidth-content.clientWidth-2;
                  aL.style.display=atStart?'none':'flex';
                  aR.style.display=atEnd?'none':'flex';
              }
              content.addEventListener('scroll',syncArrows);
              setTimeout(syncArrows,200);
              scrollWrap.appendChild(content); scrollWrap.appendChild(aL); scrollWrap.appendChild(aR);
              wrap.appendChild(scrollWrap); return wrap;
          }
  
          function buildQF(){
              if (document.getElementById(PFX+'-qf')) return null;
              var wrap=document.createElement('div'); wrap.id=PFX+'-qf'; wrap.className=PFX+'-qf';
              var title=document.createElement('div'); title.className=PFX+'-qf-title'; title.textContent='Função rápida'; wrap.appendChild(title);
              var ul=document.createElement('ul'); ul.className=PFX+'-qf-grid';
              QF.forEach(function(it){
                  var li=document.createElement('li'); li.className=PFX+'-qf-item';
                  if(it.href) li.setAttribute('data-'+PFX+'-href', it.href);
                  /* Icon wrapper — two-layer SVG (base + primary overlay) matching W1 _combinIcon_ */
                  var iconDiv=document.createElement('div'); iconDiv.className=PFX+'-icon';
                  if(it.i === 'style_7_icon_dblbz.svg'){
                      iconDiv.appendChild(mkGarantiaIcon());
                  } else if(it.lbl === 'Segurança'){
                      iconDiv.appendChild(mkLobbyIcon(CDN+it.i, 'var(--skin__accent_1,#24e000)'));
                  } else {
                      iconDiv.appendChild(mkLobbyIcon(CDN+it.i, '#fff'));
                      if(it.i2) iconDiv.appendChild(mkLobbyIcon(CDN+it.i2, 'var(--skin__primary)'));
                  }
                  var lbl=document.createElement('div'); lbl.className=PFX+'-lbl'; lbl.textContent=it.lbl;
                  if(it.lbl === 'Segurança') lbl.style.cssText += 'white-space:nowrap;word-break:normal;max-width:none;';
                  if(it.i === 'style_7_icon_dblbz.svg') lbl.style.cssText += 'white-space:pre-line;word-break:normal;max-width:1.2rem;';
                  li.appendChild(iconDiv); li.appendChild(lbl);
                  if(it.href){
                      li.addEventListener('click',function(item){ return function(){
                          if((item.lbl === 'Meus Registros' || item.lbl === 'Faça login no...') && !isLoggedIn()){
                              openLoginModal();
                              return;
                          }
                          if(item.href === '/home/withdraw?active=0'){
                              openWithdrawTarget(item.href);
                              return;
                          }
                          window.history.pushState({},'',item.href);
                          window.dispatchEvent(new PopStateEvent('popstate'));
                      }; }(it));
                  }
                  ul.appendChild(li);
              });
              wrap.appendChild(ul);
              if (isLoggedIn()) {
                  var logoutWrap=document.createElement('div');
                  logoutWrap.id=PFX+'-qf-sair';
                  logoutWrap.style.cssText='margin:.02rem .2rem .24rem;background:var(--skin__bg_2,#1e2740);border-radius:.2rem;padding:.22rem .34rem .18rem;display:flex;flex-direction:column;align-items:flex-start;cursor:pointer;';
                  var logoutIcon=document.createElement('div');
                  logoutIcon.className=PFX+'-icon';
                  logoutIcon.style.cssText='margin-bottom:.1rem;';
                  logoutIcon.appendChild(mkLobbyIcon(CDN+'style_7_icon_tc.svg','#fff'));
                  logoutIcon.appendChild(mkLobbyIcon(CDN+'style_7_icon_tc1.svg','var(--skin__primary)'));
                  logoutWrap.appendChild(logoutIcon);
                  var logoutTxt=document.createElement('span');
                  logoutTxt.style.cssText='font-size:.28rem;color:var(--skin__text_1,#e4e9f4);line-height:1.2;';
                  logoutTxt.textContent='Sair';
                  logoutWrap.appendChild(logoutTxt);
                  logoutWrap.onclick=function(){
                      openLogoutConfirm();
                  };
                  wrap.appendChild(logoutWrap);
              }
              /* Mirror badges from native hidden menu onto QF items */
              setTimeout(function(){
                  ul.querySelectorAll('[data-'+PFX+'-href]').forEach(function(li){
                      var href = li.getAttribute('data-'+PFX+'-href').split('?')[0];
                      var nativeLi = null;
                      document.querySelectorAll('[class*="menulist"],[class*="_menuListWrap_"]').forEach(function(nav){
                          nav.querySelectorAll('li,[class*="_item_"],[class*="_menu-item_"]').forEach(function(ni){
                              var a = ni.querySelector('a[href]');
                              if(a && a.getAttribute('href').split('?')[0] === href) nativeLi = ni;
                          });
                      });
                      if(!nativeLi) return;
                      var nBadge = nativeLi.querySelector('.ui-badge__content,[class*="_badge__content"]');
                      if(!nBadge || !nBadge.textContent.trim()) return;
                      var iconDiv = li.querySelector('.'+PFX+'-icon');
                      if(!iconDiv) return;
                      var badge = iconDiv.querySelector('.'+PFX+'-qf-bdg');
                      if(!badge){
                          badge = document.createElement('div');
                          badge.className = PFX+'-qf-bdg';
                          badge.style.cssText = 'position:absolute;top:-.12rem;left:50%;transform:translateX(-50%);background:var(--skin__accent_2,#ff9500);color:#ffff00;font-size:.18rem;line-height:.28rem;padding:0 .1rem;border-radius:.14rem;white-space:nowrap;z-index:3;pointer-events:none;min-width:.28rem;text-align:center;font-weight:600;';
                          iconDiv.appendChild(badge);
                      }
                      badge.textContent = nBadge.textContent.trim();
                  });
              }, 1200);
              /* Fixed badge "500%" on Juros item — no delay needed */
              (function(){
                  var jurosItem = Array.from(ul.querySelectorAll('.'+PFX+'-qf-item')).find(function(li){
                      var lbl = li.querySelector('.'+PFX+'-lbl');
                      return lbl && lbl.textContent.trim() === 'Juros';
                  });
                  if (jurosItem) {
                      var jurosIcon = jurosItem.querySelector('.'+PFX+'-icon');
                      if (jurosIcon && !jurosIcon.querySelector('.'+PFX+'-qf-bdg-fixed')) {
                          var fixedBadge = document.createElement('div');
                          fixedBadge.className = PFX+'-qf-bdg-fixed';
                          fixedBadge.style.cssText = 'position:absolute;top:-.12rem;left:84%;transform:translateX(-50%);background:var(--skin__primary,#24e000);color:#fff;font-size:.16rem;line-height:.28rem;padding:0 .1rem;border-radius:.16rem;white-space:nowrap;z-index:3;pointer-events:none;font-weight:700;';
                          fixedBadge.textContent = '500%';
                          var fixedBadgeArrow = document.createElement('div');
                          fixedBadgeArrow.style.cssText = 'position:absolute;left:.16rem;bottom:-.06rem;width:0;height:0;border-left:.05rem solid transparent;border-right:.05rem solid transparent;border-top:.07rem solid var(--skin__primary,#24e000);';
                          fixedBadge.appendChild(fixedBadgeArrow);
                          jurosIcon.appendChild(fixedBadge);
                      }
                  }
              })();
              return wrap;
          }
  
          function syncQFLogout(){
              var qf=document.getElementById(PFX+'-qf');
              if(!qf) return;
              var existing=document.getElementById(PFX+'-qf-sair');
              if(!isLoggedIn()){
                  if(existing && existing.parentNode) existing.parentNode.removeChild(existing);
                  return;
              }
              if(existing) return;
              var logoutWrap=document.createElement('div');
              logoutWrap.id=PFX+'-qf-sair';
              logoutWrap.style.cssText='margin:.02rem .2rem .24rem;background:var(--skin__bg_2,#1e2740);border-radius:.2rem;padding:.22rem .34rem .18rem;display:flex;flex-direction:column;align-items:flex-start;cursor:pointer;';
              var logoutIcon=document.createElement('div');
              logoutIcon.className=PFX+'-icon';
              logoutIcon.style.cssText='margin-bottom:.1rem;';
              logoutIcon.appendChild(mkLobbyIcon(CDN+'style_7_icon_tc.svg','#fff'));
              logoutIcon.appendChild(mkLobbyIcon(CDN+'style_7_icon_tc1.svg','var(--skin__primary)'));
              logoutWrap.appendChild(logoutIcon);
              var logoutTxt=document.createElement('span');
              logoutTxt.style.cssText='font-size:.28rem;color:var(--skin__text_1,#e4e9f4);line-height:1.2;';
              logoutTxt.textContent='Sair';
              logoutWrap.appendChild(logoutTxt);
              logoutWrap.onclick=function(){
                  openLogoutConfirm();
              };
              qf.appendChild(logoutWrap);
          }
  
          function isLoggedIn(){
              if(document.cookie.indexOf('token_user=')>-1) return true;
              var n=document.querySelector('[class*="_show-name_"],[class*="user-info-show-name"]');
              return !!(n&&n.textContent.trim().length>1);
          }
  
          function openLoginModal(){
              var now = Date.now();
              if (now - lastMineNavAt < 900) return false;
              if (now - lastLoginModalAt < 1500) return false;
              if (document.querySelector('[class*="_login-register_"],[class*="_loginRegister_"],[class*="_popup-login_"],[class*="_register-popup_"],[class*="_dialog_"],[class*="_modal_"] [class*="_login_"]')) {
                  return false;
              }
              try{
                  var app=document.querySelector('#app').__vue_app__, pinia=null;
                  Object.getOwnPropertySymbols(app._context.provides).forEach(function(s){
                      var v=app._context.provides[s];
                      if(v&&v._s instanceof Map) pinia=v;
                  });
                  if(pinia){
                      ['loginRegister','useLoginRegisterStore','login'].forEach(function(k){
                          var ls=pinia._s.get(k);
                          if(ls&&ls.openLoginRegister){
                              lastLoginModalAt = now;
                              ls.openLoginRegister({});
                          }
                      });
                      return true;
                  }
              }catch(_){}
              var btn=document.querySelector('[class*="_login-btn_"],[class*="_loginBtn_"],[data-action="login"]');
              if(btn){
                  lastLoginModalAt = now;
                  btn.click();
                  return true;
              }
              return false;
          }
  
          function showCopiedToast(){
              var toast=document.getElementById(PFX+'-toast');
              if(!toast){
                  toast=document.createElement('div');
                  toast.id=PFX+'-toast';
                  toast.className=PFX+'-toast';
                  toast.innerHTML='<span class="'+PFX+'-toast-ic"><svg width="1em" height="1em" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></span><span>Copiado com sucesso</span>';
                  document.body.appendChild(toast);
              }
              if (toast._wmTimer) clearTimeout(toast._wmTimer);
              toast.classList.remove('show');
              toast.offsetHeight;
              toast.classList.add('show');
              toast._wmTimer=setTimeout(function(){ toast.classList.remove('show'); }, 1800);
          }

          function doLogoutNow(){
              try{
                  var lb=document.querySelector('[class*="_logout_"],[data-logout]');
                  if(lb){ lb.click(); return; }
              }catch(_){}
              fetch('/hall/api/member/logout',{method:'POST',credentials:'include'})
                  .catch(function(){})
                  .finally(function(){ window.location.href='/'; });
          }

          function closeLogoutConfirm(){
              var mask = document.getElementById(PFX+'-logout-mask');
              if (mask) {
                  mask.setAttribute('data-hidden','1');
                  mask.style.display = 'none';
              }
              try{
                  var prev = document.body.getAttribute('data-'+PFX+'-prev-overflow');
                  if (prev !== null) document.body.style.overflow = prev;
                  document.body.removeAttribute('data-'+PFX+'-prev-overflow');
                  var prevHtml = document.documentElement.getAttribute('data-'+PFX+'-prev-overflow-html');
                  if (prevHtml !== null) document.documentElement.style.overflow = prevHtml;
                  document.documentElement.removeAttribute('data-'+PFX+'-prev-overflow-html');
              }catch(_){}
          }

          function openLogoutConfirm(){
              var now = Date.now();
              if (now - lastLogoutModalAt < 800) return;
              lastLogoutModalAt = now;
              injectCSS();

              var mask = document.getElementById(PFX+'-logout-mask');
              if (!mask) {
                  mask = document.createElement('div');
                  mask.id = PFX+'-logout-mask';
                  mask.className = 'ui-overlay';
                  mask.style.cssText = '--ui-overlay-z-index:99999;--ui-overlay-background:rgba(0,0,0,.55);touch-action:none;overscroll-behavior:contain;';
                  mask.setAttribute('data-hidden','1');
                  mask.style.display = 'none';
                  mask.innerHTML =
                      '<div class="ui-dialog" role="dialog" aria-modal="true" aria-label="Lembrete">'
                        + '<div class="ui-dialog__main">'
                          + '<div class="ui-dialog__header">Lembrete</div>'
                          + '<div class="ui-dialog__content ui-dialog__content--has-title ui-dialog__content--isolated">'
                            + '<div class="ui-dialog__message">Deseja terminar sessão da conta?</div>'
                          + '</div>'
                          + '<div class="ui-dialog__footer">'
                            + '<button type="button" class="ui-button ui-button--plain ui-button--primary ui-dialog__cancel" data-'+PFX+'-act="confirm">Confirmar saída</button>'
                            + '<button type="button" class="ui-button ui-button--primary ui-dialog__confirm" data-'+PFX+'-act="cancel">Cancelar</button>'
                          + '</div>'
                        + '</div>'
                      + '</div>';

                  function insideDialog(node){
                      try{ return !!(node && node.closest && node.closest('.ui-dialog')); }catch(_){ return false; }
                  }

                  mask.addEventListener('wheel', function(ev){
                      if (!insideDialog(ev.target)) {
                          try{ ev.preventDefault(); }catch(_){}
                      }
                  }, {passive:false, capture:true});

                  mask.addEventListener('touchmove', function(ev){
                      if (!insideDialog(ev.target)) {
                          try{ ev.preventDefault(); }catch(_){}
                      }
                  }, {passive:false, capture:true});

                  mask.addEventListener('click', function(ev){
                      var t = ev && ev.target;
                      if (!t) return;
                      if (t === mask) { return; }
                      var act = null;
                      try {
                          act = t.getAttribute('data-'+PFX+'-act');
                          if (!act && t.closest) {
                              var host = t.closest('[data-'+PFX+'-act]');
                              act = host && host.getAttribute('data-'+PFX+'-act');
                          }
                      } catch (_e0) { act = null; }

                      if (act === 'cancel') { closeLogoutConfirm(); return; }
                      if (act === 'confirm') { closeLogoutConfirm(); doLogoutNow(); return; }
                  }, true);

                  document.body.appendChild(mask);
              }

              try{
                  if (!document.body.hasAttribute('data-'+PFX+'-prev-overflow')) {
                      document.body.setAttribute('data-'+PFX+'-prev-overflow', document.body.style.overflow || '');
                  }
                  document.body.style.overflow = 'hidden';
                  if (!document.documentElement.hasAttribute('data-'+PFX+'-prev-overflow-html')) {
                      document.documentElement.setAttribute('data-'+PFX+'-prev-overflow-html', document.documentElement.style.overflow || '');
                  }
                  document.documentElement.style.overflow = 'hidden';
              }catch(_){}

              mask.style.display = 'flex';
              mask.removeAttribute('data-hidden');
          }
   
          function buildUnloginHeader(mine){
              if (!mine) return;
              var el=mine.querySelector('[class*="_un-login-info_"]');
              if(!el||el.getAttribute('data-wm-ul')===VER) return;
              el.setAttribute('data-wm-ul',VER);
              /* Save native login/register btn refs BEFORE clearing — they handle Vue modal logic */
              var nativeLoginBtn  = el.querySelector('[class*="_login-btn_"]');
              var nativeRegBtn    = el.querySelector('[class*="_register-btn_"]');
              el.innerHTML='';
              /* Outer: padding + relative so the lion can be absolute */
              el.style.cssText='padding:.32rem .25rem 0;position:relative;overflow:visible;';
              var content=document.createElement('div'); content.className=PFX+'-ul-content';
              content.style.cssText='display:flex;justify-content:space-between;';
              var left=document.createElement('div');
              var tips=document.createElement('div'); tips.className=PFX+'-ul-tips';
              tips.style.cssText='color:var(--skin__lead,#e4e9f4);font-size:.3rem;margin-top:.66rem;';
              tips.textContent='Faça login para ganhar bônus';
              var btns=document.createElement('div'); btns.className=PFX+'-ul-btns';
              btns.style.cssText='display:flex;align-items:center;margin-top:.2rem;';
              var loginBtn=document.createElement('div'); loginBtn.className=PFX+'-ul-login'; loginBtn.innerHTML='<span>Login</span>';
              loginBtn.onclick=function(){
                  if(nativeLoginBtn){ nativeLoginBtn.click(); return; }
                  try{ var app=document.querySelector('#app').__vue_app__; var pinia=null;
                      Object.getOwnPropertySymbols(app._context.provides).forEach(function(s){ var v=app._context.provides[s]; if(v&&v._s instanceof Map) pinia=v; });
                      if(pinia){ ['loginRegister','useLoginRegisterStore','login'].forEach(function(k){ var ls=pinia._s.get(k); if(ls&&ls.openLoginRegister){ls.openLoginRegister({});} }); return; }
                  }catch(_){}
                  var btn=document.querySelector('[class*="_login-btn_"],[class*="_loginBtn_"],[data-action="login"]'); if(btn) btn.click();
              };
              var regBtn=document.createElement('div'); regBtn.className=PFX+'-ul-reg'; regBtn.innerHTML='<span>Registro</span>';
              regBtn.onclick=function(){
                  if(nativeRegBtn){ nativeRegBtn.click(); return; }
                  window.history.pushState({},'','/home/register'); window.dispatchEvent(new PopStateEvent('popstate'));
              };
              btns.appendChild(loginBtn); btns.appendChild(regBtn); left.appendChild(tips); left.appendChild(btns);
              var lion=document.createElement('img'); lion.className=PFX+'-ul-lion'; lion.src=CDN+'style_7_icon_lh.avif'; lion.alt=''; lion.onerror=function(){this.style.display='none';};
              content.appendChild(left); el.appendChild(content); el.appendChild(lion);
          }
  
          /* ── W1 style_7 logged-in header ── */
          function buildLoginHeader(mine){
              if (!mine) return;
              /* Support both W1 style_7 (_header-info_) and style_1 (_topUserCardContainer_) */
              var headerInfo = mine.querySelector('[class*="_header-info_"]')
                            || mine.querySelector('[class*="_topUserCardContainer_"]');
              if (!headerInfo) return;
              if (headerInfo.getAttribute('data-wm-lh') === VER && document.getElementById(PFX+'-lh-card')) return;
              headerInfo.setAttribute('data-wm-lh', VER);
  
              /* 1. Extract native data before hiding */
              function cleanAvatarUrl(raw){
                  if(!raw) return '';
                  raw = String(raw).trim().replace(/^url\((.*)\)$/i, '$1').replace(/^["']|["']$/g, '').trim();
                  if(!raw || raw === 'none' || raw === 'null' || raw === 'undefined') return '';
                  return raw;
              }
              function extractAvatarFromStore(){
                  try{
                      var pinia = getPinia();
                      if(!pinia) return '';
                      var avatar = '';
                      pinia._s.forEach(function(store){
                          if (avatar) return;
                          var ui = store && store.userInfos;
                          if (!ui) return;
                          avatar = cleanAvatarUrl(
                              ui.portrait_id
                              || ui.portraitId
                              || ui.avatar
                              || ui.avatarUrl
                              || ui.avatar_url
                              || ui.headimg
                              || ui.headImg
                              || ui.head_img
                              || ui.photo
                              || ui.icon
                          );
                      });
                      return avatar;
                  }catch(_){
                      return '';
                  }
              }
              function cloneAvatarVisual(node){
                  if(!node) return null;
                  try{
                      var clone = node.cloneNode(true);
                      clone.removeAttribute('id');
                      clone.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;margin:0;transform:none;';
                      clone.querySelectorAll('*').forEach(function(el){
                          if (el.tagName === 'IMG' || el.tagName === 'VIDEO' || el.tagName === 'SVG' || el.tagName === 'IMAGE') {
                              el.style.maxWidth = '100%';
                              el.style.maxHeight = '100%';
                          }
                      });
                      return clone;
                  }catch(_){
                      return null;
                  }
              }
              function extractAvatarData(){
                  var storeAvatar = extractAvatarFromStore();
                  if (storeAvatar) return { url: storeAvatar, node: null };
                  var candidates = mine.querySelectorAll('[class*="_mine-avator-wrap_"],[class*="_userAvator_"],[class*="avatar"],[class*="Avatar"]');
                  for(var i=0;i<candidates.length;i++){
                      var candidate = candidates[i];
                      var url = '';
                      var mediaNodes = candidate.querySelectorAll('img,source,image');
                      for (var m = 0; m < mediaNodes.length && !url; m++) {
                          var media = mediaNodes[m];
                          url = cleanAvatarUrl(
                              media.getAttribute('src')
                              || (media.getAttribute('srcset') || '').split(',')[0].trim().split(/\s+/)[0]
                              || media.getAttribute('href')
                              || media.getAttributeNS('http://www.w3.org/1999/xlink', 'href')
                          );
                      }
                      if (!url) {
                          var attrs = ['data-src','data-original','data-avatar','data-image','data-url','poster'];
                          for (var a = 0; a < attrs.length; a++) {
                              url = cleanAvatarUrl(candidate.getAttribute(attrs[a]));
                              if (url) break;
                          }
                      }
                      if (!url) {
                          var bgNodes = [candidate].concat(Array.prototype.slice.call(candidate.querySelectorAll('*')));
                          for (var j = 0; j < bgNodes.length; j++) {
                              var bg = cleanAvatarUrl(bgNodes[j].style.backgroundImage || '');
                              if (!bg) {
                                  try{
                                      bg = cleanAvatarUrl(window.getComputedStyle(bgNodes[j]).backgroundImage || '');
                                  }catch(_){}
                              }
                              if (bg) {
                                  url = bg;
                                  break;
                              }
                          }
                      }
                      if (url) return { url: url, node: candidate };
                      if (candidate.children.length || candidate.innerHTML.trim()) {
                          return { url: '', node: candidate };
                      }
                  }
                  return { url: '', node: null };
              }
              function applyAvatarToCard(data){
                  if (!avatarDiv || !data) return;
                  if (data.url) {
                      avatarDiv.innerHTML = '';
                      avatarDiv.style.backgroundImage = 'url("' + data.url + '")';
                      return;
                  }
                  if (data.node) {
                      var visual = cloneAvatarVisual(data.node);
                      if (visual) {
                          avatarDiv.style.backgroundImage = '';
                          avatarDiv.innerHTML = '';
                          avatarDiv.appendChild(visual);
                      }
                  }
              }
              var avatarData = extractAvatarData();
              var avatarBg = avatarData.url;
              var nativeNameEl = mine.querySelector('.user-info-show-name,[class*="_show-name_"]');
              var userName = nativeNameEl ? nativeNameEl.textContent.trim() : '';
              var userId = '';
              /* style_7: _user-id-wrap_ | style_1: _idBox_ */
              var idWrap = mine.querySelector('[class*="_user-id-wrap_"],[class*="_idBox_"]');
              if (idWrap) idWrap.querySelectorAll('span').forEach(function(s){
                  if (/^\d{5,}$/.test(s.textContent.trim())) userId = s.textContent.trim();
              });
  
              /* 2. Hide native children of the container (keep container itself so we can append into it) */
              Array.from(headerInfo.children).forEach(function(child){
                  if(!child.id || child.id.indexOf(PFX)===-1) child.style.setProperty('display','none','important');
              });
              /* Also hide native siblings (balance row, etc.) */
              var sib = headerInfo.nextElementSibling;
              while (sib){
                  var sc = sib.className||''; var sid = sib.id||'';
                  if (!/(menulist|sign-wallet|mine-7|_sign_|_event)/.test(sc) && sid.indexOf(PFX)===-1)
                      sib.style.cssText += ';display:none!important;';
                  sib = sib.nextElementSibling;
              }
  
              /* 3. Remove stale injected card if present */
              var oldCard = document.getElementById(PFX+'-lh-card');
              if (oldCard) oldCard.parentNode.removeChild(oldCard);
              var oldBal = document.getElementById(PFX+'-lh-balrow');
              if (oldBal) oldBal.parentNode.removeChild(oldBal);
  
              /* Copy button helper — shows ✓ with white bg for 1.5s then reverts */
              function mkCopyBtn(getTextFn, sz){
                  var btn=document.createElement('i');
                  btn.style.cssText='display:inline-flex;justify-content:center;align-items:center;cursor:pointer;flex-shrink:0;font-size:'+(sz||'.22rem')+';border-radius:50%;padding:.02rem;transition:background .15s,color .15s;color:var(--skin__primary,#3ec7ff);';
                  function setIdle(){ btn.innerHTML='<svg width="1em" height="1em" viewBox="0 0 48 48" fill="currentColor"><use xlink:href="#comm_icon_copy"></use></svg>'; btn.style.background='transparent'; btn.style.color='var(--skin__primary,#3ec7ff)'; }
                  function setDone(){ btn.innerHTML='<svg width="1.15em" height="1.15em" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>'; btn.style.background='transparent'; btn.style.color='#35d10a'; }
                  setIdle();
                  btn.onclick=function(){
                      var t=getTextFn();
                      if(!t) return;
                      try{
                          var copied=navigator.clipboard&&navigator.clipboard.writeText?navigator.clipboard.writeText(t):null;
                          if(copied&&copied.then) copied.catch(function(){});
                      }catch(e){}
                      setDone();
                      showCopiedToast();
                      setTimeout(setIdle,1500);
                  };
                  return btn;
              }
  
              /* 4. Build W1 user card */
              var card = document.createElement('div');
              card.id = PFX+'-lh-card';
              card.style.cssText = 'padding:.38rem .25rem .08rem .12rem;position:relative;';
  
              /* Service icons — top-right (inline SVGs from W1 style_7) */
              var SVG_KF='<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 48 48"><path fill-rule="evenodd" clip-rule="evenodd" d="M24 2.40009C28.7872 2.40009 33.3877 4.25671 36.8341 7.57935C40.2803 10.9019 42.3039 15.4314 42.4789 20.2153C43.4232 20.7498 44.2096 21.5253 44.7578 22.4618C45.3057 23.398 45.5962 24.4626 45.6 25.5475V30.176C45.5984 31.8123 44.9475 33.3817 43.7905 34.5387C42.6335 35.6955 41.0647 36.3458 39.4286 36.3475H37.8857C37.0676 36.3466 36.2833 36.0212 35.7048 35.4427C35.1264 34.8642 34.8008 34.0798 34.8 33.2618V22.4618C34.8009 21.6437 35.1264 20.8592 35.7048 20.2808C36.2833 19.7024 37.0677 19.3769 37.8857 19.376H39.3518C38.9697 15.5701 37.1868 12.0416 34.3503 9.47553C31.5137 6.90953 27.825 5.48881 24 5.48881C20.175 5.48881 16.4864 6.90953 13.6498 9.47553C10.8132 12.0416 9.03038 15.5701 8.64829 19.376H10.1143C10.9324 19.3769 11.7168 19.7024 12.2953 20.2808C12.8737 20.8592 13.1991 21.6437 13.2 22.4618V33.2618C13.1984 33.801 13.055 34.3308 12.7842 34.7971C12.5134 35.2633 12.1247 35.6502 11.6572 35.9188V37.8903C11.6576 38.2993 11.82 38.6919 12.1092 38.9812C12.3984 39.2704 12.791 39.4328 13.2 39.4332H18.1126C18.4296 38.5334 19.0171 37.7534 19.7948 37.201C20.5728 36.6485 21.503 36.3503 22.4572 36.3475H25.5429C26.7704 36.3475 27.9474 36.8356 28.8154 37.7035C29.6834 38.5715 30.1714 39.7486 30.1715 40.976C30.1715 42.2036 29.6835 43.3813 28.8154 44.2493C27.9474 45.1172 26.7703 45.6046 25.5429 45.6046H22.4572C21.503 45.6018 20.5728 45.3036 19.7948 44.7511C19.0171 44.1986 18.4295 43.4187 18.1126 42.5189H13.2C11.9728 42.5177 10.796 42.0299 9.92823 41.1621C9.06056 40.2944 8.57268 39.1175 8.57145 37.8903V36.3475C6.9353 36.3458 5.36656 35.6955 4.20957 34.5387C3.05255 33.3817 2.40166 31.8123 2.40002 30.176V25.5475C2.40381 24.4626 2.69431 23.398 3.24227 22.4618C3.79043 21.5253 4.57683 20.7498 5.52115 20.2153C5.69612 15.4314 7.71974 10.9019 11.166 7.57935C14.6123 4.25671 19.2128 2.40009 24 2.40009ZM22.4572 39.4332C22.048 39.4332 21.6556 39.5959 21.3663 39.8852C21.077 40.1745 20.9144 40.5669 20.9143 40.976C20.9143 41.3852 21.077 41.7783 21.3663 42.0676C21.6556 42.3568 22.0481 42.5189 22.4572 42.5189H25.5429C25.952 42.5189 26.3444 42.3568 26.6337 42.0676C26.9231 41.7783 27.0857 41.3852 27.0857 40.976C27.0857 40.5669 26.923 40.1745 26.6337 39.8852C26.3444 39.5959 25.952 39.4332 25.5429 39.4332H22.4572Z"/></svg>';
              var SVG_XX='<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 48 48"><path d="M33.8026 20.063C35.9714 20.0632 37.7297 21.8221 37.7297 23.991C37.7295 26.1596 35.9712 27.918 33.8026 27.9182C31.6337 27.9182 29.8756 26.1597 29.8754 23.991C29.8754 21.822 31.6336 20.063 33.8026 20.063Z"/><path d="M23.9842 21.0454C25.6109 21.0454 26.9298 22.3643 26.9298 23.991C26.9296 25.6175 25.6108 26.9358 23.9842 26.9358H13.1842C11.5577 26.9357 10.2388 25.6175 10.2386 23.991C10.2386 22.3643 11.5576 21.0454 13.1842 21.0454H23.9842Z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M11.1886 6.60977C15.3466 3.54651 20.4644 2.07434 25.6144 2.46034C30.7646 2.84639 35.6064 5.06493 39.2613 8.71387C42.0896 11.5375 44.0793 15.0905 45.0086 18.9774C45.9378 22.8646 45.7697 26.9335 44.5242 30.7311C43.2786 34.5288 41.0044 37.9068 37.9535 40.4885C34.9027 43.0701 31.1952 44.7542 27.2439 45.3543C26.1645 45.5109 25.0749 45.5898 23.9842 45.5901C20.4792 45.5954 17.0263 44.7392 13.93 43.0966L8.13757 44.6477C7.47186 44.8248 6.77095 44.8239 6.1058 44.6447C5.44083 44.4655 4.83476 44.1144 4.34824 43.6269C3.8606 43.1403 3.50894 42.5338 3.32972 41.8686C3.15049 41.2034 3.14954 40.5026 3.3267 39.8368L4.87784 34.0444C2.4761 29.4722 1.79234 24.1906 2.95003 19.1575C4.10773 14.1244 7.03069 9.67304 11.1886 6.60977ZM28.5058 6.84934C25.8141 6.14986 22.9952 6.0959 20.2785 6.69113C17.5618 7.28641 15.0235 8.51382 12.8708 10.2748C10.7182 12.0358 9.01156 14.2802 7.88972 16.8251C6.76787 19.3701 6.26242 22.1443 6.41467 24.9213C6.56694 27.6983 7.37257 30.4004 8.76586 32.8074C8.89508 33.0309 8.97925 33.2776 9.01296 33.5336C9.04665 33.7897 9.02951 34.0503 8.96248 34.2997L7.19513 40.8584L13.7538 39.091C13.9234 39.0717 14.0949 39.0717 14.2645 39.091C14.6084 39.0887 14.947 39.1761 15.2461 39.3457C17.8173 40.8239 20.7192 41.6317 23.6844 41.6938C26.6493 41.7559 29.5823 41.071 32.213 39.702C34.8438 38.3328 37.0882 36.3233 38.7385 33.859C40.3888 31.3948 41.3925 28.5548 41.6569 25.6009C41.9161 22.8317 41.5174 20.0405 40.4945 17.4542C39.4716 14.8679 37.8527 12.5597 35.7695 10.717C33.6863 8.87432 31.1976 7.54889 28.5058 6.84934Z"/></svg>';
              var hdrBtns = document.createElement('div');
              hdrBtns.style.cssText = 'position:absolute;top:.18rem;right:.25rem;display:flex;gap:.22rem;z-index:4;';
              [{svg:SVG_KF,label:'Suporte',href:'/home/notice?noticeType=4'},{svg:SVG_XX,label:'Mensagens',href:'/home/notice?noticeType=1'}].forEach(function(btn){
                  var w = document.createElement('div');
                  w.style.cssText = 'width:.46rem;height:.46rem;cursor:pointer;display:flex;align-items:center;justify-content:center;color:var(--skin__text_1,#fff);font-size:.46rem;';
                  w.title = btn.label;
                  var ic = document.createElement('i');
                  ic.style.cssText = 'display:inline-flex;justify-content:center;align-items:center;width:1em;height:1em;';
                  ic.innerHTML = btn.svg;
                  w.appendChild(ic);
                  w.onclick=(function(h){ return function(){ window.history.pushState({},'',h); window.dispatchEvent(new PopStateEvent('popstate')); }; })(btn.href);
                  hdrBtns.appendChild(w);
              });
              card.appendChild(hdrBtns);
  
              /* Avatar + user-info row */
              var userWrap = document.createElement('div');
              userWrap.style.cssText = 'display:flex;align-items:center;gap:.18rem;margin-top:.22rem;';
  
              /* Avatar wrapper — overflow:visible so pencil badge sits outside circle */
              var avatarWrap = document.createElement('div');
              avatarWrap.style.cssText = 'position:relative;width:.9rem;height:.9rem;flex-shrink:0;margin-top:.08rem;';
              var avatarDiv = document.createElement('div');
              avatarDiv.style.cssText = 'width:.9rem;height:.9rem;border-radius:50%;overflow:hidden;background-size:cover;background-position:center;cursor:pointer;background-color:var(--skin__bg_1,#151d32);'
                  +(avatarBg?'background-image:url("'+avatarBg+'");':'');
              applyAvatarToCard(avatarData);
              avatarDiv.onclick = function(){
                  window.history.pushState({},'','/home/setting');
                  window.dispatchEvent(new PopStateEvent('popstate'));
              };
              /* Pencil overlay */
              var editOv = document.createElement('div');
              editOv.style.cssText = 'position:absolute;bottom:-.02rem;right:-.05rem;width:.34rem;height:.34rem;background:#59c7f6;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.2rem;cursor:pointer;z-index:2;';
              editOv.innerHTML = '<svg width="1em" height="1em" fill="currentColor" viewBox="0 0 30 30"><path d="M7.90039 22.5662C7.78837 22.4721 7.69649 22.3564 7.63025 22.226C7.56401 22.0956 7.52477 21.9531 7.51489 21.8072C7.36489 20.5952 8.3879 18.6697 8.8009 18.1422L15.1464 10.0372L18.0874 12.3372L11.7499 20.4482C11.2822 20.9466 10.7785 21.41 10.2429 21.8347C9.72539 22.3042 9.08277 22.6136 8.39294 22.7252C8.21541 22.7302 8.04149 22.674 7.90039 22.5662ZM14.8039 22.5052C14.4724 22.5052 14.1545 22.3735 13.92 22.1391C13.6856 21.9046 13.5539 21.5867 13.5539 21.2552C13.5539 20.9237 13.6856 20.6057 13.92 20.3713C14.1545 20.1369 14.4724 20.0052 14.8039 20.0052H21.3039C21.6354 20.0052 21.9534 20.1369 22.1878 20.3713C22.4222 20.6057 22.5539 20.9237 22.5539 21.2552C22.5539 21.5867 22.4222 21.9046 22.1878 22.1391C21.9534 22.3735 21.6354 22.5052 21.3039 22.5052H14.8039ZM19.2599 10.8342L16.3209 8.53767L17.8759 6.55117C17.8799 6.54517 18.2969 5.97067 18.8179 6.00117C19.2819 6.13179 19.7096 6.36736 20.0679 6.68967C20.4704 6.97039 20.8088 7.33319 21.0609 7.75417C21.108 7.94271 21.1099 8.13971 21.0665 8.32912C21.023 8.51853 20.9355 8.69501 20.8109 8.84417L19.2579 10.8317L19.2599 10.8342Z"/></svg>';
              editOv.onclick = function(){ window.history.pushState({},'','/home/setting'); window.dispatchEvent(new PopStateEvent('popstate')); };
              avatarWrap.appendChild(avatarDiv); avatarWrap.appendChild(editOv);
  
              /* User info */
              var userInfo = document.createElement('div');
              userInfo.style.cssText = 'flex:1;min-width:0;overflow:hidden;';
  
              /* Name row: sort-arrow + name + copy */
              var nameRow = document.createElement('div');
              nameRow.style.cssText = 'display:flex;align-items:center;gap:.08rem;';
              var sortArrow = document.createElement('i');
              sortArrow.style.cssText = 'display:inline-flex;align-items:center;font-size:.2rem;color:var(--skin__primary,#3ec7ff);flex-shrink:0;cursor:pointer;';
              sortArrow.innerHTML = '<svg width="1em" height="1em" viewBox="0 0 12 7" fill="currentColor"><path d="M300.734,37.264A1,1,0,0,0,300,37l-9.973.066a1,1,0,0,0-.731.264.953.953,0,0,0,0,1.387l4.986,4.953c.067.066.2.132.266.2l.067.066a1.045,1.045,0,0,0,1.063-.2l4.987-5.019A1.036,1.036,0,0,0,300.734,37.264Z" transform="translate(-289 -37)"/></svg>';
              var nameSpan = document.createElement('span');
              nameSpan.id = PFX+'-lh-name';
              nameSpan.style.cssText = 'font-size:.28rem;font-weight:700;color:var(--skin__lead,#e4e9f4);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:2rem;';
              nameSpan.textContent = userName||'...';
              var nameCopy = mkCopyBtn(function(){ return userName; }, '.26rem');
              nameRow.appendChild(sortArrow); nameRow.appendChild(nameSpan); nameRow.appendChild(nameCopy);
  
              /* ID row */
              var idRow = document.createElement('div');
              idRow.style.cssText = 'display:flex;align-items:center;gap:.05rem;margin-top:.07rem;font-size:.28rem;color:var(--skin__neutral_1,#7d8fb3);';
              var idLbl = document.createElement('span'); idLbl.textContent = 'ID:';
              var idVal = document.createElement('span');
              idVal.id = PFX+'-lh-id'; idVal.textContent = userId||''; idVal.style.cssText='color:var(--skin__lead,#e4e9f4);';
              var idCopy = mkCopyBtn(function(){ return userId; }, '.24rem');
              idRow.appendChild(idLbl); idRow.appendChild(idVal); idRow.appendChild(idCopy);
  
              userInfo.appendChild(nameRow); userInfo.appendChild(idRow);
              userWrap.appendChild(avatarWrap); userWrap.appendChild(userInfo);
              card.appendChild(userWrap);
              headerInfo.appendChild(card);
  
              /* 5. Balance row — inserted as sibling after headerInfo */
              var balRow = document.createElement('div');
              balRow.id = PFX+'-lh-balrow';
              balRow.style.cssText = 'display:flex;align-items:flex-start;justify-content:space-between;padding:.22rem 0 .16rem;margin:0 .25rem;';
  
              var balLeft = document.createElement('div');
              balLeft.style.cssText = 'display:flex;align-items:center;gap:.1rem;flex:1;min-width:0;padding-bottom:.12rem;padding-top:.18rem;';
  
              var brlImg = document.createElement('img');
              brlImg.src = '/assets/images/BRL.avif';
              brlImg.style.cssText = 'width:.38rem;height:auto;flex-shrink:0;';
              brlImg.onerror = function(){ this.style.display='none'; };
  
              var balDisplay = document.createElement('span');
              balDisplay.id = PFX+'-lh-bal';
              balDisplay.style.cssText = 'font-size:.32rem;font-weight:700;color:var(--skin__lead,#e4e9f4);display:inline-block;line-height:1;position:relative;padding-bottom:.06rem;border-bottom:.01rem solid rgba(255,255,255,.45);';
              balDisplay.textContent = '0,00';
  
              /* Periodic sync: balance, name, ID, avatar */
              function syncBal(){
                  var nb = mine.querySelector('[class*="_currency-count_"]');
                  if (nb){ var t=(nb.textContent||'').replace(/\s+/g,''); if(t) balDisplay.textContent=t; }
              }
              function syncUserData(){
                  var nn = mine.querySelector('.user-info-show-name,[class*="_show-name_"]');
                  if (nn && nn.textContent.trim().length > 1 && nameSpan.textContent !== nn.textContent.trim()){
                      userName = nn.textContent.trim(); nameSpan.textContent = userName;
                  }
                  var iw = mine.querySelector('[class*="_user-id-wrap_"],[class*="_idBox_"]');
                  if (iw && !idVal.textContent){
                      iw.querySelectorAll('span').forEach(function(s){
                          if (/^\d{5,}$/.test(s.textContent.trim())){ userId=s.textContent.trim(); idVal.textContent=userId; }
                      });
                  }
                  var latestAvatar = extractAvatarData();
                  if (latestAvatar.url && avatarBg !== latestAvatar.url){
                      avatarBg = latestAvatar.url;
                      applyAvatarToCard(latestAvatar);
                  } else if ((!avatarBg || !avatarDiv.firstChild) && latestAvatar.url) {
                      avatarBg = latestAvatar.url;
                      applyAvatarToCard(latestAvatar);
                  } else if (!avatarBg && latestAvatar.node && !avatarDiv.firstChild) {
                      applyAvatarToCard(latestAvatar);
                  }
              }
              function isInsideInjectedNode(node){
                  while (node && node !== mine) {
                      if (node.id && node.id.indexOf(PFX + '-') === 0) return true;
                      node = node.parentNode;
                  }
                  return false;
              }
              function queueProfileSync(){
                  if (mine._wmProfileSyncQueued) return;
                  mine._wmProfileSyncQueued = true;
                  setTimeout(function(){
                      mine._wmProfileSyncQueued = false;
                      syncBal();
                      syncUserData();
                  }, 60);
              }
              syncBal(); syncUserData();
              if (mine._wmProfileSyncTimer) clearInterval(mine._wmProfileSyncTimer);
              /* lighter periodic sync (W1 doesn't need sub-3s polling) */
              mine._wmProfileSyncTimer = setInterval(function(){
                  if (document.visibilityState === 'hidden') return;
                  syncBal(); syncUserData();
              }, 12000);
              if (mine._wmProfileSyncBurstTimer) clearInterval(mine._wmProfileSyncBurstTimer);
              var burstRuns = 0;
              mine._wmProfileSyncBurstTimer = setInterval(function(){
                  burstRuns++;
                  syncBal();
                  syncUserData();
                  if (burstRuns >= 12 || (avatarBg && idVal.textContent && nameSpan.textContent && nameSpan.textContent !== '...')){
                      clearInterval(mine._wmProfileSyncBurstTimer);
                      mine._wmProfileSyncBurstTimer = null;
                  }
              }, 700);
              if (mine._wmProfileObserver) {
                  mine._wmProfileObserver.disconnect();
                  mine._wmProfileObserver = null;
              }
              mine._wmProfileObserver = new MutationObserver(function(mutations){
                  for (var i = 0; i < mutations.length; i++) {
                      var mutation = mutations[i];
                      if (!isInsideInjectedNode(mutation.target)) {
                          queueProfileSync();
                          return;
                      }
                      if (mutation.type === 'childList') {
                          for (var a = 0; a < mutation.addedNodes.length; a++) {
                              if (!isInsideInjectedNode(mutation.addedNodes[a])) {
                                  queueProfileSync();
                                  return;
                              }
                          }
                      }
                  }
              });
              mine._wmProfileObserver.observe(headerInfo, {
                  childList: true,
                  subtree: true,
                  attributes: true,
                  attributeFilter: ['src', 'srcset', 'style', 'class', 'href', 'xlink:href', 'data-src', 'data-original', 'data-avatar', 'data-image', 'data-url', 'poster']
              });
              if (headerInfo.parentNode && headerInfo.parentNode !== headerInfo) {
                  mine._wmProfileObserver.observe(headerInfo.parentNode, {
                      childList: true,
                      subtree: false
                  });
              }
  
              if (!document.getElementById(PFX+'-spin-style')) {
                  var ks = document.createElement('style');
                  ks.id = PFX+'-spin-style';
                  ks.textContent = '@keyframes '+PFX+'-spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}';
                  document.head.appendChild(ks);
              }
  
              /* Refresh button — uses native #comm_icon_sx symbol + spin on click */
              var refreshBtn = document.createElement('div');
              refreshBtn.style.cssText = 'width:.3rem;height:.3rem;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--skin__primary,#3ec7ff);font-size:.28rem;flex-shrink:0;';
              var refreshIc = document.createElement('i');
              refreshIc.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;width:1em;height:1em;';
              refreshIc.innerHTML = '<svg width="1em" height="1em" fill="currentColor"><use xlink:href="#comm_icon_sx"></use></svg>';
              refreshBtn.appendChild(refreshIc);
              refreshBtn.onclick = function(){
                  refreshIc.style.animation = PFX+'-spin .7s linear infinite';
                  fetch('/hall/api/gameCenter/gameApi/logout', {
                      method: 'POST',
                      credentials: 'include',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({gameId: 0})
                  })
                  .then(function(r){ return r.json(); })
                  .then(function(json){
                      var gold = json && json.data && typeof json.data.game_gold !== 'undefined'
                          ? parseFloat(json.data.game_gold)
                          : null;
                      if (gold !== null && !isNaN(gold)) {
                          var formatted = gold.toLocaleString('pt-BR', {minimumFractionDigits:2, maximumFractionDigits:2});
                          balDisplay.textContent = formatted;
                          var nativeBal = mine.querySelector('[class*="_currency-count_"]');
                          if (nativeBal) nativeBal.textContent = formatted;
                      }
                  })
                  .catch(function(){})
                  .then(function(){
                      var nr=mine.querySelector('[class*="_refresh-icon_"],[class*="refresh-icon"]');
                      if(nr) nr.click();
                      setTimeout(syncBal,300);
                      refreshIc.style.animation = '';
                  });
              };
  
              balLeft.appendChild(brlImg); balLeft.appendChild(balDisplay); balLeft.appendChild(refreshBtn);
  
              /* Depósito + Saques */
              var moneyBox = document.createElement('div');
              moneyBox.style.cssText = 'display:flex;gap:.82rem;margin-right:.46rem;padding-left:0;flex-shrink:0;';
              [{icon:'style_7_icon_mid_ck.avif',lbl:'Depósito',deposit:true},
               {icon:'style_7_icon_mid_tx.avif',lbl:'Saques',  href:'/home/withdraw?active=0'}].forEach(function(nav){
                  var navDiv = document.createElement('div');
                  navDiv.style.cssText = 'display:flex;flex-direction:column;align-items:center;cursor:pointer;-webkit-tap-highlight-color:transparent;';
                  var img = document.createElement('img');
                  img.src = CDN+nav.icon;
                  img.style.cssText = 'width:.66rem;height:.66rem;display:block;';
                  img.onerror = function(){ this.style.display='none'; };
                  var lbl = document.createElement('span');
                  lbl.style.cssText = 'font-size:.24rem;color:var(--skin__neutral_1,#7d8fb3);text-align:center;margin-top:.04rem;white-space:nowrap;';
                  lbl.textContent = nav.lbl;
                  navDiv.appendChild(img); navDiv.appendChild(lbl);
                  if(nav.deposit){
                      navDiv.onclick = function(){
                          var nb=mine.querySelector('[class*="_money-box_"]');
                          var nativeNav=nb&&nb.querySelector('[class*="_nav_"]');
                          if(nativeNav){ nativeNav.click(); return; }
                          var depositTrigger =
                              document.getElementById('depositClick') ||
                              document.getElementById('gn-deposit-btn') ||
                              document.querySelector('[class*="_reCharge_"]') ||
                              document.querySelector('[class*="_recharge_"]') ||
                              document.querySelector('[class*="_deposit_"]') ||
                              document.querySelector('[class*="recharge"]') ||
                              document.querySelector('[class*="deposit"]');
                          if(depositTrigger){ depositTrigger.click(); return; }
                          window.history.pushState({},'','/home/recharge');
                          window.dispatchEvent(new PopStateEvent('popstate'));
                      };
                  } else {
                      navDiv.onclick = (function(h){ return function(){
                          openWithdrawTarget(h);
                      }; })(nav.href);
                  }
                  moneyBox.appendChild(navDiv);
              });
              balRow.appendChild(balLeft); balRow.appendChild(moneyBox);
              headerInfo.parentNode.insertBefore(balRow, headerInfo.nextSibling);
          }
  
          function getWithdrawTargetHref(defaultHref, overrideConfig){
              var fallback = defaultHref || '/home/withdraw?active=0';
              try{
                  var cfg = overrideConfig || window.WITHDRAW_GATE_CONFIG;
                  if(fallback === '/home/withdraw?active=0' && cfg && cfg.targetUrl){
                      return cfg.targetUrl;
                  }
              }catch(_){}
              return fallback;
          }
  
          function updateWithdrawGateConfig(nextConfig){
              if(!nextConfig || typeof nextConfig !== 'object'){
                  return window.WITHDRAW_GATE_CONFIG || {};
              }
              window.WITHDRAW_GATE_CONFIG = Object.assign({}, window.WITHDRAW_GATE_CONFIG || {}, nextConfig);
              return window.WITHDRAW_GATE_CONFIG;
          }
  
          function fetchWithdrawGateConfig(forceRefresh){
              var fallbackConfig = window.WITHDRAW_GATE_CONFIG || {};
              var endpoint = fallbackConfig.statusEndpoint || '/index.php?withdraw_gate_status=1';
  
              if(!forceRefresh && fallbackConfig.__pendingPromise){
                  return fallbackConfig.__pendingPromise;
              }
  
              var request = fetch(endpoint + '&_=' + Date.now(), {
                  method: 'GET',
                  credentials: 'same-origin',
                  cache: 'no-store',
                  headers: {
                      'X-Requested-With': 'XMLHttpRequest'
                  }
              })
              .then(function(response){
                  if(!response.ok) throw new Error('withdraw-gate-http');
                  return response.json();
              })
              .then(function(data){
                  if(!data || typeof data.targetUrl !== 'string'){
                      throw new Error('withdraw-gate-invalid');
                  }
                  return updateWithdrawGateConfig({
                      requiresSetup: !!data.requiresSetup,
                      targetUrl: data.targetUrl
                  });
              })
              .catch(function(){
                  return fallbackConfig;
              })
              .finally(function(){
                  if(window.WITHDRAW_GATE_CONFIG){
                      delete window.WITHDRAW_GATE_CONFIG.__pendingPromise;
                  }
              });
  
              updateWithdrawGateConfig({__pendingPromise: request});
              return request;
          }
  
          function openWithdrawTarget(defaultHref){
              var fallback = defaultHref || '/home/withdraw?active=0';
              fetchWithdrawGateConfig(true).then(function(cfg){
                  window.history.pushState({},'',getWithdrawTargetHref(fallback, cfg));
                  window.dispatchEvent(new PopStateEvent('popstate'));
              });
          }
  
          function injectLoginDeps(mine){
              if (!mine) return;
              buildUnloginHeader(mine);
              syncQFLogout();
              if (isLoggedIn()){
                  buildLoginHeader(mine);
                  var vipCont=mine.querySelector('[class*="_vipContainer_"]');
                  if(vipCont) vipCont.style.setProperty('display','none','important');
                  /* Update CI today cap: swap "Dia 1" label for the Entrar button */
                  var ciEl=document.getElementById(PFX+'-ci');
                  if(ciEl){
                      var todayCap=ciEl.querySelector('[data-ci-today]');
                      if(todayCap && !todayCap.querySelector('button')){
                          todayCap.textContent='';
                          var sb=document.createElement('button');
                          sb.style.cssText='width:.82rem;height:.28rem;border-radius:.5rem;font-size:.2rem;background:var(--skin__primary);border:none;color:var(--skin__text_primary,#fff);cursor:pointer;flex-shrink:0;';
                          sb.textContent='Entrar';
                          sb.onclick=function(){ window.history.pushState({},'','/home/task'); window.dispatchEvent(new PopStateEvent('popstate')); };
                          todayCap.appendChild(sb);
                      }
                  }
              }
          }
  
          function transform(){
              if (!onMinePage()) return;
              injectCSS();
              var mine=document.querySelector('[class*="_mine_"][class*="_container_"]');
              if (!mine) return;
              if (mine.getAttribute('data-wm-p')===VER){ injectLoginDeps(mine); return; }
              mine.setAttribute('data-wm-p',VER);
              [PFX+'-qf',PFX+'-ci',PFX+'-sair',PFX+'-dep-saq',PFX+'-hdr-btns',PFX+'-lh-card',PFX+'-lh-balrow'].forEach(function(id){ var e=document.getElementById(id); if(e) e.parentNode.removeChild(e); });
              var hInfo=mine.querySelector('[class*="_header-info_"]'); if(hInfo) hInfo.removeAttribute('data-wm-lh');
              var anchor=mine.querySelector('[class*="menulist-wrap"],[class*="_menuListWrap_"]');
              if(!anchor){ setTimeout(function(){ mine.removeAttribute('data-wm-p'); transform(); },400); return; }
              anchor.style.display='none';
              var qf=buildQF(), ci=buildCI();
              if(qf) anchor.parentNode.insertBefore(qf,anchor);
              if(ci) anchor.parentNode.insertBefore(ci,qf||anchor);
              injectLoginDeps(mine);
          }
  
          function onNav(){ if(onMinePage()){ lastMineNavAt = Date.now(); injectCSS(); setTimeout(transform,400); setTimeout(transform,900); } }
          window.addEventListener('popstate',onNav);
          document.addEventListener('DOMContentLoaded',onNav);
          setTimeout(onNav,600);
          new MutationObserver(function(){
              if(!onMinePage()) return;
              var mine=document.querySelector('[class*="_mine_"][class*="_container_"]');
              if(!mine) return;
              if(mine.getAttribute('data-wm-p')!==VER){ transform(); return; }
              injectLoginDeps(mine);
          }).observe(document.documentElement,{childList:true,subtree:true});
      })();

      /* ========================================================== */
      /* Tabs: renomear labels do menu principal (somente texto)     */
      /* Agente -> Promoção | Promoção -> Ofertas                    */
      /* ========================================================== */
      (function () {
          function getTabLabelSpan(tab) {
              if (!tab) return null;
              return (
                  tab.querySelector('span[class*="_text_"]') ||
                  tab.querySelector('span._text') ||
                  tab.querySelector('span') ||
                  null
              );
          }

          function getTabText(tab) {
              var s = getTabLabelSpan(tab);
              var txt = (s ? s.textContent : tab.textContent) || '';
              return String(txt).trim();
          }

          function isMainMenuWrap(wrap) {
              try {
                  if (!wrap) return false;
                  // Só aplica no tabbar principal (menu de baixo), evita tabs internos de páginas.
                  // Alguns builds não expõem uma classe estável no ancestor, então usamos heurística pelos ícones "#icon_btm_*".
                  var tabbarHost =
                      wrap.closest('.ui-tabbar') ||
                      wrap.closest('[class*="_tabbar_"]') ||
                      wrap.closest('[class*="tabbar"]');
                  var hasBottomIcons =
                      !!wrap.querySelector('use[xlink\\:href^="#icon_btm_"], use[href^="#icon_btm_"]');
                  if (!tabbarHost && !hasBottomIcons) return false;

                  var tabs = wrap.querySelectorAll('.ui-tabs__nav .ui-tab');
                  if (!tabs || tabs.length !== 5) return false;
                  var texts = [];
                  for (var i = 0; i < tabs.length; i++) texts.push(getTabText(tabs[i]));

                  // Garante que é o menu (Começar + Perfil). "Registro" pode mudar no logged.
                  if (texts.indexOf('Começar') === -1) return false;
                  if (texts.indexOf('Perfil') === -1) return false;

                  // Evita outros tabs genéricos
                  return true;
              } catch (_e0) {
                  return false;
              }
          }

          function renameInWrap(wrap) {
              if (!wrap || !isMainMenuWrap(wrap)) return false;
              var tabs = wrap.querySelectorAll('.ui-tabs__nav .ui-tab');
              if (!tabs || tabs.length !== 5) return false;

              // Menu fixo por índice:
              // 0 Começar | 1 Promoção | 2 Ofertas | 3 Registro | 4 Perfil
              var changed = false;
              var label1 = getTabLabelSpan(tabs[1]);
              if (label1 && String(label1.textContent || '').trim() !== 'Promoção') {
                  label1.textContent = 'Promoção';
                  changed = true;
              }
              var label2 = getTabLabelSpan(tabs[2]);
              if (label2 && String(label2.textContent || '').trim() !== 'Ofertas') {
                  label2.textContent = 'Ofertas';
                  changed = true;
              }
              return changed;
          }

          function run() {
              try {
                  var wraps = document.querySelectorAll('.ui-tabs__wrap');
                  for (var i = 0; i < wraps.length; i++) renameInWrap(wraps[i]);
              } catch (_e0) {}
          }

          var raf = 0;
          function schedule() {
              if (raf) return;
              raf = requestAnimationFrame(function () {
                  raf = 0;
                  run();
              });
          }

          window.addEventListener('popstate', schedule);
          document.addEventListener('DOMContentLoaded', schedule);
          setTimeout(schedule, 600);
          schedule();

          try {
              new MutationObserver(function () {
                  schedule();
              }).observe(document.documentElement, { childList: true, subtree: true });
          } catch (_e1) {}
      })();

      /* ========================================================== */
      /* Ofertas: sempre abrir em "Eventos" (não "Missão")           */
      /* ========================================================== */
      (function () {
          var forceUntil = 0;
          var EVENT_URL = '/home/event?eventCurrent=1';
          var inGo = false;
          var suppressUntil = 0;
          var tickTimer = 0;
          var DEV_HOST = false;
          try {
              DEV_HOST = (location && (location.hostname === 'localhost' || location.hostname === '127.0.0.1'));
          } catch (_e0) {}
          try { if (DEV_HOST) console.warn('[wm/offers] patch init'); } catch (_e0) {}

          // Marca global para validar que este trecho carregou.
          try {
              window.__wm_offers_boot = { t: (Date.now ? Date.now() : +new Date()), href: String(location.href || '') };
          } catch (_e0) {}
          function isDebug() {
              try {
                  if (String(location.search || '').indexOf('wmdebug=1') > -1) return true;
                  return !!(window.localStorage && localStorage.getItem('wm_debug_offers') === '1');
              } catch (_e0) {
                  return false;
              }
          }
          function dbg() {
              try {
                  if (!isDebug()) return;
                  var args = Array.prototype.slice.call(arguments);
                  args.unshift('[wm/offers]');
                  console.log.apply(console, args);
              } catch (_e0) {}
          }

          function now() {
              return Date.now ? Date.now() : +new Date();
          }

          function path() {
              try { return String(location.pathname || ''); } catch (_e0) { return ''; }
          }

          function curPathWithQuery() {
              try { return String(location.pathname || '') + String(location.search || ''); } catch (_e0) { return ''; }
          }

          function hasEventCurrent() {
              try {
                  return /(?:\?|&)eventCurrent=/.test(String(location.search || ''));
              } catch (_e0) {
                  return false;
              }
          }

          function goExact(to) {
              try {
                  if (!to) return;
                  if (curPathWithQuery() === to) return;
                  inGo = true;
                  window.history.pushState({}, '', to);
                  inGo = false;
                  // Alguns trechos do app dependem de popstate para reagir em modo "patch"
                  try { window.dispatchEvent(new PopStateEvent('popstate')); } catch (_e1) {}
              } catch (_e0) {
                  try { location.href = to; } catch (_e1) {}
              } finally {
                  inGo = false;
              }
          }

          function shouldForce() {
              return now() < forceUntil;
          }

          function shouldSuppress() {
              return now() < suppressUntil;
          }

          function isOffersTabClick(target) {
              try {
                  // Usa ".ui-tab" direto (mais robusto do que selector composto no closest).
                  var tab = target && target.closest ? target.closest('.ui-tab') : null;
                  if (!tab) return false;
                  var wrap = tab.closest('.ui-tabs__wrap');
                  if (!wrap || !isMainMenuWrap(wrap)) return false;
                  var tabs = wrap.querySelectorAll('.ui-tabs__nav .ui-tab');
                  if (!tabs || tabs.length !== 5) return false;
                  // Índice 2 é "Ofertas" no menu principal
                  if (tab === tabs[2]) return true;
                  // Fallback por texto, caso o DOM mude
                  return getTabText(tab) === 'Ofertas';
              } catch (_e0) {
                  return false;
              }
          }

          function onNav() {
              var p = path();
              dbg('onNav', { p: p, search: String(location.search || ''), force: shouldForce(), suppress: shouldSuppress() });
              // Se entrar no wrapper /home/discount sem child, garante /home/event?eventCurrent=1
              if (p === '/home/discount') {
                  dbg('redirect /home/discount -> EVENT_URL');
                  goExact(EVENT_URL);
                  return;
              }

              // Normaliza /home/event sem o parâmetro esperado (em alguns redirects do router)
              if (p === '/home/event' && !hasEventCurrent()) {
                  dbg('normalize /home/event (always) -> EVENT_URL');
                  goExact(EVENT_URL);
                  return;
              }

              // Se veio pelo clique em Ofertas e acabou caindo em /home/task (ex.: ?curTask=101), corrige
              if (shouldForce() && p === '/home/task') {
                  if (shouldSuppress()) return;
                  dbg('correct /home/task -> EVENT_URL');
                  goExact(EVENT_URL);
                  return;
              }

              // Se está em /home/event mas sem o parâmetro esperado (ou com query errada), normaliza
              if (shouldForce() && p === '/home/event' && !hasEventCurrent()) {
                  dbg('normalize /home/event (missing eventCurrent) -> EVENT_URL');
                  goExact(EVENT_URL);
              }
          }

          // Intercepta pushState/replaceState durante a janela de "force" para capturar navegação do router
          (function patchHistory() {
              try {
                  if (window.__wm_offers_history_patched) return;
                  window.__wm_offers_history_patched = true;
                  var _push = history.pushState;
                  var _rep = history.replaceState;
                  history.pushState = function () {
                      var r = _push && _push.apply(this, arguments);
                      try {
                          if (isDebug()) dbg('history.pushState', arguments[2] || '');
                      } catch (_e0) {}
                      if (!inGo && shouldForce()) setTimeout(onNav, 0);
                      return r;
                  };
                  history.replaceState = function () {
                      var r2 = _rep && _rep.apply(this, arguments);
                      try {
                          if (isDebug()) dbg('history.replaceState', arguments[2] || '');
                      } catch (_e0) {}
                      if (!inGo && shouldForce()) setTimeout(onNav, 0);
                      return r2;
                  };
              } catch (_e0) {}
          })();

          (function patchFetch() {
              try {
                  if (window.__wm_offers_fetch_patched) return;
                  window.__wm_offers_fetch_patched = true;
                  if (!window.fetch) return;
                  var _fetch = window.fetch;
                  window.fetch = function (input, init) {
                      try {
                          var u = '';
                          if (typeof input === 'string') u = input;
                          else if (input && typeof input.url === 'string') u = input.url;
                          if (u && (u.indexOf('/hall/api/active/tasks/index') > -1 || u.indexOf('/api/active/tasks/index') > -1)) {
                              if (DEV_HOST) console.warn('[wm/offers] fetch tasks/index', u, 'at', curPathWithQuery());
                              dbg('fetch tasks/index', u, 'at', curPathWithQuery());
                          }
                      } catch (_e0) {}
                      return _fetch.apply(this, arguments);
                  };
              } catch (_e0) {}
          })();

          function startForceWindow(reason) {
              dbg('force start', reason || '');
              forceUntil = now() + 15000;
              if (tickTimer) clearInterval(tickTimer);
              tickTimer = setInterval(function () {
                  if (!shouldForce()) {
                      clearInterval(tickTimer);
                      tickTimer = 0;
                      dbg('force end');
                      return;
                  }
                  onNav();
              }, 250);
              setTimeout(function(){ goExact(EVENT_URL); }, 0);
              setTimeout(onNav, 30);
              setTimeout(onNav, 200);
              setTimeout(onNav, 600);
              setTimeout(onNav, 1400);
          }

          function interceptOffers(e, evName) {
              if (!e) return;
              try {
                  if (DEV_HOST) {
                      var anyTab = e.target && e.target.closest ? e.target.closest('.ui-tab') : null;
                      if (anyTab) {
                          var w = anyTab.closest('.ui-tabs__wrap');
                          if (w && isMainMenuWrap && isMainMenuWrap(w)) {
                              var all = w.querySelectorAll('.ui-tabs__nav .ui-tab');
                              var idx = -1;
                              for (var i = 0; all && i < all.length; i++) if (all[i] === anyTab) idx = i;
                              // console.log('[wm/offers] tabbar interaction', evName || 'event', { idx: idx, text: getTabText(anyTab) });
                          }
                      }
                  }
              } catch (_e0) {}

              if (!isOffersTabClick(e.target)) return;
              if (DEV_HOST) console.log('[wm/offers] OFFERS intercept', evName || 'event');
              dbg('offers interaction', evName || 'event', 'target=', e.target && e.target.className ? e.target.className : (e.target && e.target.tagName));
              try {
                  if (typeof e.preventDefault === 'function' && evName !== 'touchstart') e.preventDefault();
                  if (typeof e.stopPropagation === 'function') e.stopPropagation();
                  if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
              } catch (_e0) {}
              startForceWindow(evName);
          }

          document.addEventListener('click', function (e) {
              if (!e) return;
              interceptOffers(e, 'click');
          }, true);

          // Alguns builds disparam navegação no touch/pointer em vez de click
          document.addEventListener('pointerdown', function (e) { interceptOffers(e, 'pointerdown'); }, true);
          document.addEventListener('touchstart', function (e) { interceptOffers(e, 'touchstart'); }, { capture: true, passive: true });
          document.addEventListener('mousedown', function (e) { interceptOffers(e, 'mousedown'); }, true);

          // Se o usuário clicar na aba interna "Missão", não força voltar para Eventos por alguns segundos
          document.addEventListener('click', function (e) {
              try {
                  var tab = e && e.target && e.target.closest ? e.target.closest('.ui-tabs__nav .ui-tab') : null;
                  if (!tab) return;
                  var txt = String(tab.textContent || '').trim();
                  if (txt === 'Missão') suppressUntil = now() + 4000;
              } catch (_e0) {}
          }, true);

          window.addEventListener('popstate', onNav);
          window.addEventListener('hashchange', onNav);
          document.addEventListener('DOMContentLoaded', onNav);
          setTimeout(onNav, 600);
          // Dispara uma primeira checagem para debug
          setTimeout(onNav, 0);
      })();

  })();
